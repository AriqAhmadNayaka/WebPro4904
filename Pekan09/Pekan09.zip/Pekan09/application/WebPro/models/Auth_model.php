<?php
// Mencegah akses script secara langsung dari browser demi keamanan
defined('BASEPATH') OR exit('No direct script access allowed');

// Mendefinisikan class Auth_model yang mewarisi sifat dari CI_Model
class Auth_model extends CI_Model {

    // Nama tabel default yang digunakan
    protected $table = 'users';
    // Variabel untuk menampung daftar kolom tabel agar tidak query berulang kali
    protected $table_fields = NULL;

    // Konstruktor class
    public function __construct()
    {
        // Menjalankan konstruktor dari parent (CI_Model)
        parent::__construct();
        // Memuat library database CodeIgniter
        $this->load->database();
    }

    // Fungsi utama untuk proses login/autentikasi
    public function authenticate($username, $password)
    {
        // Membersihkan spasi dan memastikan input adalah string
        $username = trim((string) $username);
        $password = (string) $password;

        // Jika salah satu kosong, langsung kembalikan NULL (gagal)
        if ($username === '' || $password === '') {
            return NULL;
        }

        // Mencari user di database berdasarkan username (dibatasi hanya 1 hasil)
        $user = $this->db
            ->limit(1)
            ->get_where($this->table, array('username' => $username))
            ->row_array();

        // Jika user tidak ditemukan atau kolom password tidak ada dalam hasil
        if (empty($user) || !isset($user['password'])) {
            return NULL;
        }

        // Mengambil hash password yang tersimpan di database
        $stored_password = (string) $user['password'];

        // Mengecek apakah password input cocok dengan yang tersimpan
        if (!$this->password_matches($password, $stored_password)) {
            return NULL;
        }

        // Fitur canggih: Cek apakah hash perlu diperbarui (misal: dari MD5 ke BCRYPT)
        if ($this->should_upgrade_hash($stored_password)) {
            // Hash ulang password menggunakan algoritma default terbaru
            $new_hash = password_hash($password, PASSWORD_DEFAULT);
            // Menentukan identifier (pakai 'id' jika ada, jika tidak pakai 'username')
            $identifier_column = isset($user['id']) ? 'id' : 'username';
            $identifier_value = isset($user['id']) ? $user['id'] : $user['username'];

            // Update password baru yang sudah di-hash ke database
            $this->db
                ->where($identifier_column, $identifier_value)
                ->update($this->table, array('password' => $new_hash));

            // Update data user di memori agar sinkron
            $user['password'] = $new_hash;
        }

        // Mengembalikan data user dalam bentuk object
        return (object) $user;
    }

    // Alias dari fungsi authenticate untuk kemudahan penamaan
    public function cek_login($username, $password)
    {
        return $this->authenticate($username, $password);
    }

    // Mengecek apakah username sudah terdaftar
    public function username_exists($username)
    {
        $username = trim((string) $username);

        if ($username === '') {
            return FALSE;
        }

        // Menghitung jumlah baris yang memiliki username tersebut
        return $this->db
            ->where('username', $username)
            ->from($this->table)
            ->count_all_results() > 0;
    }

    // Mengecek apakah email sudah terdaftar (jika kolom email ada)
    public function email_exists($email)
    {
        $email = trim((string) $email);

        // Jika kosong atau kolom email tidak ditemukan di tabel, return FALSE
        if ($email === '' || !$this->has_column('email')) {
            return FALSE;
        }

        return $this->db
            ->where('email', $email)
            ->from($this->table)
            ->count_all_results() > 0;
    }

    // Fungsi untuk mendaftarkan user baru
    public function create_user(array $data)
    {
        // Validasi input dasar
        $username = isset($data['username']) ? trim((string) $data['username']) : '';
        $password = isset($data['password']) ? (string) $data['password'] : '';

        if ($username === '' || $password === '') {
            return FALSE;
        }

        // Cegah duplikasi username
        if ($this->username_exists($username)) {
            return FALSE;
        }

        // Menyiapkan data utama untuk di-insert
        $insert_data = array(
            'username' => $username,
            'password' => password_hash($password, PASSWORD_DEFAULT) // Hash aman
        );

        // Mapping field opsional agar fleksibel dengan berbagai nama kolom database
        $optional_map = array(
            'name' => array('name', 'nama_lengkap', 'full_name'),
            'email' => array('email'),
            'phone' => array('phone', 'no_telp', 'nomor_telepon'),
            'address' => array('address', 'alamat')
        );

        // Loop untuk memasukkan data opsional jika kolomnya memang ada di tabel
        foreach ($optional_map as $source_key => $possible_columns) {
            if (!isset($data[$source_key])) {
                continue;
            }

            $value = trim((string) $data[$source_key]);

            if ($value === '') {
                continue;
            }

            foreach ($possible_columns as $column_name) {
                if ($this->has_column($column_name)) {
                    $insert_data[$column_name] = $value;
                    break;
                }
            }
        }

        // Isi kolom timestamp jika tersedia di database
        if ($this->has_column('created_at')) {
            $insert_data['created_at'] = date('Y-m-d H:i:s');
        }

        if ($this->has_column('updated_at')) {
            $insert_data['updated_at'] = date('Y-m-d H:i:s');
        }

        // Eksekusi perintah insert ke database
        $this->db->insert($this->table, $insert_data);

        // Mengembalikan ID user baru atau FALSE jika gagal
        return $this->db->insert_id() ?: FALSE;
    }

    // Fungsi internal untuk mencocokkan password (mendukung hash modern & lama)
    protected function password_matches($input_password, $stored_password)
    {
        if ($stored_password === '') {
            return FALSE;
        }

        // Mendapatkan info algoritma hash yang digunakan di database
        $hash_info = password_get_info($stored_password);

        // Jika menggunakan standar password_hash (BCRYPT/Argon2)
        if (!empty($hash_info['algo'])) {
            return password_verify($input_password, $stored_password);
        }

        // Fallback: Mendukung pengecekan MD5 atau Plain Text (untuk migrasi sistem lama)
        return hash_equals($stored_password, md5($input_password))
            || hash_equals($stored_password, $input_password);
    }

    // Fungsi internal untuk menentukan apakah hash butuh diperbarui
    protected function should_upgrade_hash($stored_password)
    {
        $hash_info = password_get_info($stored_password);

        // Jika bukan format password_hash (misal MD5), harus upgrade
        if (empty($hash_info['algo'])) {
            return TRUE;
        }

        // Jika algoritmanya sudah password_hash, cek apakah cost/standar perlu ditingkatkan
        return password_needs_rehash($stored_password, PASSWORD_DEFAULT);
    }

    // Fungsi internal untuk mengecek ketersediaan kolom di tabel secara dinamis
    protected function has_column($column_name)
    {
        // Cache daftar kolom agar tidak membebani database berkali-kali
        if ($this->table_fields === NULL) {
            $this->table_fields = $this->db->list_fields($this->table);
        }

        return in_array($column_name, $this->table_fields, TRUE);
    }
}