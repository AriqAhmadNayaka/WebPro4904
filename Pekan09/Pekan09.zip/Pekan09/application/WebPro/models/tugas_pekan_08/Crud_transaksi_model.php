<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_transaksi_model extends CI_Model {

    protected $table = 'transaksi';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
        $transactions = $this->db
            ->order_by('tanggal', 'DESC')
            ->order_by('id', 'DESC')
            ->get($this->table)
            ->result();

        foreach ($transactions as $transaction) {
            $this->decorate_transaction($transaction);
        }

        return $transactions;
    }

    public function get_by_id($id)
    {
        $transaction = $this->db
            ->limit(1)
            ->get_where($this->table, array('id' => (int) $id))
            ->row();

        if ($transaction !== NULL) {
            $this->decorate_transaction($transaction);
        }

        return $transaction;
    }

    public function insert(array $data)
    {
        $this->db->insert($this->table, $data);

        return $this->db->insert_id();
    }

    public function update($id, array $data)
    {
        return $this->db
            ->where('id', (int) $id)
            ->update($this->table, $data);
    }

    public function delete($id)
    {
        return $this->db
            ->where('id', (int) $id)
            ->delete($this->table);
    }

    public function get_summary($transactions = NULL)
    {
        if ($transactions === NULL) {
            $transactions = $this->get_all();
        }

        $summary = array(
            'total_pemasukan' => 0,
            'total_pengeluaran' => 0,
            'saldo' => 0,
            'jumlah_transaksi' => 0
        );

        foreach ($transactions as $transaction) {
            $amount = isset($transaction->jumlah) ? (float) $transaction->jumlah : 0;
            $type = $this->normalize_jenis(isset($transaction->jenis) ? $transaction->jenis : '');

            if ($type === 'pemasukan') {
                $summary['total_pemasukan'] += $amount;
            } else {
                $summary['total_pengeluaran'] += $amount;
            }

            $summary['jumlah_transaksi']++;
        }

        $summary['saldo'] = $summary['total_pemasukan'] - $summary['total_pengeluaran'];

        return $summary;
    }

    protected function decorate_transaction($transaction)
    {
        $transaction->jenis_normalized = $this->normalize_jenis(isset($transaction->jenis) ? $transaction->jenis : '');
        $transaction->has_file = isset($transaction->file_bukti) && $transaction->file_bukti !== '';
    }

    protected function normalize_jenis($jenis)
    {
        $normalized = strtolower(trim((string) $jenis));

        if (in_array($normalized, array('pemasukan', 'masuk', 'income'), TRUE)) {
            return 'pemasukan';
        }

        return 'pengeluaran';
    }
}
