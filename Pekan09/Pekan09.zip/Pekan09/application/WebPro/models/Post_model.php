<?php
// Mencegah akses langsung ke file script demi keamanan aplikasi
defined('BASEPATH') OR exit('No direct script access allowed');

// Mendefinisikan class Post_model yang merupakan turunan dari CI_Model
class Post_model extends CI_Model {

    // Menentukan nama tabel database yang akan digunakan (posts)
    protected $table = 'posts';

    // Fungsi yang otomatis berjalan saat class dipanggil
    public function __construct()
    {
        // Menjalankan fungsi konstruktor dari parent (CI_Model)
        parent::__construct();
        // Memuat library database agar bisa query ke DB
        $this->load->database();
    }

    // Fungsi untuk mengambil semua data postingan
    public function get_all()
    {
        // Mengambil data dari tabel, diurutkan berdasarkan tgl dibuat & ID terbaru
        $posts = $this->db
            ->order_by('created_at', 'DESC')
            ->order_by('id', 'DESC')
            ->get($this->table)
            ->result();

        // Melakukan looping untuk memproses setiap baris data yang didapat
        foreach ($posts as $post) {
            // Memanggil fungsi internal untuk menambah URL gambar ke setiap post
            $this->decorate_post($post);
        }

        // Mengembalikan kumpulan data hasil query tadi
        return $posts;
    }

    // Fungsi untuk mengambil satu data post berdasarkan ID-nya
    public function get_by_id($id)
    {
        // Mencari data dengan limit 1 berdasarkan ID yang di-cast ke integer
        $post = $this->db
            ->limit(1)
            ->get_where($this->table, array('id' => (int) $id))
            ->row();

        // Jika data ketemu (bukan NULL), proses URL gambarnya
        if ($post !== NULL) {
            $this->decorate_post($post);
        }

        // Mengembalikan objek data post tunggal atau NULL jika zonk
        return $post;
    }

    // Fungsi untuk memasukkan data baru ke tabel posts
    public function insert($data)
    {
        // Menjalankan perintah insert database
        $this->db->insert($this->table, $data);
        // Mengembalikan ID terakhir yang baru saja diinput
        return $this->db->insert_id();
    }

    // Fungsi untuk mengupdate data post yang sudah ada
    public function update($id, $data)
    {
        // Update data berdasarkan ID yang spesifik
        return $this->db
            ->where('id', (int) $id)
            ->update($this->table, $data);
    }

    // Fungsi untuk menghapus data post berdasarkan ID
    public function delete($id)
    {
        // Menjalankan perintah delete pada baris ID tersebut
        return $this->db
            ->where('id', (int) $id)
            ->delete($this->table);
    }

    // Fungsi untuk mengecek apakah ID post tersebut ada di database
    public function exists($id)
    {
        // Menghitung jumlah baris berdasarkan ID, return TRUE jika > 0
        return $this->db
            ->where('id', (int) $id)
            ->from($this->table)
            ->count_all_results() > 0;
    }

    // Fungsi internal (protected) untuk memformat tampilan data (khusus gambar)
    protected function decorate_post($post)
    {
        // Set default URL gambar jadi NULL dulu
        $post->image_url = NULL;

        // Cek apakah kolom image ada isinya, kalau kosong langsung berhenti
        if (!isset($post->image) || empty($post->image)) {
            return;
        }

        // Membersihkan string 'posts/' dari nama file agar tidak dobel saat digabung
        $image_name = str_replace('posts/', '', (string) $post->image);
        // Membuat URL lengkap ke file gambar (misal: http://web.com/uploads/posts/foto.jpg)
        $post->image_url = base_url('uploads/posts/' . $image_name);
    }
}   