<?php
// Mencegah akses langsung ke file script demi keamanan
defined('BASEPATH') OR exit('No direct script access allowed');

// Mendefinisikan class Transaksi_model sebagai turunan CI_Model
class Transaksi_model extends CI_Model {

    // Menentukan nama tabel database yang digunakan yaitu 'transaksi'
    protected $table = 'transaksi';

    // Konstruktor untuk inisialisasi awal
    public function __construct()
    {
        // Menjalankan konstruktor milik parent class
        parent::__construct();
        // Memuat library database CodeIgniter
        $this->load->database();
    }

    // Mengambil semua data transaksi dari database
    public function get_all()
    {
        // Query ambil data, urutkan berdasarkan tanggal terbaru dan ID terbaru
        $transactions = $this->db
            ->order_by('tanggal', 'DESC')
            ->order_by('id', 'DESC')
            ->get($this->table)
            ->result();

        // Loop untuk memproses tiap data transaksi agar lebih rapi (normalized)
        foreach ($transactions as $transaction) {
            $this->decorate_transaction($transaction);
        }

        // Mengembalikan array objek hasil transaksi
        return $transactions;
    }

    // Mengambil data satu transaksi berdasarkan ID
    public function get_by_id($id)
    {
        // Cari satu baris data berdasarkan ID yang dikonversi ke integer
        $transaction = $this->db
            ->limit(1)
            ->get_where($this->table, array('id' => (int) $id))
            ->row();

        // Jika data ada, lakukan pembersihan/format data (decorate)
        if ($transaction !== NULL) {
            $this->decorate_transaction($transaction);
        }

        // Kembalikan objek transaksi tunggal
        return $transaction;
    }

    // Menambah data transaksi baru
    public function insert($data)
    {
        // Masukkan data ke tabel transaksi
        $this->db->insert($this->table, $data);
        // Kembalikan ID dari transaksi yang baru saja dibuat
        return $this->db->insert_id();
    }

    // Menghapus data transaksi berdasarkan ID
    public function delete($id)
    {
        // Jalankan perintah delete berdasarkan filter ID
        return $this->db
            ->where('id', (int) $id)
            ->delete($this->table);
    }

    // Menghitung ringkasan keuangan (total masuk, keluar, dan saldo)
    public function get_summary($transactions = NULL)
    {
        // Jika parameter kosong, otomatis ambil semua data transaksi dulu
        if ($transactions === NULL) {
            $transactions = $this->get_all();
        }

        // Inisialisasi struktur array untuk ringkasan/summary
        $summary = array(
            'total_pemasukan' => 0,
            'total_pengeluaran' => 0,
            'saldo' => 0,
            'jumlah_transaksi' => 0
        );

        // Melakukan perhitungan total dengan looping data transaksi
        foreach ($transactions as $transaction) {
            // Ambil jumlah uang, pastikan formatnya float (angka desimal/pecahan)
            $amount = isset($transaction->jumlah) ? (float) $transaction->jumlah : 0;
            // Cek jenis transaksi (apakah pemasukan atau pengeluaran)
            $type = $this->normalize_jenis(isset($transaction->jenis) ? $transaction->jenis : '');

            // Tambahkan ke total pemasukan jika tipenya cocok
            if ($type === 'pemasukan') {
                $summary['total_pemasukan'] += $amount;
            } else {
                // Tambahkan ke total pengeluaran jika selain pemasukan
                $summary['total_pengeluaran'] += $amount;
            }

            // Hitung jumlah baris transaksi yang diproses
            $summary['jumlah_transaksi']++;
        }

        // Hitung saldo akhir (pemasukan dikurangi pengeluaran)
        $summary['saldo'] = $summary['total_pemasukan'] - $summary['total_pengeluaran'];

        // Kembalikan hasil perhitungan akhir
        return $summary;
    }

    // Fungsi internal untuk memperkaya data objek transaksi
    protected function decorate_transaction($transaction)
    {
        // Tambahkan atribut jenis_normalized agar seragam (pemasukan/pengeluaran)
        $transaction->jenis_normalized = $this->normalize_jenis(isset($transaction->jenis) ? $transaction->jenis : '');
        // Tambahkan status boolean apakah transaksi punya file bukti atau tidak
        $transaction->has_file = isset($transaction->file_bukti) && $transaction->file_bukti !== '';
    }

    // Fungsi internal untuk menyamakan berbagai sebutan jenis transaksi
    protected function normalize_jenis($jenis)
    {
        // Ubah jadi huruf kecil semua dan hapus spasi samping
        $normalized = strtolower(trim((string) $jenis));

        // Jika input adalah 'masuk', 'income', atau 'pemasukan', kembalikan 'pemasukan'
        if (in_array($normalized, array('pemasukan', 'masuk', 'income'), TRUE)) {
            return 'pemasukan';
        }

        // Defaultnya dianggap sebagai pengeluaran
        return 'pengeluaran';
    }
}