<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jwt {

    protected $secret_key;
    protected $algorithm = 'HS256';

    public function __construct()
    {
        $this->secret_key = 'pekan09_codeigniter_secret_key';
    }

    public function encode(array $payload)
    {
        $header = array('typ' => 'JWT', 'alg' => $this->algorithm);
        $segments = array(
            $this->base64url_encode(json_encode($header)),
            $this->base64url_encode(json_encode($payload))
        );

        $signing_input = implode('.', $segments);
        $segments[] = $this->sign($signing_input);

        return implode('.', $segments);
    }

    public function decode($token)
    {
        $parts = explode('.', (string) $token);

        if (count($parts) !== 3) {
            return FALSE;
        }

        list($header, $payload, $signature) = $parts;
        $valid_signature = hash_equals($this->sign($header . '.' . $payload), $signature);

        if (!$valid_signature) {
            return FALSE;
        }

        $decoded_payload = json_decode($this->base64url_decode($payload), TRUE);

        if (!is_array($decoded_payload)) {
            return FALSE;
        }

        if (isset($decoded_payload['exp']) && time() > (int) $decoded_payload['exp']) {
            return FALSE;
        }

        return $decoded_payload;
    }

    protected function sign($input)
    {
        return $this->base64url_encode(hash_hmac('sha256', $input, $this->secret_key, TRUE));
    }

    protected function base64url_encode($data)
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    protected function base64url_decode($data)
    {
        return base64_decode(strtr($data, '-_', '+/'));
    }
}
