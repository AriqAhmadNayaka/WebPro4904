<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'auth';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['auth'] = 'auth/index';
$route['auth/login'] = 'auth/login';
$route['auth/register'] = 'auth/register';
$route['auth/proses_login'] = 'auth/proses_login';
$route['auth/proses_register'] = 'auth/proses_register';
$route['auth/logout'] = 'auth/logout';

$route['dashboard'] = 'dashboard/index';

$route['posts'] = 'posts/index';
$route['posts/create'] = 'posts/create';
$route['posts/store'] = 'posts/store';
$route['posts/show/(:num)'] = 'posts/show/$1';
$route['posts/edit/(:num)'] = 'posts/edit/$1';
$route['posts/update/(:num)'] = 'posts/update/$1';
$route['posts/delete/(:num)'] = 'posts/delete/$1';

$route['tugas-pekan-08'] = 'tugas_pekan_08/transaksi';
$route['tugas-pekan-08/tambah'] = 'tugas_pekan_08/transaksi/create';
$route['tugas-pekan-08/simpan'] = 'tugas_pekan_08/transaksi/store';
$route['tugas-pekan-08/edit/(:num)'] = 'tugas_pekan_08/transaksi/edit/$1';
$route['tugas-pekan-08/update/(:num)'] = 'tugas_pekan_08/transaksi/update/$1';
$route['tugas-pekan-08/hapus/(:num)'] = 'tugas_pekan_08/transaksi/delete/$1';

$route['api/auth/register'] = 'api/auth/register';
$route['api/auth/login'] = 'api/auth/login';
$route['api/auth/logout'] = 'api/auth/logout';
$route['api/auth/me'] = 'api/auth/me';
$route['api/post'] = 'api/post/index';
$route['api/post/(:num)'] = 'api/post/index/$1';

$route['crudjs'] = 'crudjs';
$route['crudjs/list'] = 'crudjs/list';
$route['crudjs/store'] = 'crudjs/store';
$route['crudjs/show/(:num)'] = 'crudjs/show/$1';
$route['crudjs/update/(:num)'] = 'crudjs/update/$1';
$route['crudjs/delete/(:num)'] = 'crudjs/delete/$1';
