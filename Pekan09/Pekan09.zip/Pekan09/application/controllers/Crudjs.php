<?php
require_once APPPATH . 'modules/Crudjs/controllers/Crudjs.php';
