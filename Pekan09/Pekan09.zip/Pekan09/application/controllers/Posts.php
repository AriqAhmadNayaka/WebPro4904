<?php
require_once APPPATH . 'modules/Posts/controllers/Posts.php';
