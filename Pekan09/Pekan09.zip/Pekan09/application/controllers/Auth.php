<?php
require_once APPPATH . 'modules/Auth/controllers/Auth.php';
