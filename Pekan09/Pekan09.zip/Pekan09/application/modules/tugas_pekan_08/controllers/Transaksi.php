<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . 'core/MX_Controller.php';

/**
 * @property Crud_transaksi_model $crud_model
 * @property CI_Form_validation $form_validation
 * @property CI_Input $input
 * @property CI_Loader $load
 * @property CI_Session $session
 * @property CI_Upload $upload
 */
class Transaksi extends MX_Controller {

    protected $upload_directory = FCPATH . 'uploads/bukti/';
    protected $max_upload_size_kb = 10240;

    public function __construct()
    {
        parent::__construct();
        $this->load->model('tugas_pekan_08/Crud_transaksi_model', 'crud_model');
        $this->load->helper(array('url', 'form'));
        $this->load->library(array('form_validation', 'session', 'upload'));
    }

    public function index()
    {
        $transactions = $this->crud_model->get_all();

        $data = array(
            'title' => 'Tugas Pekan 08 - CRUD Sederhana',
            'transaksi' => $transactions,
            'summary' => $this->crud_model->get_summary($transactions),
            'error' => (string) $this->session->flashdata('error'),
            'success' => (string) $this->session->flashdata('success')
        );

        $this->load->view('tugas_pekan_08/index', $data);
    }

    public function create()
    {
        $data = array(
            'title' => 'Tambah Transaksi',
            'form_action' => 'tugas-pekan-08/simpan',
            'submit_label' => 'Simpan Transaksi',
            'form_data' => (array) $this->session->flashdata('form_data'),
            'error' => (string) $this->session->flashdata('error'),
            'transaction' => NULL
        );

        $this->load->view('tugas_pekan_08/form', $data);
    }

    public function store()
    {
        $form_data = $this->collect_form_data();
        $this->session->set_flashdata('form_data', $form_data);
        $uploaded_file = '';

        if (!$this->validate_form()) {
            $this->session->set_flashdata('error', $this->validation_message('Data transaksi belum valid.'));
            redirect('tugas-pekan-08/tambah');
            return;
        }

        $payload = array(
            'tanggal' => $form_data['tanggal'],
            'keterangan' => $form_data['keterangan'],
            'jenis' => $form_data['jenis'],
            'jumlah' => (int) $form_data['jumlah']
        );

        if (!empty($_FILES['file_bukti']['name'])) {
            $upload_result = $this->upload_bukti();

            if (!$upload_result['status']) {
                $this->session->set_flashdata('error', $upload_result['error']);
                redirect('tugas-pekan-08/tambah');
                return;
            }

            $uploaded_file = $upload_result['file_name'];
            $payload['file_bukti'] = $upload_result['file_name'];
        }

        if ($this->crud_model->insert($payload)) {
            $this->session->set_flashdata('success', 'Data transaksi berhasil ditambahkan.');
        } else {
            if ($uploaded_file !== '') {
                $uploaded_file_path = $this->upload_directory . $uploaded_file;
                if (is_file($uploaded_file_path)) {
                    unlink($uploaded_file_path);
                }
            }

            $this->session->set_flashdata('error', 'Data transaksi gagal disimpan.');
            redirect('tugas-pekan-08/tambah');
            return;
        }

        redirect('tugas-pekan-08');
    }

    public function edit($id = NULL)
    {
        $id = (int) $id;
        $transaction = $this->crud_model->get_by_id($id);

        if ($id < 1 || $transaction === NULL) {
            $this->session->set_flashdata('error', 'Data transaksi tidak ditemukan.');
            redirect('tugas-pekan-08');
            return;
        }

        $data = array(
            'title' => 'Edit Transaksi',
            'form_action' => 'tugas-pekan-08/update/' . $id,
            'submit_label' => 'Update Transaksi',
            'form_data' => (array) $this->session->flashdata('form_data'),
            'error' => (string) $this->session->flashdata('error'),
            'transaction' => $transaction
        );

        $this->load->view('tugas_pekan_08/form', $data);
    }

    public function update($id = NULL)
    {
        $id = (int) $id;
        $transaction = $this->crud_model->get_by_id($id);
        $uploaded_file = '';

        if ($id < 1 || $transaction === NULL) {
            $this->session->set_flashdata('error', 'Data transaksi tidak ditemukan.');
            redirect('tugas-pekan-08');
            return;
        }

        $form_data = $this->collect_form_data();
        $this->session->set_flashdata('form_data', $form_data);

        if (!$this->validate_form()) {
            $this->session->set_flashdata('error', $this->validation_message('Data transaksi belum valid.'));
            redirect('tugas-pekan-08/edit/' . $id);
            return;
        }

        $payload = array(
            'tanggal' => $form_data['tanggal'],
            'keterangan' => $form_data['keterangan'],
            'jenis' => $form_data['jenis'],
            'jumlah' => (int) $form_data['jumlah']
        );

        if (!empty($_FILES['file_bukti']['name'])) {
            $upload_result = $this->upload_bukti();

            if (!$upload_result['status']) {
                $this->session->set_flashdata('error', $upload_result['error']);
                redirect('tugas-pekan-08/edit/' . $id);
                return;
            }

            $uploaded_file = $upload_result['file_name'];
            $payload['file_bukti'] = $upload_result['file_name'];
        }

        if ($this->crud_model->update($id, $payload)) {
            if ($uploaded_file !== '' && !empty($transaction->file_bukti)) {
                $old_file = $this->upload_directory . $transaction->file_bukti;
                if (is_file($old_file)) {
                    unlink($old_file);
                }
            }

            $this->session->set_flashdata('success', 'Data transaksi berhasil diperbarui.');
        } else {
            if ($uploaded_file !== '') {
                $uploaded_file_path = $this->upload_directory . $uploaded_file;
                if (is_file($uploaded_file_path)) {
                    unlink($uploaded_file_path);
                }
            }

            $this->session->set_flashdata('error', 'Data transaksi gagal diperbarui.');
            redirect('tugas-pekan-08/edit/' . $id);
            return;
        }

        redirect('tugas-pekan-08');
    }

    public function delete($id = NULL)
    {
        $id = (int) $id;
        $transaction = $this->crud_model->get_by_id($id);

        if ($id < 1 || $transaction === NULL) {
            $this->session->set_flashdata('error', 'Data transaksi tidak ditemukan.');
            redirect('tugas-pekan-08');
            return;
        }

        if ($this->crud_model->delete($id)) {
            if (!empty($transaction->file_bukti)) {
                $file_path = $this->upload_directory . $transaction->file_bukti;
                if (is_file($file_path)) {
                    unlink($file_path);
                }
            }

            $this->session->set_flashdata('success', 'Data transaksi berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Data transaksi gagal dihapus.');
        }

        redirect('tugas-pekan-08');
    }

    protected function collect_form_data()
    {
        return array(
            'tanggal' => trim((string) $this->input->post('tanggal', TRUE)),
            'keterangan' => trim((string) $this->input->post('keterangan', TRUE)),
            'jenis' => trim((string) $this->input->post('jenis', TRUE)),
            'jumlah' => trim((string) $this->input->post('jumlah', TRUE))
        );
    }

    protected function validate_form()
    {
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'trim|required');
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'trim|required|max_length[255]');
        $this->form_validation->set_rules('jenis', 'Jenis', 'trim|required|in_list[pemasukan,pengeluaran]');
        $this->form_validation->set_rules('jumlah', 'Jumlah', 'trim|required|integer|greater_than[0]');

        return $this->form_validation->run();
    }

    protected function upload_bukti()
    {
        if (!isset($_FILES['file_bukti'])) {
            return array(
                'status' => FALSE,
                'error' => 'File bukti tidak ditemukan pada request.'
            );
        }

        if ($_FILES['file_bukti']['error'] === UPLOAD_ERR_INI_SIZE || $_FILES['file_bukti']['error'] === UPLOAD_ERR_FORM_SIZE) {
            return array(
                'status' => FALSE,
                'error' => 'Ukuran file terlalu besar. Maksimal upload adalah 10 MB.'
            );
        }

        if (!is_dir($this->upload_directory)) {
            if (!mkdir($this->upload_directory, 0777, TRUE) && !is_dir($this->upload_directory)) {
                return array(
                    'status' => FALSE,
                    'error' => 'Folder upload bukti tidak bisa dibuat.'
                );
            }
        }

        $config['upload_path'] = $this->upload_directory;
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = $this->max_upload_size_kb;
        $config['encrypt_name'] = TRUE;

        $this->upload->initialize($config);

        if ($this->upload->do_upload('file_bukti')) {
            $upload_data = $this->upload->data();

            return array(
                'status' => TRUE,
                'file_name' => $upload_data['file_name']
            );
        }

        return array(
            'status' => FALSE,
            'error' => $this->normalize_upload_error($this->upload->display_errors('', ''))
        );
    }

    protected function normalize_upload_error($message)
    {
        if (stripos($message, 'larger than the permitted size') !== FALSE) {
            return 'Ukuran file terlalu besar. Maksimal upload adalah 10 MB.';
        }

        if (stripos($message, 'filetype you are attempting to upload is not allowed') !== FALSE) {
            return 'Format file tidak didukung. Gunakan JPG, JPEG, PNG, GIF, atau PDF.';
        }

        return $message;
    }

    protected function validation_message($default_message)
    {
        $errors = $this->form_validation->error_array();

        return empty($errors) ? $default_message : implode(' ', $errors);
    }
}
