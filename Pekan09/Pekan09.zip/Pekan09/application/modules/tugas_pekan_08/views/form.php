<?php
$transaction = isset($transaction) && is_object($transaction) ? $transaction : NULL;
$form_data = isset($form_data) && is_array($form_data) ? $form_data : array();
$title = isset($title) ? (string) $title : 'Form Transaksi';
$form_action = isset($form_action) ? (string) $form_action : 'tugas-pekan-08/simpan';
$submit_label = isset($submit_label) ? (string) $submit_label : 'Simpan';
$error = isset($error) ? (string) $error : '';

$tanggal = isset($form_data['tanggal']) ? $form_data['tanggal'] : ($transaction !== NULL && isset($transaction->tanggal) ? $transaction->tanggal : '');
$keterangan = isset($form_data['keterangan']) ? $form_data['keterangan'] : ($transaction !== NULL && isset($transaction->keterangan) ? $transaction->keterangan : '');
$jenis = isset($form_data['jenis']) ? $form_data['jenis'] : ($transaction !== NULL && isset($transaction->jenis_normalized) ? $transaction->jenis_normalized : '');
$jumlah = isset($form_data['jumlah']) ? $form_data['jumlah'] : ($transaction !== NULL && isset($transaction->jumlah) ? $transaction->jumlah : '');
$file_bukti = $transaction !== NULL && !empty($transaction->file_bukti) ? (string) $transaction->file_bukti : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo html_escape($title); ?></title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Georgia, "Times New Roman", serif;
            background:
                radial-gradient(circle at top right, rgba(216, 180, 116, 0.18), transparent 30%),
                linear-gradient(180deg, #f5efe3 0%, #edf4f1 100%);
            color: #17322c;
        }

        .page {
            max-width: 840px;
            margin: 0 auto;
            padding: 28px 18px 40px;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            margin-bottom: 18px;
            color: #174d45;
            text-decoration: none;
            font-weight: 700;
        }

        .panel {
            padding: 28px;
            border-radius: 28px;
            background: rgba(255, 255, 255, 0.92);
            border: 1px solid rgba(23, 50, 44, 0.08);
            box-shadow: 0 18px 42px rgba(23, 50, 44, 0.1);
        }

        h1 {
            margin: 0 0 8px;
            font-size: clamp(30px, 5vw, 42px);
            line-height: 1.08;
        }

        .intro {
            margin: 0 0 22px;
            color: #5e746f;
        }

        .alert {
            margin-bottom: 16px;
            padding: 14px 16px;
            border-radius: 16px;
            background: #fff1f2;
            border: 1px solid #fecdd3;
            color: #9f1239;
            font-size: 14px;
        }

        .field {
            margin-bottom: 16px;
        }

        .field label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 700;
        }

        .field input,
        .field select,
        .field textarea {
            width: 100%;
            padding: 13px 14px;
            border-radius: 16px;
            border: 1px solid #cdd8d4;
            background: #fcfcfb;
            font-size: 15px;
            font-family: inherit;
        }

        .field textarea {
            min-height: 132px;
            resize: vertical;
        }

        .field input:focus,
        .field select:focus,
        .field textarea:focus {
            outline: none;
            border-color: #1f7668;
            box-shadow: 0 0 0 4px rgba(31, 118, 104, 0.12);
        }

        .help {
            margin-top: 8px;
            color: #60756e;
            font-size: 13px;
        }

        .actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 24px;
        }

        .button,
        .button-secondary {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 14px 18px;
            border-radius: 16px;
            text-decoration: none;
            font-weight: 700;
            border: none;
            cursor: pointer;
            font-family: inherit;
            font-size: 15px;
        }

        .button {
            background: linear-gradient(135deg, #174d45 0%, #1f7668 60%, #d8b474 100%);
            color: #fff8ea;
        }

        .button-secondary {
            background: #edf4f1;
            color: #174d45;
        }
    </style>
</head>
<body>
    <div class="page">
        <a class="back-link" href="<?php echo site_url('tugas-pekan-08'); ?>">Kembali ke daftar transaksi</a>

        <section class="panel">
            <h1><?php echo html_escape($title); ?></h1>
            <p class="intro">Silakan isi form berikut untuk menyimpan data transaksi pada tugas pekan 08.</p>

            <?php if ($error !== ''): ?>
                <div class="alert"><?php echo html_escape($error); ?></div>
            <?php endif; ?>

            <?php echo form_open_multipart($form_action); ?>
                <div class="field">
                    <label for="tanggal">Tanggal</label>
                    <input type="date" id="tanggal" name="tanggal" value="<?php echo html_escape($tanggal); ?>" required>
                </div>

                <div class="field">
                    <label for="keterangan">Keterangan</label>
                    <textarea id="keterangan" name="keterangan" required><?php echo html_escape($keterangan); ?></textarea>
                </div>

                <div class="field">
                    <label for="jenis">Jenis Transaksi</label>
                    <select id="jenis" name="jenis" required>
                        <option value="">Pilih jenis transaksi</option>
                        <option value="pemasukan" <?php echo $jenis === 'pemasukan' ? 'selected' : ''; ?>>Pemasukan</option>
                        <option value="pengeluaran" <?php echo $jenis === 'pengeluaran' ? 'selected' : ''; ?>>Pengeluaran</option>
                    </select>
                </div>

                <div class="field">
                    <label for="jumlah">Jumlah</label>
                    <input type="number" id="jumlah" name="jumlah" min="1" value="<?php echo html_escape((string) $jumlah); ?>" required>
                </div>

                <div class="field">
                    <label for="file_bukti">File Bukti</label>
                    <input type="file" id="file_bukti" name="file_bukti" accept=".jpg,.jpeg,.png,.gif,.pdf">
                    <p class="help">Format yang didukung: JPG, JPEG, PNG, GIF, PDF. Maksimal 10 MB.</p>
                    <?php if ($file_bukti !== ''): ?>
                        <p class="help">
                            File saat ini:
                            <a href="<?php echo base_url('uploads/bukti/' . rawurlencode($file_bukti)); ?>" target="_blank" rel="noopener noreferrer"><?php echo html_escape($file_bukti); ?></a>
                        </p>
                        <p class="help">Kosongkan upload jika tidak ingin mengganti file lama.</p>
                    <?php endif; ?>
                </div>

                <div class="actions">
                    <button class="button" type="submit"><?php echo html_escape($submit_label); ?></button>
                    <a class="button-secondary" href="<?php echo site_url('tugas-pekan-08'); ?>">Batal</a>
                </div>
            <?php echo form_close(); ?>
        </section>
    </div>
</body>
</html>
