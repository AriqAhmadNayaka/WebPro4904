<?php
$summary = isset($summary) && is_array($summary) ? $summary : array();
$transaksi = isset($transaksi) && is_array($transaksi) ? $transaksi : array();
$error = isset($error) ? (string) $error : '';
$success = isset($success) ? (string) $success : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas Pekan 08 - CRUD Sederhana</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Georgia, "Times New Roman", serif;
            background:
                radial-gradient(circle at top left, rgba(17, 94, 89, 0.14), transparent 32%),
                linear-gradient(180deg, #f8f4eb 0%, #eef3f0 100%);
            color: #17322c;
        }

        a {
            color: inherit;
        }

        .page {
            max-width: 1180px;
            margin: 0 auto;
            padding: 28px 18px 40px;
        }

        .hero {
            display: grid;
            grid-template-columns: 1.4fr auto;
            gap: 16px;
            align-items: end;
            padding: 28px;
            border-radius: 28px;
            background: linear-gradient(135deg, #174d45 0%, #1f7668 58%, #d8b474 100%);
            color: #fff8ea;
            box-shadow: 0 18px 46px rgba(23, 50, 44, 0.16);
        }

        .hero h1 {
            margin: 0 0 10px;
            font-size: clamp(32px, 5vw, 48px);
            line-height: 1.05;
        }

        .hero p {
            margin: 0;
            max-width: 680px;
            color: rgba(255, 248, 234, 0.88);
            font-size: 16px;
        }

        .cta {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 14px 18px;
            border-radius: 16px;
            background: #fff8ea;
            color: #174d45;
            font-weight: 700;
            text-decoration: none;
            white-space: nowrap;
        }

        .alerts {
            display: grid;
            gap: 12px;
            margin-top: 18px;
        }

        .alert {
            padding: 14px 16px;
            border-radius: 16px;
            border: 1px solid transparent;
            font-size: 14px;
        }

        .alert-error {
            background: #fff1f2;
            border-color: #fecdd3;
            color: #9f1239;
        }

        .alert-success {
            background: #ecfdf5;
            border-color: #a7f3d0;
            color: #065f46;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 16px;
            margin: 22px 0;
        }

        .card {
            padding: 20px;
            border-radius: 22px;
            background: rgba(255, 255, 255, 0.86);
            border: 1px solid rgba(23, 50, 44, 0.08);
            box-shadow: 0 14px 36px rgba(23, 50, 44, 0.08);
        }

        .card span {
            display: block;
            margin-bottom: 12px;
            color: #5e746f;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }

        .card strong {
            font-size: 28px;
            line-height: 1.2;
        }

        .table-card {
            padding: 22px;
            border-radius: 24px;
            background: rgba(255, 255, 255, 0.92);
            border: 1px solid rgba(23, 50, 44, 0.08);
            box-shadow: 0 14px 36px rgba(23, 50, 44, 0.08);
            overflow-x: auto;
        }

        .table-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 14px;
        }

        .table-head h2 {
            margin: 0;
            font-size: 28px;
        }

        .table-head p {
            margin: 6px 0 0;
            color: #5e746f;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 760px;
        }

        th,
        td {
            padding: 14px 12px;
            border-bottom: 1px solid #e7ece8;
            text-align: left;
            vertical-align: top;
        }

        th {
            color: #60756e;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }

        .badge {
            display: inline-flex;
            align-items: center;
            padding: 8px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
        }

        .badge-pemasukan {
            background: #dcfce7;
            color: #166534;
        }

        .badge-pengeluaran {
            background: #fee2e2;
            color: #991b1b;
        }

        .actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .action-link {
            display: inline-flex;
            align-items: center;
            padding: 9px 12px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 700;
            font-size: 13px;
        }

        .action-edit {
            background: #e0f2fe;
            color: #0c4a6e;
        }

        .action-delete {
            background: #fee2e2;
            color: #991b1b;
        }

        .action-file {
            background: #ecfeff;
            color: #155e75;
        }

        .empty {
            text-align: center;
            color: #5e746f;
            padding: 24px 12px;
        }

        @media (max-width: 900px) {
            .hero,
            .stats {
                grid-template-columns: 1fr;
            }

            .table-head {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="page">
        <section class="hero">
            <div>
                <h1>Tugas Pekan 08<br>CRUD Transaksi Sederhana</h1>
                <p>Aplikasi ini dibuat dengan pola MVC di CodeIgniter 3 untuk mengelola data transaksi pada tabel <strong>transaksi</strong> yang sudah Anda siapkan.</p>
            </div>
            <a class="cta" href="<?php echo site_url('tugas-pekan-08/tambah'); ?>">Tambah Data</a>
        </section>

        <div class="alerts">
            <?php if ($success !== ''): ?>
                <div class="alert alert-success"><?php echo html_escape($success); ?></div>
            <?php endif; ?>
            <?php if ($error !== ''): ?>
                <div class="alert alert-error"><?php echo html_escape($error); ?></div>
            <?php endif; ?>
        </div>

        <section class="stats">
            <div class="card">
                <span>Total Pemasukan</span>
                <strong>Rp <?php echo number_format(isset($summary['total_pemasukan']) ? (float) $summary['total_pemasukan'] : 0, 0, ',', '.'); ?></strong>
            </div>
            <div class="card">
                <span>Total Pengeluaran</span>
                <strong>Rp <?php echo number_format(isset($summary['total_pengeluaran']) ? (float) $summary['total_pengeluaran'] : 0, 0, ',', '.'); ?></strong>
            </div>
            <div class="card">
                <span>Saldo</span>
                <strong>Rp <?php echo number_format(isset($summary['saldo']) ? (float) $summary['saldo'] : 0, 0, ',', '.'); ?></strong>
            </div>
            <div class="card">
                <span>Jumlah Data</span>
                <strong><?php echo number_format(isset($summary['jumlah_transaksi']) ? (int) $summary['jumlah_transaksi'] : count($transaksi), 0, ',', '.'); ?></strong>
            </div>
        </section>

        <section class="table-card">
            <div class="table-head">
                <div>
                    <h2>Daftar Transaksi</h2>
                    <p>Fitur yang tersedia: create, read, update, dan delete.</p>
                </div>
                <a class="cta" href="<?php echo site_url('tugas-pekan-08/tambah'); ?>">Input Baru</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Jenis</th>
                        <th>Jumlah</th>
                        <th>File Bukti</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($transaksi)): ?>
                        <tr>
                            <td colspan="7" class="empty">Belum ada data transaksi.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($transaksi as $item): ?>
                            <?php $jenis_normalized = isset($item->jenis_normalized) ? $item->jenis_normalized : 'pengeluaran'; ?>
                            <tr>
                                <td><?php echo isset($item->id) ? (int) $item->id : 0; ?></td>
                                <td><?php echo !empty($item->tanggal) ? html_escape($item->tanggal) : '-'; ?></td>
                                <td><?php echo isset($item->keterangan) ? html_escape($item->keterangan) : '-'; ?></td>
                                <td>
                                    <span class="badge <?php echo $jenis_normalized === 'pemasukan' ? 'badge-pemasukan' : 'badge-pengeluaran'; ?>">
                                        <?php echo isset($item->jenis) ? html_escape(ucfirst($item->jenis)) : '-'; ?>
                                    </span>
                                </td>
                                <td>Rp <?php echo number_format(isset($item->jumlah) ? (float) $item->jumlah : 0, 0, ',', '.'); ?></td>
                                <td>
                                    <?php if (!empty($item->file_bukti)): ?>
                                        <a class="action-link action-file" href="<?php echo base_url('uploads/bukti/' . rawurlencode($item->file_bukti)); ?>" target="_blank" rel="noopener noreferrer">Buka Bukti</a>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a class="action-link action-edit" href="<?php echo site_url('tugas-pekan-08/edit/' . (int) $item->id); ?>">Edit</a>
                                        <a class="action-link action-delete" href="<?php echo site_url('tugas-pekan-08/hapus/' . (int) $item->id); ?>" onclick="return confirm('Hapus data transaksi ini?');">Hapus</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
    </div>
</body>
</html>
