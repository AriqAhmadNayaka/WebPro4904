<?php
$summary = isset($summary) && is_array($summary) ? $summary : array();
$transaksi = isset($transaksi) && is_array($transaksi) ? $transaksi : array();
$form_data = isset($form_data) && is_array($form_data) ? $form_data : array();
$username = isset($username) ? (string) $username : '';
$error = isset($error) ? (string) $error : '';
$success = isset($success) ? (string) $success : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard NaviBiz</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background: #f8fbff;
            color: #16324f;
        }

        .page {
            max-width: 1100px;
            margin: 0 auto;
            padding: 28px 18px 40px;
        }

        .hero {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            margin-bottom: 20px;
            padding: 24px;
            border-radius: 20px;
            background: linear-gradient(135deg, #0d5c9f 0%, #0a84ff 100%);
            color: #ffffff;
        }

        .hero h1 {
            margin: 0 0 8px;
        }

        .hero p {
            margin: 0;
            color: rgba(255, 255, 255, 0.9);
        }

        .logout {
            display: inline-block;
            padding: 12px 16px;
            border-radius: 12px;
            background: #ffffff;
            color: #0d5c9f;
            font-weight: 700;
            text-decoration: none;
        }

        .alerts {
            display: grid;
            gap: 12px;
            margin-bottom: 18px;
        }

        .alert {
            padding: 12px 14px;
            border-radius: 12px;
            font-size: 14px;
        }

        .alert-error {
            background: #fff1f2;
            border: 1px solid #fecdd3;
            color: #9f1239;
        }

        .alert-success {
            background: #ecfdf5;
            border: 1px solid #a7f3d0;
            color: #065f46;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 14px;
            margin-bottom: 20px;
        }

        .stat {
            background: #ffffff;
            border-radius: 18px;
            padding: 18px;
            box-shadow: 0 10px 28px rgba(22, 50, 79, 0.08);
        }

        .stat span {
            display: block;
            color: #64748b;
            font-size: 13px;
            margin-bottom: 10px;
        }

        .stat strong {
            font-size: 24px;
        }

        .grid {
            display: grid;
            grid-template-columns: 360px 1fr;
            gap: 18px;
        }

        .panel {
            background: #ffffff;
            border-radius: 20px;
            padding: 22px;
            box-shadow: 0 10px 28px rgba(22, 50, 79, 0.08);
        }

        .panel h2 {
            margin: 0 0 8px;
        }

        .field {
            margin-bottom: 14px;
        }

        .field label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 600;
        }

        .field input,
        .field select,
        .field textarea {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #cbd5e1;
            border-radius: 12px;
            font-size: 14px;
        }

        .field textarea {
            min-height: 110px;
            resize: vertical;
        }

        .field input:focus,
        .field select:focus,
        .field textarea:focus {
            outline: none;
            border-color: #0a84ff;
            box-shadow: 0 0 0 4px rgba(10, 132, 255, 0.12);
        }

        .submit {
            width: 100%;
            border: none;
            border-radius: 12px;
            padding: 14px;
            background: linear-gradient(135deg, #0a84ff 0%, #0d5c9f 100%);
            color: #ffffff;
            font-weight: 700;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px 10px;
            border-bottom: 1px solid #e2e8f0;
            text-align: left;
            font-size: 14px;
        }

        th {
            color: #64748b;
            font-size: 12px;
            text-transform: uppercase;
        }

        .empty {
            text-align: center;
            color: #64748b;
            padding: 18px 0;
        }

        .delete-link {
            color: #b91c1c;
            font-weight: 600;
            text-decoration: none;
        }

        @media (max-width: 900px) {
            .stats,
            .grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="page">
        <div class="hero">
            <div>
                <h1>Halo, <?php echo html_escape($username !== '' ? $username : 'Pengguna'); ?></h1>
                <p>Kelola data transaksi harian Anda dari satu halaman.</p>
            </div>
            <a class="logout" href="<?php echo site_url('auth/logout'); ?>">Logout</a>
        </div>

        <div class="alerts">
            <?php if ($success !== ''): ?>
                <div class="alert alert-success"><?php echo html_escape($success); ?></div>
            <?php endif; ?>
            <?php if ($error !== ''): ?>
                <div class="alert alert-error"><?php echo html_escape($error); ?></div>
            <?php endif; ?>
        </div>

        <div class="stats">
            <div class="stat">
                <span>Total Pemasukan</span>
                <strong>Rp <?php echo number_format(isset($summary['total_pemasukan']) ? (float) $summary['total_pemasukan'] : 0, 0, ',', '.'); ?></strong>
            </div>
            <div class="stat">
                <span>Total Pengeluaran</span>
                <strong>Rp <?php echo number_format(isset($summary['total_pengeluaran']) ? (float) $summary['total_pengeluaran'] : 0, 0, ',', '.'); ?></strong>
            </div>
            <div class="stat">
                <span>Saldo</span>
                <strong>Rp <?php echo number_format(isset($summary['saldo']) ? (float) $summary['saldo'] : 0, 0, ',', '.'); ?></strong>
            </div>
            <div class="stat">
                <span>Jumlah Transaksi</span>
                <strong><?php echo number_format(isset($summary['jumlah_transaksi']) ? (int) $summary['jumlah_transaksi'] : count($transaksi), 0, ',', '.'); ?></strong>
            </div>
        </div>

        <div class="grid">
            <div class="panel">
                <h2>Tambah Transaksi</h2>
                <?php echo form_open_multipart('dashboard/simpan'); ?>
                    <div class="field">
                        <label for="tanggal">Tanggal</label>
                        <input type="date" id="tanggal" name="tanggal" value="<?php echo html_escape(isset($form_data['tanggal']) ? $form_data['tanggal'] : ''); ?>" required>
                    </div>

                    <div class="field">
                        <label for="keterangan">Keterangan</label>
                        <textarea id="keterangan" name="keterangan" required><?php echo html_escape(isset($form_data['keterangan']) ? $form_data['keterangan'] : ''); ?></textarea>
                    </div>

                    <div class="field">
                        <label for="jenis">Jenis</label>
                        <select id="jenis" name="jenis" required>
                            <option value="">Pilih jenis transaksi</option>
                            <option value="pemasukan" <?php echo (isset($form_data['jenis']) && $form_data['jenis'] === 'pemasukan') ? 'selected' : ''; ?>>Pemasukan</option>
                            <option value="pengeluaran" <?php echo (isset($form_data['jenis']) && $form_data['jenis'] === 'pengeluaran') ? 'selected' : ''; ?>>Pengeluaran</option>
                        </select>
                    </div>

                    <div class="field">
                        <label for="jumlah">Jumlah</label>
                        <input type="number" id="jumlah" name="jumlah" min="1" value="<?php echo html_escape(isset($form_data['jumlah']) ? $form_data['jumlah'] : ''); ?>" required>
                    </div>

                    <div class="field">
                        <label for="file_bukti">Bukti Transaksi</label>
                        <input type="file" id="file_bukti" name="file_bukti" accept=".jpg,.jpeg,.png,.gif,.pdf">
                        <small>Format: JPG, JPEG, PNG, GIF, PDF. Maksimal 10 MB.</small>
                    </div>

                    <button type="submit" class="submit">Simpan Transaksi</button>
                <?php echo form_close(); ?>
            </div>

            <div class="panel">
                <h2>Riwayat Transaksi</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Keterangan</th>
                            <th>Jenis</th>
                            <th>Jumlah</th>
                            <th>File</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($transaksi)): ?>
                            <tr>
                                <td colspan="6" class="empty">Belum ada transaksi.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($transaksi as $item): ?>
                                <tr>
                                    <td><?php echo !empty($item->tanggal) ? html_escape($item->tanggal) : '-'; ?></td>
                                    <td><?php echo isset($item->keterangan) ? html_escape($item->keterangan) : '-'; ?></td>
                                    <td><?php echo isset($item->jenis) ? html_escape($item->jenis) : '-'; ?></td>
                                    <td>Rp <?php echo number_format(isset($item->jumlah) ? (float) $item->jumlah : 0, 0, ',', '.'); ?></td>
                                    <td><?php echo !empty($item->file_bukti) ? html_escape($item->file_bukti) : '-'; ?></td>
                                    <td>
                                        <a class="delete-link" href="<?php echo site_url('dashboard/hapus/' . (isset($item->id) ? (int) $item->id : 0)); ?>" onclick="return confirm('Hapus transaksi ini?');">Hapus</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
