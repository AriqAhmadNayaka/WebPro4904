<?php
// Mencegah file controller ini diakses langsung tanpa melalui CodeIgniter.
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . 'core/MX_Controller.php';

/**
 * Properti ini dipakai untuk memvalidasi data form transaksi.
 * @property CI_Form_validation $form_validation
 * Properti ini dipakai untuk mengambil input dari request POST/GET.
 * @property CI_Input $input
 * Properti ini dipakai untuk memuat model, helper, library, dan view.
 * @property CI_Loader $load
 * Properti ini dipakai untuk menyimpan session dan flash message.
 * @property CI_Session $session
 * Properti ini adalah model untuk operasi data transaksi.
 * @property Transaksi_model $Transaksi_model
 * Properti ini adalah library upload milik CodeIgniter.
 * @property CI_Upload $upload
 */
// Mendefinisikan controller Dashboard untuk halaman utama transaksi.
class Dashboard extends MX_Controller {

    // Menyimpan path folder upload bukti transaksi di dalam root project.
    protected $upload_directory = FCPATH . 'uploads/bukti/';
    // Menyimpan batas maksimal ukuran file upload dalam satuan KB.
    protected $max_upload_size_kb = 10240;

    // Constructor akan dijalankan otomatis setiap kali controller Dashboard dipanggil.
    public function __construct()
    {
        // Menjalankan constructor bawaan dari CI_Controller.
        parent::__construct();
        // Memuat model transaksi agar method database bisa dipakai di controller ini.
        $this->load->model('Transaksi_model');
        // Memuat helper URL dan form untuk redirect dan form handling.
        $this->load->helper(array('url', 'form'));
        // Memuat library validasi form, session, dan upload.
        $this->load->library(array('form_validation', 'session', 'upload'));

        // Memastikan hanya user yang sudah login yang bisa mengakses dashboard.
        $this->ensure_authenticated();
    }

    // Method utama untuk menampilkan halaman dashboard.
    public function index()
    {
        // Mengambil seluruh data transaksi dari model.
        $transactions = $this->Transaksi_model->get_all();

        // Menyiapkan judul halaman dashboard.
        $data['title'] = 'Dashboard Transaksi';
        // Mengambil username dari session untuk ditampilkan di view.
        $data['username'] = (string) $this->session->userdata('username');
        // Mengirim daftar transaksi ke view.
        $data['transaksi'] = $transactions;
        // Menghitung ringkasan total transaksi untuk ditampilkan di dashboard.
        $data['summary'] = $this->Transaksi_model->get_summary($transactions);
        // Mengambil data form terakhir dari flashdata jika sebelumnya gagal submit.
        $data['form_data'] = (array) $this->session->flashdata('form_data');
        // Mengambil pesan error dari flashdata.
        $data['error'] = (string) $this->session->flashdata('error');
        // Mengambil pesan sukses dari flashdata.
        $data['success'] = (string) $this->session->flashdata('success');

        // Menampilkan view dashboard beserta data yang sudah disiapkan.
        $this->load->view('dashboard', $data);
    }

    // Method untuk menyimpan transaksi baru dari form dashboard.
    public function simpan()
    {
        // Menetapkan aturan validasi untuk field tanggal.
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'trim|required');
        // Menetapkan aturan validasi untuk field keterangan.
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'trim|required|max_length[255]');
        // Menetapkan aturan validasi untuk field jenis transaksi.
        $this->form_validation->set_rules('jenis', 'Jenis', 'trim|required|in_list[pemasukan,pengeluaran]');
        // Menetapkan aturan validasi untuk field jumlah nominal transaksi.
        $this->form_validation->set_rules('jumlah', 'Jumlah', 'trim|required|numeric|greater_than[0]');

        // Mengambil semua input form lalu membersihkan nilainya.
        $form_data = array(
            // Mengambil nilai tanggal dari request POST.
            'tanggal' => trim((string) $this->input->post('tanggal', TRUE)),
            // Mengambil nilai keterangan dari request POST.
            'keterangan' => trim((string) $this->input->post('keterangan', TRUE)),
            // Mengambil nilai jenis dari request POST.
            'jenis' => trim((string) $this->input->post('jenis', TRUE)),
            // Mengambil nilai jumlah dari request POST.
            'jumlah' => trim((string) $this->input->post('jumlah', TRUE))
        );

        // Menyimpan data form ke flashdata agar input tidak hilang jika validasi gagal.
        $this->session->set_flashdata('form_data', $form_data);

        // Jika validasi gagal, kirim pesan error dan kembali ke dashboard.
        if ($this->form_validation->run() === FALSE) {
            // Menyimpan pesan error hasil validasi.
            $this->session->set_flashdata('error', $this->validation_message('Data transaksi belum valid.'));
            // Redirect kembali ke halaman dashboard.
            redirect('dashboard');
            // Menghentikan eksekusi method setelah redirect.
            return;
        }

        // Menyusun data transaksi yang siap disimpan ke database.
        $data = array(
            // Menyimpan tanggal transaksi.
            'tanggal' => $form_data['tanggal'],
            // Menyimpan keterangan transaksi.
            'keterangan' => $form_data['keterangan'],
            // Menyimpan jenis transaksi.
            'jenis' => $form_data['jenis'],
            // Mengubah jumlah ke float agar formatnya sesuai untuk penyimpanan.
            'jumlah' => (float) $form_data['jumlah']
        );

        // Jika user mengunggah file bukti, jalankan proses upload terlebih dahulu.
        if (!empty($_FILES['file_bukti']['name'])) {
            // Memanggil method internal untuk memproses upload file.
            $upload_result = $this->upload_bukti();

            // Jika upload gagal, simpan pesan error dan kembali ke dashboard.
            if (!$upload_result['status']) {
                // Menyimpan pesan error upload.
                $this->session->set_flashdata('error', $upload_result['error']);
                // Redirect kembali ke halaman dashboard.
                redirect('dashboard');
                // Menghentikan eksekusi method setelah redirect.
                return;
            }

            // Jika upload berhasil, simpan nama file ke data transaksi.
            $data['file_bukti'] = $upload_result['file_name'];
        }

        // Menyimpan transaksi ke database melalui model.
        $insert_id = $this->Transaksi_model->insert($data);

        // Jika insert berhasil, hapus data form lama dan kirim pesan sukses.
        if ($insert_id) {
            // Menghapus data form lama yang sempat disimpan di flashdata/session.
            $this->session->unset_userdata('form_data');
            // Menyimpan pesan sukses.
            $this->session->set_flashdata('success', 'Transaksi berhasil disimpan.');
        } else {
            // Jika insert gagal, simpan pesan error.
            $this->session->set_flashdata('error', 'Transaksi gagal disimpan.');
        }

        // Setelah proses selesai, kembali ke halaman dashboard.
        redirect('dashboard');
    }

    // Method untuk menghapus transaksi berdasarkan id.
    public function hapus($id = NULL)
    {
        // Mengubah nilai id menjadi integer agar lebih aman.
        $id = (int) $id;

        // Jika id tidak valid, kirim pesan error lalu kembali ke dashboard.
        if ($id < 1) {
            // Menyimpan pesan error karena id transaksi tidak valid.
            $this->session->set_flashdata('error', 'ID transaksi tidak valid.');
            // Redirect ke halaman dashboard.
            redirect('dashboard');
            // Menghentikan eksekusi method setelah redirect.
            return;
        }

        // Mengambil data transaksi berdasarkan id yang akan dihapus.
        $transaction = $this->Transaksi_model->get_by_id($id);

        // Jika transaksi tidak ditemukan, kirim pesan error lalu kembali.
        if ($transaction === NULL) {
            // Menyimpan pesan error karena transaksi tidak ditemukan.
            $this->session->set_flashdata('error', 'Transaksi tidak ditemukan.');
            // Redirect ke halaman dashboard.
            redirect('dashboard');
            // Menghentikan eksekusi method setelah redirect.
            return;
        }

        // Jika transaksi punya file bukti, siapkan juga proses penghapusan filenya.
        if (!empty($transaction->file_bukti)) {
            // Menyusun path file lengkap dari folder upload dan nama file.
            $file_path = $this->upload_directory . $transaction->file_bukti;

            // Jika file fisiknya benar-benar ada, hapus dari server.
            if (is_file($file_path)) {
                // Menghapus file bukti dari filesystem.
                unlink($file_path);
            }
        }

        // Menjalankan delete transaksi di database.
        if ($this->Transaksi_model->delete($id)) {
            // Jika berhasil, simpan pesan sukses.
            $this->session->set_flashdata('success', 'Transaksi berhasil dihapus.');
        } else {
            // Jika gagal, simpan pesan error.
            $this->session->set_flashdata('error', 'Transaksi gagal dihapus.');
        }

        // Kembali ke halaman dashboard setelah proses hapus selesai.
        redirect('dashboard');
    }

    // Method internal untuk memastikan hanya user login yang boleh mengakses dashboard.
    protected function ensure_authenticated()
    {
        // Jika session menandakan user sudah login, hentikan pengecekan di sini.
        if ($this->session->userdata('logged_in') === TRUE || $this->session->userdata('status') === 'login') {
            // Keluar dari method karena user valid.
            return;
        }

        // Jika belum login, simpan pesan error.
        $this->session->set_flashdata('error', 'Silakan login terlebih dahulu.');
        // Arahkan user ke halaman login.
        redirect('auth/login');
    }

    // Method internal untuk memproses upload file bukti transaksi.
    protected function upload_bukti()
    {
        // Jika field file_bukti tidak ada di request, kembalikan error.
        if (!isset($_FILES['file_bukti'])) {
            // Mengembalikan status gagal dan pesan error.
            return array(
                // Menandakan proses upload gagal.
                'status' => FALSE,
                // Menyertakan pesan error yang akan ditampilkan ke user.
                'error' => 'File bukti tidak ditemukan pada request.'
            );
        }

        // Jika PHP menolak file karena ukuran melebihi batas, kembalikan pesan khusus.
        if ($_FILES['file_bukti']['error'] === UPLOAD_ERR_INI_SIZE || $_FILES['file_bukti']['error'] === UPLOAD_ERR_FORM_SIZE) {
            // Mengembalikan status gagal dan pesan error ukuran file.
            return array(
                // Menandakan proses upload gagal.
                'status' => FALSE,
                // Pesan error maksimal ukuran file.
                'error' => 'Ukuran file terlalu besar. Maksimal upload adalah 10 MB.'
            );
        }

        // Jika folder upload belum ada, coba buat folder tersebut terlebih dahulu.
        if (!is_dir($this->upload_directory)) {
            // Jika mkdir gagal dan folder tetap belum ada, kembalikan error.
            if (!mkdir($this->upload_directory, 0777, TRUE) && !is_dir($this->upload_directory)) {
                // Mengembalikan status gagal dan pesan error folder.
                return array(
                    // Menandakan proses upload gagal.
                    'status' => FALSE,
                    // Menyertakan pesan error bahwa folder upload tidak bisa dibuat.
                    'error' => 'Folder upload bukti tidak bisa dibuat.'
                );
            }
        }

        // Menentukan lokasi folder tujuan upload.
        $config['upload_path'] = $this->upload_directory;
        // Menentukan tipe file yang diizinkan.
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        // Menentukan batas maksimal ukuran file dalam KB.
        $config['max_size'] = $this->max_upload_size_kb;
        // Mengaktifkan nama file acak agar tidak bentrok.
        $config['encrypt_name'] = TRUE;

        // Menginisialisasi library upload dengan konfigurasi di atas.
        $this->upload->initialize($config);

        // Jika upload file berhasil, ambil data file hasil upload.
        if ($this->upload->do_upload('file_bukti')) {
            // Mengambil metadata file hasil upload.
            $upload_data = $this->upload->data();

            // Mengembalikan status sukses dan nama file hasil upload.
            return array(
                // Menandakan proses upload berhasil.
                'status' => TRUE,
                // Mengirim nama file untuk disimpan ke database.
                'file_name' => $upload_data['file_name']
            );
        }

        // Jika upload gagal, kembalikan status gagal dan pesan error yang sudah dinormalisasi.
        return array(
            // Menandakan proses upload gagal.
            'status' => FALSE,
            // Menyimpan pesan error upload agar lebih mudah dibaca user.
            'error' => $this->normalize_upload_error($this->upload->display_errors('', ''))
        );
    }

    // Method internal untuk mengubah pesan error upload bawaan menjadi pesan yang lebih ramah.
    protected function normalize_upload_error($message)
    {
        // Jika pesan error mengandung indikasi ukuran terlalu besar, ganti dengan pesan Indonesia yang lebih jelas.
        if (stripos($message, 'larger than the permitted size') !== FALSE) {
            // Mengembalikan pesan error ukuran file.
            return 'Ukuran file terlalu besar. Maksimal upload adalah 10 MB.';
        }

        // Jika pesan error mengandung indikasi tipe file tidak diizinkan, ganti dengan pesan yang lebih jelas.
        if (stripos($message, 'filetype you are attempting to upload is not allowed') !== FALSE) {
            // Mengembalikan pesan error format file.
            return 'Format file tidak didukung. Gunakan JPG, JPEG, PNG, GIF, atau PDF.';
        }

        // Jika pesan tidak termasuk dua kondisi di atas, kembalikan pesan asli.
        return $message;
    }

    // Method internal untuk merangkum error validasi form menjadi satu string.
    protected function validation_message($default_message)
    {
        // Mengambil semua pesan error validasi dalam bentuk array.
        $errors = $this->form_validation->error_array();

        // Jika tidak ada error detail, pakai pesan default; jika ada, gabungkan semua pesan jadi satu kalimat.
        return empty($errors) ? $default_message : implode(' ', $errors);
    }
}
