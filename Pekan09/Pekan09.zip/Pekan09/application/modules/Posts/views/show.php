<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo html_escape(isset($title) ? $title : 'Detail Post'); ?></title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f5f7fb; color: #172033; }
        .page { max-width: 760px; margin: 0 auto; padding: 28px 18px; }
        article { background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 22px; }
        .meta { color: #64748b; }
        a { display: inline-block; margin-top: 16px; color: #2563eb; font-weight: 700; text-decoration: none; }
    </style>
</head>
<body>
    <main class="page">
        <article>
            <h1><?php echo html_escape($post->title); ?></h1>
            <p class="meta">Oleh <?php echo html_escape($post->author); ?></p>
            <?php if (!empty($post->image_url)): ?>
                <img src="<?php echo html_escape($post->image_url); ?>" alt="" style="max-width:100%;border-radius:8px;">
            <?php endif; ?>
            <p><?php echo nl2br(html_escape($post->article)); ?></p>
            <a href="<?php echo site_url('posts'); ?>">Kembali</a>
        </article>
    </main>
</body>
</html>
