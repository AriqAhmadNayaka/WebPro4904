<?php $posts = isset($posts) && is_array($posts) ? $posts : array(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo html_escape(isset($title) ? $title : 'Posts'); ?></title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f5f7fb; color: #172033; }
        .page { max-width: 1000px; margin: 0 auto; padding: 28px 18px; }
        .top { display: flex; justify-content: space-between; align-items: center; gap: 16px; margin-bottom: 18px; }
        .button { display: inline-block; padding: 10px 14px; border-radius: 8px; background: #2563eb; color: #fff; text-decoration: none; font-weight: 700; }
        .alert { padding: 12px 14px; border-radius: 8px; margin-bottom: 12px; }
        .success { background: #dcfce7; color: #166534; }
        .error { background: #fee2e2; color: #991b1b; }
        .grid { display: grid; gap: 14px; }
        .card { background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 18px; }
        .meta { color: #64748b; font-size: 14px; }
        .actions { display: flex; gap: 10px; margin-top: 12px; }
        .actions a { color: #2563eb; font-weight: 700; text-decoration: none; }
        .actions .delete { color: #dc2626; }
    </style>
</head>
<body>
    <main class="page">
        <div class="top">
            <div>
                <h1>Posts</h1>
                <p class="meta">CRUD sederhana dari controller Posts.</p>
            </div>
            <a class="button" href="<?php echo site_url('posts/create'); ?>">Tambah Post</a>
        </div>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert success"><?php echo html_escape($this->session->flashdata('success')); ?></div>
        <?php endif; ?>
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert error"><?php echo html_escape($this->session->flashdata('error')); ?></div>
        <?php endif; ?>

        <section class="grid">
            <?php if (empty($posts)): ?>
                <div class="card">Belum ada post.</div>
            <?php endif; ?>

            <?php foreach ($posts as $post): ?>
                <article class="card">
                    <h2><?php echo html_escape($post->title); ?></h2>
                    <p class="meta">Oleh <?php echo html_escape($post->author); ?></p>
                    <p><?php echo nl2br(html_escape(substr($post->article, 0, 220))); ?></p>
                    <div class="actions">
                        <a href="<?php echo site_url('posts/show/' . $post->id); ?>">Detail</a>
                        <a href="<?php echo site_url('posts/edit/' . $post->id); ?>">Edit</a>
                        <a class="delete" href="<?php echo site_url('posts/delete/' . $post->id); ?>" onclick="return confirm('Hapus post ini?')">Hapus</a>
                    </div>
                </article>
            <?php endforeach; ?>
        </section>
    </main>
</body>
</html>
