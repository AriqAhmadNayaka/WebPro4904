<?php $errors = $this->session->flashdata('validation_errors'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo html_escape(isset($title) ? $title : 'Edit Post'); ?></title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f5f7fb; color: #172033; }
        .page { max-width: 760px; margin: 0 auto; padding: 28px 18px; }
        form { background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; }
        label { display: block; margin: 14px 0 8px; font-weight: 700; }
        input, textarea { width: 100%; box-sizing: border-box; padding: 11px 12px; border: 1px solid #cbd5e1; border-radius: 8px; }
        textarea { min-height: 160px; resize: vertical; }
        button, .link { display: inline-block; margin-top: 16px; padding: 10px 14px; border-radius: 8px; border: 0; background: #2563eb; color: #fff; text-decoration: none; font-weight: 700; cursor: pointer; }
        .link { background: #64748b; margin-left: 8px; }
        .error { padding: 12px 14px; border-radius: 8px; background: #fee2e2; color: #991b1b; margin-bottom: 12px; }
    </style>
</head>
<body>
    <main class="page">
        <h1>Edit Post</h1>
        <?php if ($errors): ?><div class="error"><?php echo $errors; ?></div><?php endif; ?>
        <?php echo form_open_multipart('posts/update/' . $post->id); ?>
            <label for="title">Title</label>
            <input type="text" id="title" name="title" value="<?php echo html_escape($post->title); ?>">

            <label for="author">Author</label>
            <input type="text" id="author" name="author" value="<?php echo html_escape($post->author); ?>">

            <label for="article">Article</label>
            <textarea id="article" name="article"><?php echo html_escape($post->article); ?></textarea>

            <label for="image">Image</label>
            <input type="file" id="image" name="image" accept=".jpg,.jpeg,.png">

            <button type="submit">Update</button>
            <a class="link" href="<?php echo site_url('posts'); ?>">Kembali</a>
        <?php echo form_close(); ?>
    </main>
</body>
</html>
