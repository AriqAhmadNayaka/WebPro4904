<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    protected $table = 'users';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_by_id($id)
    {
        return $this->db
            ->limit(1)
            ->get_where($this->table, array('id' => (int) $id))
            ->row();
    }

    public function get_by_username($username)
    {
        return $this->db
            ->limit(1)
            ->get_where($this->table, array('username' => trim((string) $username)))
            ->row();
    }

    public function insert(array $data)
    {
        if (isset($data['password'])) {
            $data['password'] = password_hash((string) $data['password'], PASSWORD_DEFAULT);
        }

        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }
}
