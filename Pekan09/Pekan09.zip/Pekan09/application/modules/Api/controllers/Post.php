<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . 'core/MX_Controller.php';

class Post extends MX_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Post_model');
        $this->load->library('Jwt');
        $this->load->helper('url');
    }

    public function index($id = NULL)
    {
        $payload = $this->require_token();

        if ($payload === FALSE) {
            return;
        }

        $method = $this->input->method(TRUE);

        if ($method === 'GET') {
            return $id === NULL ? $this->all() : $this->show($id);
        }

        if ($method === 'POST') {
            return $this->create();
        }

        if ($method === 'PUT' || $method === 'PATCH') {
            return $this->update_post($id);
        }

        if ($method === 'DELETE') {
            return $this->delete_post($id);
        }

        return $this->json_response(array('status' => FALSE, 'message' => 'Method tidak diizinkan.'), 405);
    }

    protected function all()
    {
        return $this->json_response(array('status' => TRUE, 'data' => $this->Post_model->get_all()));
    }

    protected function show($id)
    {
        $post = $this->Post_model->get_by_id($id);

        if (!$post) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Post tidak ditemukan.'), 404);
        }

        return $this->json_response(array('status' => TRUE, 'data' => $post));
    }

    protected function create()
    {
        $data = $this->request_data();
        $payload = $this->post_payload($data);

        if ($payload['title'] === '' || $payload['author'] === '' || $payload['article'] === '') {
            return $this->json_response(array('status' => FALSE, 'message' => 'Title, author, dan article wajib diisi.'), 422);
        }

        $payload['created_at'] = date('Y-m-d H:i:s');
        $payload['updated_at'] = date('Y-m-d H:i:s');
        $id = $this->Post_model->insert($payload);

        if (!$id) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Post gagal dibuat.'), 500);
        }

        return $this->json_response(array('status' => TRUE, 'message' => 'Post berhasil dibuat.', 'id' => $id), 201);
    }

    protected function update_post($id)
    {
        if ($id === NULL || !$this->Post_model->exists($id)) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Post tidak ditemukan.'), 404);
        }

        $data = $this->request_data();
        $payload = array('updated_at' => date('Y-m-d H:i:s'));

        foreach (array('title', 'author', 'article', 'image') as $field) {
            if (isset($data[$field])) {
                $payload[$field] = trim((string) $data[$field]);
            }
        }

        if ($this->Post_model->update($id, $payload)) {
            return $this->json_response(array('status' => TRUE, 'message' => 'Post berhasil diperbarui.'));
        }

        return $this->json_response(array('status' => FALSE, 'message' => 'Post gagal diperbarui.'), 500);
    }

    protected function delete_post($id)
    {
        if ($id === NULL || !$this->Post_model->exists($id)) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Post tidak ditemukan.'), 404);
        }

        if ($this->Post_model->delete($id)) {
            return $this->json_response(array('status' => TRUE, 'message' => 'Post berhasil dihapus.'));
        }

        return $this->json_response(array('status' => FALSE, 'message' => 'Post gagal dihapus.'), 500);
    }

    protected function post_payload(array $data)
    {
        return array(
            'title' => isset($data['title']) ? trim((string) $data['title']) : '',
            'author' => isset($data['author']) ? trim((string) $data['author']) : '',
            'article' => isset($data['article']) ? trim((string) $data['article']) : '',
            'image' => isset($data['image']) ? trim((string) $data['image']) : ''
        );
    }

    protected function require_token()
    {
        $header = $this->input->get_request_header('Authorization', TRUE);

        if (!$header || stripos($header, 'Bearer ') !== 0) {
            $this->json_response(array('status' => FALSE, 'message' => 'Token tidak ditemukan.'), 401);
            return FALSE;
        }

        $payload = $this->jwt->decode(trim(substr($header, 7)));

        if ($payload === FALSE) {
            $this->json_response(array('status' => FALSE, 'message' => 'Token tidak valid atau sudah kedaluwarsa.'), 401);
            return FALSE;
        }

        return $payload;
    }

    protected function request_data()
    {
        $json = json_decode($this->input->raw_input_stream, TRUE);
        return is_array($json) ? $json : $this->input->post(NULL, TRUE);
    }

    protected function json_response(array $payload, $status = 200)
    {
        return $this->output
            ->set_status_header($status)
            ->set_content_type('application/json', 'utf-8')
            ->set_output(json_encode($payload, JSON_PRETTY_PRINT));
    }
}
