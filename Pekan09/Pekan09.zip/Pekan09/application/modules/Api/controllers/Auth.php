<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . 'core/MX_Controller.php';

class Auth extends MX_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Auth_model');
        $this->load->library('Jwt');
        $this->load->helper('url');
    }

    public function register()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            return $this->json_response(array('status' => FALSE, 'message' => 'Method tidak diizinkan.'), 405);
        }

        $data = $this->request_data();
        $username = isset($data['username']) ? trim((string) $data['username']) : '';
        $password = isset($data['password']) ? (string) $data['password'] : '';
        $email = isset($data['email']) ? trim((string) $data['email']) : '';
        $name = isset($data['name']) ? trim((string) $data['name']) : '';

        if ($username === '' || $password === '') {
            return $this->json_response(array('status' => FALSE, 'message' => 'Username dan password wajib diisi.'), 422);
        }

        if (strlen($password) < 6) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Password minimal 6 karakter.'), 422);
        }

        if ($this->Auth_model->username_exists($username)) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Username sudah terdaftar.'), 409);
        }

        if ($email !== '' && $this->Auth_model->email_exists($email)) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Email sudah terdaftar.'), 409);
        }

        $user_id = $this->Auth_model->create_user(array(
            'name' => $name,
            'email' => $email,
            'username' => $username,
            'password' => $password,
            'phone' => isset($data['phone']) ? $data['phone'] : '',
            'address' => isset($data['address']) ? $data['address'] : ''
        ));

        if (!$user_id) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Registrasi gagal.'), 500);
        }

        return $this->json_response(array(
            'status' => TRUE,
            'message' => 'Registrasi berhasil.',
            'data' => array('id' => $user_id, 'username' => $username)
        ), 201);
    }

    public function login()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            return $this->json_response(array('status' => FALSE, 'message' => 'Method tidak diizinkan.'), 405);
        }

        $data = $this->request_data();
        $username = isset($data['username']) ? trim((string) $data['username']) : '';
        $password = isset($data['password']) ? (string) $data['password'] : '';
        $user = $this->Auth_model->authenticate($username, $password);

        if ($user === NULL) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Username atau password salah.'), 401);
        }

        $payload = array(
            'sub' => isset($user->id) ? (int) $user->id : 0,
            'username' => isset($user->username) ? $user->username : $username,
            'iat' => time(),
            'exp' => time() + 86400
        );

        return $this->json_response(array(
            'status' => TRUE,
            'message' => 'Login berhasil.',
            'token' => $this->jwt->encode($payload),
            'token_type' => 'Bearer'
        ));
    }

    public function me()
    {
        $payload = $this->require_token();

        if ($payload === FALSE) {
            return;
        }

        return $this->json_response(array('status' => TRUE, 'data' => $payload));
    }

    public function logout()
    {
        return $this->json_response(array(
            'status' => TRUE,
            'message' => 'Logout berhasil. Hapus token di client/Postman.'
        ));
    }

    protected function require_token()
    {
        $header = $this->input->get_request_header('Authorization', TRUE);

        if (!$header || stripos($header, 'Bearer ') !== 0) {
            $this->json_response(array('status' => FALSE, 'message' => 'Token tidak ditemukan.'), 401);
            return FALSE;
        }

        $token = trim(substr($header, 7));
        $payload = $this->jwt->decode($token);

        if ($payload === FALSE) {
            $this->json_response(array('status' => FALSE, 'message' => 'Token tidak valid atau sudah kedaluwarsa.'), 401);
            return FALSE;
        }

        return $payload;
    }

    protected function request_data()
    {
        $json = json_decode($this->input->raw_input_stream, TRUE);
        return is_array($json) ? $json : $this->input->post(NULL, TRUE);
    }

    protected function json_response(array $payload, $status = 200)
    {
        return $this->output
            ->set_status_header($status)
            ->set_content_type('application/json', 'utf-8')
            ->set_output(json_encode($payload, JSON_PRETTY_PRINT));
    }
}
