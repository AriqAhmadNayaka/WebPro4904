<?php
// Mencegah file controller ini diakses langsung tanpa melalui CodeIgniter.
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . 'core/MX_Controller.php';

/**
 * Properti ini berisi model autentikasi yang dimuat oleh CodeIgniter.
 * @property Auth_model $Auth_model
 * Properti ini dipakai untuk validasi form login dan register.
 * @property CI_Form_validation $form_validation
 * Properti ini dipakai untuk mengambil data input GET/POST.
 * @property CI_Input $input
 * Properti ini dipakai untuk memuat view, helper, model, dan library.
 * @property CI_Loader $load
 * Properti ini dipakai untuk menyimpan session dan flashdata.
 * @property CI_Session $session
 */
// Mendefinisikan controller Auth yang menangani login, register, dan logout.
class Auth extends MX_Controller {

    // Constructor akan dijalankan otomatis saat controller dipanggil.
    public function __construct()
    {
        // Menjalankan constructor bawaan CI_Controller.
        parent::__construct();
        // Memuat model Auth_model agar fungsi autentikasi bisa dipakai di controller ini.
        $this->load->model('Auth_model');
        // Memuat helper URL, form, dan cookie untuk kebutuhan redirect, form, dan remember me.
        $this->load->helper(array('url', 'form', 'cookie'));
        // Memuat library validasi form dan session untuk proses login/register.
        $this->load->library(array('form_validation', 'session'));
    }

    // Method default controller auth, biasanya dipakai saat mengakses /auth.
    public function index()
    {
        // Jika user sudah login, langsung arahkan ke dashboard.
        if ($this->is_logged_in()) {
            // Redirect ke halaman dashboard.
            redirect('dashboard');
            // Hentikan proses method setelah redirect.
            return;
        }

        // Jika belum login, tampilkan halaman login.
        $this->login();
    }

    // Method untuk menampilkan halaman login.
    public function login()
    {
        // Jika user sudah login, tidak perlu melihat form login lagi.
        if ($this->is_logged_in()) {
            // Redirect ke dashboard.
            redirect('dashboard');
            // Hentikan eksekusi method.
            return;
        }

        // Mengambil data form login terakhir dari flashdata agar input tidak hilang setelah redirect.
        $form_data = $this->session->flashdata('auth_form_data');
        // Mengambil username yang disimpan di cookie remember me.
        $remembered_username = get_cookie('remember_user', TRUE);

        // Menentukan nilai default field username dari flashdata atau cookie.
        $data['username_value'] = isset($form_data['username']) && $form_data['username'] !== ''
            ? $form_data['username']
            : (string) $remembered_username;
        // Menentukan apakah checkbox remember me perlu dicentang otomatis.
        $data['remember_me'] = !empty($form_data['remember']) || !empty($remembered_username);
        // Mengambil pesan error dari flashdata.
        $data['error'] = (string) $this->session->flashdata('error');
        // Mengambil pesan sukses dari flashdata.
        $data['success'] = (string) $this->session->flashdata('success');

        // Menampilkan view login dan mengirimkan data yang sudah disiapkan.
        $this->load->view('login', $data);
    }

    // Method untuk menampilkan halaman register.
    public function register()
    {
        // Jika user sudah login, tidak perlu melihat form register lagi.
        if ($this->is_logged_in()) {
            // Redirect ke dashboard.
            redirect('dashboard');
            // Hentikan eksekusi method.
            return;
        }

        // Mengambil data form register terakhir dari flashdata.
        $form_data = $this->session->flashdata('register_form_data');

        // Menyiapkan data form agar input yang gagal validasi bisa muncul lagi.
        $data['form_data'] = is_array($form_data) ? $form_data : array();
        // Mengambil pesan error dari flashdata.
        $data['error'] = (string) $this->session->flashdata('error');
        // Mengambil pesan sukses dari flashdata.
        $data['success'] = (string) $this->session->flashdata('success');

        // Menampilkan view register beserta data yang sudah disiapkan.
        $this->load->view('register', $data);
    }

    // Method untuk memproses submit form login.
    public function proses_login()
    {
        // Jika user sudah login, tidak perlu memproses login lagi.
        if ($this->is_logged_in()) {
            // Redirect ke dashboard.
            redirect('dashboard');
            // Hentikan eksekusi method.
            return;
        }

        // Menambahkan aturan validasi untuk field username.
        $this->form_validation->set_rules('username', 'Username', 'trim|required|max_length[100]');
        // Menambahkan aturan validasi untuk field password.
        $this->form_validation->set_rules('password', 'Password', 'required');

        // Mengambil username dari form POST, membersihkan spasi, dan memfilter XSS.
        $username = trim((string) $this->input->post('username', TRUE));
        // Mengambil password dari form POST tanpa filter tambahan agar hash password tetap akurat.
        $password = (string) $this->input->post('password');
        // Menentukan apakah checkbox remember me dicentang.
        $remember = $this->input->post('remember') ? 1 : 0;

        // Menyimpan username dan status remember me ke flashdata untuk dipakai ulang jika login gagal.
        $this->session->set_flashdata('auth_form_data', array(
            // Menyimpan username yang diinput user.
            'username' => $username,
            // Menyimpan status checkbox remember me.
            'remember' => $remember
        ));

        // Jika validasi form gagal, kirim pesan error lalu kembali ke halaman login.
        if ($this->form_validation->run() === FALSE) {
            // Menyimpan pesan error validasi ke flashdata.
            $this->session->set_flashdata('error', $this->validation_message('Data login belum lengkap.'));
            // Kembali ke halaman login.
            redirect('auth/login');
            // Hentikan eksekusi method.
            return;
        }

        // Meminta model untuk mengecek apakah username dan password valid.
        $user = $this->Auth_model->authenticate($username, $password);

        // Jika model mengembalikan NULL, berarti login gagal.
        if ($user === NULL) {
            // Menyimpan pesan error login.
            $this->session->set_flashdata('error', 'Username atau password tidak cocok.');
            // Kembali ke halaman login.
            redirect('auth/login');
            // Hentikan eksekusi method.
            return;
        }

        // Menyimpan data penting user ke session agar dianggap sudah login.
        $this->session->set_userdata(array(
            // Menyimpan id user jika tersedia.
            'user_id' => isset($user->id) ? $user->id : NULL,
            // Menyimpan username user.
            'username' => isset($user->username) ? $user->username : $username,
            // Menyimpan nama user, atau fallback ke username jika kolom nama tidak ada.
            'name' => isset($user->name) ? $user->name : (isset($user->username) ? $user->username : $username),
            // Menyimpan status login versi lama agar kompatibel dengan kode lain.
            'status' => 'login',
            // Menyimpan flag login versi baru.
            'logged_in' => TRUE
        ));

        // Jika remember me dicentang, simpan username ke cookie selama 30 hari.
        if ($remember) {
            // Menulis cookie remember_user ke browser.
            $this->input->set_cookie(array(
                // Nama cookie yang disimpan.
                'name' => 'remember_user',
                // Nilai cookie berupa username user.
                'value' => isset($user->username) ? $user->username : $username,
                // Masa berlaku cookie 30 hari.
                'expire' => 86400 * 30,
                // Cookie berlaku di seluruh path aplikasi.
                'path' => '/',
                // Cookie tidak dipaksa HTTPS karena aplikasi lokal.
                'secure' => FALSE,
                // Cookie tidak bisa diakses JavaScript.
                'httponly' => TRUE,
                // Mengatur SameSite agar lebih aman.
                'samesite' => 'Lax'
            ));
        } else {
            // Jika remember me tidak dicentang, hapus cookie lama jika ada.
            delete_cookie('remember_user');
        }

        // Menyimpan pesan sukses login.
        $this->session->set_flashdata('success', 'Login berhasil. Selamat datang.');
        // Mengarahkan user ke dashboard setelah login berhasil.
        redirect('dashboard');
    }

    // Method untuk memproses submit form register.
    public function proses_register()
    {
        // Jika user sudah login, tidak perlu membuat akun lagi dari halaman ini.
        if ($this->is_logged_in()) {
            // Redirect ke dashboard.
            redirect('dashboard');
            // Hentikan eksekusi method.
            return;
        }

        // Menambahkan aturan validasi untuk nama lengkap.
        $this->form_validation->set_rules('name', 'Nama Lengkap', 'trim|required|max_length[150]');
        // Menambahkan aturan validasi untuk email.
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|max_length[150]');
        // Menambahkan aturan validasi untuk username.
        $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[3]|max_length[100]|alpha_dash');
        // Menambahkan aturan validasi untuk password.
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        // Menambahkan aturan validasi untuk nomor telepon.
        $this->form_validation->set_rules('phone', 'Nomor Telepon', 'trim|required|regex_match[/^[0-9]{10,15}$/]');
        // Menambahkan aturan validasi untuk alamat.
        $this->form_validation->set_rules('address', 'Alamat', 'trim|required|max_length[255]');

        // Mengambil seluruh input form register yang perlu dipertahankan jika terjadi error.
        $form_data = array(
            // Mengambil nama lengkap dari form.
            'name' => trim((string) $this->input->post('name', TRUE)),
            // Mengambil email dari form.
            'email' => trim((string) $this->input->post('email', TRUE)),
            // Mengambil username dari form.
            'username' => trim((string) $this->input->post('username', TRUE)),
            // Mengambil nomor telepon dari form.
            'phone' => trim((string) $this->input->post('phone', TRUE)),
            // Mengambil alamat dari form.
            'address' => trim((string) $this->input->post('address', TRUE))
        );

        // Menyimpan data form ke flashdata agar field bisa diisi ulang jika ada error.
        $this->session->set_flashdata('register_form_data', $form_data);

        // Jika validasi gagal, kembali ke halaman register dengan pesan error.
        if ($this->form_validation->run() === FALSE) {
            // Menyimpan pesan error validasi.
            $this->session->set_flashdata('error', $this->validation_message('Data pendaftaran belum lengkap.'));
            // Redirect ke halaman register.
            redirect('auth/register');
            // Hentikan eksekusi method.
            return;
        }

        // Mengecek apakah username sudah dipakai user lain.
        if ($this->Auth_model->username_exists($form_data['username'])) {
            // Menyimpan pesan error jika username sudah ada.
            $this->session->set_flashdata('error', 'Username sudah dipakai. Silakan gunakan username lain.');
            // Kembali ke halaman register.
            redirect('auth/register');
            // Hentikan eksekusi method.
            return;
        }

        // Mengecek apakah email sudah dipakai user lain.
        if ($this->Auth_model->email_exists($form_data['email'])) {
            // Menyimpan pesan error jika email sudah ada.
            $this->session->set_flashdata('error', 'Email sudah dipakai. Silakan gunakan email lain.');
            // Kembali ke halaman register.
            redirect('auth/register');
            // Hentikan eksekusi method.
            return;
        }

        // Meminta model membuat user baru berdasarkan data form register.
        $created_user = $this->Auth_model->create_user(array(
            // Mengirim nama lengkap ke model.
            'name' => $form_data['name'],
            // Mengirim email ke model.
            'email' => $form_data['email'],
            // Mengirim username ke model.
            'username' => $form_data['username'],
            // Mengirim password mentah agar di-hash oleh model.
            'password' => (string) $this->input->post('password'),
            // Mengirim nomor telepon ke model.
            'phone' => $form_data['phone'],
            // Mengirim alamat ke model.
            'address' => $form_data['address']
        ));

        // Jika model gagal membuat user, tampilkan pesan error.
        if (!$created_user) {
            // Menyimpan pesan error pembuatan akun.
            $this->session->set_flashdata('error', 'Akun gagal dibuat. Coba lagi.');
            // Kembali ke halaman register.
            redirect('auth/register');
            // Hentikan eksekusi method.
            return;
        }

        // Menyimpan username user baru ke flashdata agar otomatis muncul di form login.
        $this->session->set_flashdata('auth_form_data', array(
            // Menyimpan username hasil register.
            'username' => $form_data['username'],
            // Remember me default dimatikan setelah register.
            'remember' => 0
        ));
        // Menyimpan pesan sukses register.
        $this->session->set_flashdata('success', 'Pendaftaran berhasil. Silakan login dengan akun baru Anda.');
        // Mengarahkan user ke halaman login.
        redirect('auth/login');
    }

    // Method untuk logout user dari aplikasi.
    public function logout()
    {
        // Menghapus seluruh data session user yang sedang login.
        $this->session->sess_destroy();
        // Mengarahkan user kembali ke halaman login.
        redirect('auth/login');
    }

    // Method helper internal untuk mengecek apakah user sudah login.
    protected function is_logged_in()
    {
        // Mengembalikan TRUE jika salah satu penanda login di session aktif.
        return $this->session->userdata('logged_in') === TRUE
            || $this->session->userdata('status') === 'login';
    }

    // Method helper internal untuk merangkum pesan error validasi.
    protected function validation_message($default_message)
    {
        // Mengambil semua error validasi dalam bentuk array.
        $errors = $this->form_validation->error_array();

        // Jika tidak ada error detail, pakai pesan default; jika ada, gabungkan semua pesan.
        return empty($errors) ? $default_message : implode(' ', $errors);
    }
}
