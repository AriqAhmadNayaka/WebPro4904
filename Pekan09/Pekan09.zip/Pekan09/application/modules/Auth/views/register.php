<?php
$form_data = isset($form_data) && is_array($form_data) ? $form_data : array();
$error = isset($error) ? (string) $error : '';
$success = isset($success) ? (string) $success : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar NaviBiz</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            padding: 28px 18px;
            font-family: Arial, sans-serif;
            background-color: #ebfbfa;
            background-image:
                radial-gradient(circle at 10% 100%, rgba(5, 12, 87, 0.607), rgba(70, 79, 184, 0.281), transparent 40%),
                radial-gradient(circle at 100% 10%, rgba(60, 252, 242, 0.42), rgba(207, 244, 248, 0.756), transparent 60%);
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: #16324f;
        }

        .page {
            max-width: 860px;
            margin: 0 auto;
        }

        .home-link {
            display: inline-block;
            margin-bottom: 18px;
            color: #0d5c9f;
            text-decoration: none;
            font-weight: 700;
        }

        .header {
            text-align: center;
            margin-bottom: 24px;
        }

        .header h1 {
            margin: 0 0 8px;
            color: #ffffff;
            font-size: 44px;
        }

        .header h2 {
            margin: 0;
            color: #ffffff;
            font-size: 22px;
            font-weight: 600;
        }

        .form-container {
            width: 100%;
            display: flex;
            justify-content: center;
        }

        .form-box {
            width: 100%;
            max-width: 420px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .alert {
            padding: 12px 14px;
            border-radius: 12px;
            font-size: 14px;
            line-height: 1.5;
        }

        .alert-error {
            background: #fff1f2;
            border: 1px solid #fecdd3;
            color: #9f1239;
        }

        .alert-success {
            background: #ecfdf5;
            border: 1px solid #a7f3d0;
            color: #065f46;
        }

        .input-card {
            background: #fff;
            border: 1px solid #ccc;
            padding: 12px;
            border-radius: 10px;
            transition: 0.3s ease;
        }

        .input-card:hover {
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
            transform: translateY(-4px);
        }

        .input-card:focus-within {
            border-color: #3a71ff;
            box-shadow: 0 3px 10px rgba(149, 109, 243, 1);
            transform: translateY(-4px);
        }

        .input-card input,
        .input-card textarea {
            width: 100%;
            padding: 8px;
            border: none;
            outline: none;
            font-size: 15px;
            background: transparent;
            font-family: inherit;
        }

        .input-card textarea {
            min-height: 90px;
            resize: vertical;
        }

        button {
            padding: 12px;
            background: #956df3;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.2s ease;
            width: 100%;
            font-weight: 700;
        }

        button:hover {
            background: #7944f5;
        }

        .login-link {
            text-align: center;
            margin-top: 18px;
            color: #475569;
        }

        .login-link a {
            color: #6a0dad;
            text-decoration: none;
            font-weight: 700;
        }

        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="page">
        <a href="<?php echo site_url('auth/login'); ?>" class="home-link">Kembali ke Login</a>

        <div class="header">
            <h1>NaviBiz</h1>
            <h2>Pendaftaran / Registration</h2>
        </div>

        <div class="form-container">
            <div class="form-box">
                <?php if ($error !== ''): ?>
                    <div class="alert alert-error"><?php echo html_escape($error); ?></div>
                <?php endif; ?>

                <?php if ($success !== ''): ?>
                    <div class="alert alert-success"><?php echo html_escape($success); ?></div>
                <?php endif; ?>

                <?php echo form_open('auth/proses_register'); ?>
                    <div class="input-card">
                        <input type="text" name="name" value="<?php echo html_escape(isset($form_data['name']) ? $form_data['name'] : ''); ?>" placeholder="Masukkan nama lengkap" required>
                    </div>

                    <div class="input-card">
                        <input type="email" name="email" value="<?php echo html_escape(isset($form_data['email']) ? $form_data['email'] : ''); ?>" placeholder="Masukkan email (contoh@gmail.com)" required>
                    </div>

                    <div class="input-card">
                        <input type="text" name="username" value="<?php echo html_escape(isset($form_data['username']) ? $form_data['username'] : ''); ?>" placeholder="Buat Nama Pengguna" required>
                    </div>

                    <div class="input-card">
                        <input type="password" name="password" placeholder="Buat password" required>
                    </div>

                    <div class="input-card">
                        <input type="tel" name="phone" value="<?php echo html_escape(isset($form_data['phone']) ? $form_data['phone'] : ''); ?>" placeholder="Masukkan Nomor Telepon (Contoh 08XXXXXXXXXX)" pattern="[0-9]{10,15}" required>
                    </div>

                    <div class="input-card">
                        <textarea name="address" placeholder="Masukkan alamat lengkap" required><?php echo html_escape(isset($form_data['address']) ? $form_data['address'] : ''); ?></textarea>
                    </div>

                    <button type="submit">Daftar</button>
                <?php echo form_close(); ?>

                <div class="login-link">
                    Apakah Anda sudah memiliki akun?
                    <a href="<?php echo site_url('auth/login'); ?>">Login di sini</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
