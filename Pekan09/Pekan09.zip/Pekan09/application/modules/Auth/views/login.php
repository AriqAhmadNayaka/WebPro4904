<?php
$username_value = isset($username_value) ? (string) $username_value : '';
$remember_me = isset($remember_me) ? (bool) $remember_me : FALSE;
$error = isset($error) ? (string) $error : '';
$success = isset($success) ? (string) $success : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login NaviBiz</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #eef6ff 0%, #f8fbff 100%);
            color: #16324f;
        }

        .card {
            width: 100%;
            max-width: 420px;
            background: #ffffff;
            border-radius: 20px;
            padding: 28px;
            box-shadow: 0 20px 50px rgba(22, 50, 79, 0.12);
        }

        h1 {
            margin: 0 0 8px;
            font-size: 30px;
        }

        p {
            margin: 0 0 20px;
            color: #64748b;
            line-height: 1.6;
        }

        .alert {
            margin-bottom: 16px;
            padding: 12px 14px;
            border-radius: 12px;
            font-size: 14px;
            line-height: 1.5;
        }

        .alert-error {
            background: #fff1f2;
            border: 1px solid #fecdd3;
            color: #9f1239;
        }

        .alert-success {
            background: #ecfdf5;
            border: 1px solid #a7f3d0;
            color: #065f46;
        }

        .field {
            margin-bottom: 16px;
        }

        .field label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 600;
        }

        .field input {
            width: 100%;
            padding: 13px 14px;
            border: 1px solid #cbd5e1;
            border-radius: 12px;
            font-size: 14px;
        }

        .field input:focus {
            outline: none;
            border-color: #0a84ff;
            box-shadow: 0 0 0 4px rgba(10, 132, 255, 0.12);
        }

        .remember {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 0 0 18px;
            font-size: 14px;
            color: #475569;
        }

        button {
            width: 100%;
            border: none;
            border-radius: 12px;
            padding: 14px;
            font-size: 15px;
            font-weight: 700;
            color: #ffffff;
            background: linear-gradient(135deg, #0a84ff 0%, #0d5c9f 100%);
            cursor: pointer;
        }

        button:hover {
            filter: brightness(1.03);
        }

        .switch-link {
            margin-top: 18px;
            text-align: center;
            font-size: 14px;
            color: #64748b;
        }

        .switch-link a {
            color: #0a84ff;
            font-weight: 700;
            text-decoration: none;
        }

        .switch-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>NaviBiz</h1>
        <p>Masuk untuk membuka dashboard transaksi.</p>

        <?php if ($error !== ''): ?>
            <div class="alert alert-error"><?php echo html_escape($error); ?></div>
        <?php endif; ?>

        <?php if ($success !== ''): ?>
            <div class="alert alert-success"><?php echo html_escape($success); ?></div>
        <?php endif; ?>

        <?php echo form_open('auth/proses_login'); ?>
            <div class="field">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?php echo html_escape($username_value); ?>" required>
            </div>

            <div class="field">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>

            <label class="remember" for="remember">
                <input type="checkbox" id="remember" name="remember" value="1" <?php echo $remember_me ? 'checked' : ''; ?>>
                Ingat username saya
            </label>

            <button type="submit">Login</button>
        <?php echo form_close(); ?>

        <div class="switch-link">
            Belum punya akun?
            <a href="<?php echo site_url('auth/register'); ?>">Daftar di sini</a>
        </div>
    </div>
</body>
</html>
