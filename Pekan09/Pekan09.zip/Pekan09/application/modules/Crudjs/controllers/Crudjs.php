<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . 'core/MX_Controller.php';

class Crudjs extends MX_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->add_package_path(APPPATH . 'modules/Crudjs/');
        $this->load->model('Crudjs_model', 'crudjs_model');
        $this->load->helper(array('url', 'form'));
    }

    public function index()
    {
        $this->load->view('index', array(
            'title' => 'CRUD AJAX HMVC - NaviBiz'
        ));
    }

    public function list()
    {
        return $this->json_response(array(
            'status' => TRUE,
            'data' => $this->crudjs_model->get_all()
        ));
    }

    public function store()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            return $this->json_response(array('status' => FALSE, 'message' => 'Method tidak diizinkan.'), 405);
        }

        $payload = $this->payload();
        $error = $this->validate_payload($payload);

        if ($error !== '') {
            return $this->json_response(array('status' => FALSE, 'message' => $error), 422);
        }

        $id = $this->crudjs_model->insert($payload);

        if (!$id) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Data gagal disimpan.'), 500);
        }

        return $this->json_response(array(
            'status' => TRUE,
            'message' => 'Data berhasil ditambahkan.',
            'data' => $this->crudjs_model->get_by_id($id)
        ), 201);
    }

    public function show($id = NULL)
    {
        $transaction = $this->crudjs_model->get_by_id((int) $id);

        if (!$transaction) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Data tidak ditemukan.'), 404);
        }

        return $this->json_response(array('status' => TRUE, 'data' => $transaction));
    }

    public function update($id = NULL)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            return $this->json_response(array('status' => FALSE, 'message' => 'Method tidak diizinkan.'), 405);
        }

        $id = (int) $id;

        if (!$this->crudjs_model->get_by_id($id)) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Data tidak ditemukan.'), 404);
        }

        $payload = $this->payload();
        $error = $this->validate_payload($payload);

        if ($error !== '') {
            return $this->json_response(array('status' => FALSE, 'message' => $error), 422);
        }

        if (!$this->crudjs_model->update($id, $payload)) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Data gagal diperbarui.'), 500);
        }

        return $this->json_response(array(
            'status' => TRUE,
            'message' => 'Data berhasil diperbarui.',
            'data' => $this->crudjs_model->get_by_id($id)
        ));
    }

    public function delete($id = NULL)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            return $this->json_response(array('status' => FALSE, 'message' => 'Method tidak diizinkan.'), 405);
        }

        $id = (int) $id;

        if (!$this->crudjs_model->get_by_id($id)) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Data tidak ditemukan.'), 404);
        }

        if (!$this->crudjs_model->delete($id)) {
            return $this->json_response(array('status' => FALSE, 'message' => 'Data gagal dihapus.'), 500);
        }

        return $this->json_response(array('status' => TRUE, 'message' => 'Data berhasil dihapus.'));
    }

    protected function payload()
    {
        $json = json_decode($this->input->raw_input_stream, TRUE);
        $data = is_array($json) ? $json : $this->input->post(NULL, TRUE);

        return array(
            'tanggal' => isset($data['tanggal']) ? trim((string) $data['tanggal']) : '',
            'keterangan' => isset($data['keterangan']) ? trim((string) $data['keterangan']) : '',
            'jenis' => isset($data['jenis']) ? strtolower(trim((string) $data['jenis'])) : '',
            'jumlah' => isset($data['jumlah']) ? (int) $data['jumlah'] : 0
        );
    }

    protected function validate_payload(array $payload)
    {
        if ($payload['tanggal'] === '') {
            return 'Tanggal wajib diisi.';
        }

        if ($payload['keterangan'] === '') {
            return 'Keterangan wajib diisi.';
        }

        if (!in_array($payload['jenis'], array('pemasukan', 'pengeluaran'), TRUE)) {
            return 'Jenis transaksi harus pemasukan atau pengeluaran.';
        }

        if ($payload['jumlah'] < 1) {
            return 'Jumlah transaksi minimal 1.';
        }

        return '';
    }

    protected function json_response(array $payload, $status = 200)
    {
        return $this->output
            ->set_status_header($status)
            ->set_content_type('application/json', 'utf-8')
            ->set_output(json_encode($payload, JSON_PRETTY_PRINT));
    }
}
