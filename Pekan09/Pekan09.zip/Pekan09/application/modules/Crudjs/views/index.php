<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo html_escape($title); ?></title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, sans-serif;
            background: #f5f7fb;
            color: #1f2937;
        }
        .page {
            width: min(1180px, calc(100% - 32px));
            margin: 32px auto;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            align-items: center;
            margin-bottom: 20px;
        }
        h1 {
            margin: 0 0 6px;
            font-size: 28px;
        }
        .subtitle {
            margin: 0;
            color: #6b7280;
        }
        .layout {
            display: grid;
            grid-template-columns: 360px 1fr;
            gap: 20px;
            align-items: start;
        }
        .panel {
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 10px 20px rgba(15, 23, 42, 0.05);
        }
        label {
            display: block;
            margin: 14px 0 6px;
            font-weight: 700;
            font-size: 14px;
        }
        input, select {
            width: 100%;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            padding: 10px 12px;
            font-size: 15px;
            background: #fff;
        }
        .actions {
            display: flex;
            gap: 10px;
            margin-top: 18px;
        }
        button, .link-button {
            border: 0;
            border-radius: 6px;
            padding: 10px 14px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 40px;
        }
        .primary { background: #2563eb; color: #fff; }
        .secondary { background: #e5e7eb; color: #111827; }
        .danger { background: #dc2626; color: #fff; }
        .message {
            display: none;
            margin-bottom: 14px;
            padding: 10px 12px;
            border-radius: 6px;
            font-size: 14px;
        }
        .message.ok { display: block; background: #dcfce7; color: #166534; }
        .message.err { display: block; background: #fee2e2; color: #991b1b; }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border-bottom: 1px solid #e5e7eb;
            padding: 12px 10px;
            text-align: left;
            vertical-align: top;
        }
        th {
            background: #f9fafb;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: .04em;
            color: #4b5563;
        }
        .table-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        .amount {
            font-weight: 700;
            white-space: nowrap;
        }
        .badge {
            display: inline-block;
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 12px;
            font-weight: 700;
        }
        .badge.in { background: #dcfce7; color: #166534; }
        .badge.out { background: #fee2e2; color: #991b1b; }
        @media (max-width: 820px) {
            .layout { grid-template-columns: 1fr; }
            .topbar { align-items: flex-start; flex-direction: column; }
            .panel { padding: 16px; }
            table { min-width: 720px; }
            .table-wrap { overflow-x: auto; }
        }
    </style>
</head>
<body>
    <main class="page">
        <div class="topbar">
            <div>
                <h1>NaviBiz CRUD AJAX</h1>
                <p class="subtitle">Kelola transaksi tanpa refresh halaman.</p>
            </div>
            <a class="link-button secondary" href="<?php echo site_url('dashboard'); ?>">Dashboard</a>
        </div>

        <div class="layout">
            <section class="panel">
                <h2 id="form-title">Tambah Transaksi</h2>
                <div id="message" class="message"></div>
                <form id="transaction-form">
                    <input type="hidden" id="id" name="id">

                    <label for="tanggal">Tanggal</label>
                    <input type="date" id="tanggal" name="tanggal" required>

                    <label for="keterangan">Keterangan</label>
                    <input type="text" id="keterangan" name="keterangan" placeholder="Contoh: Beli bahan baku" required>

                    <label for="jenis">Jenis</label>
                    <select id="jenis" name="jenis" required>
                        <option value="pemasukan">Pemasukan</option>
                        <option value="pengeluaran">Pengeluaran</option>
                    </select>

                    <label for="jumlah">Jumlah</label>
                    <input type="number" id="jumlah" name="jumlah" min="1" placeholder="500000" required>

                    <div class="actions">
                        <button type="submit" class="primary" id="submit-button">Simpan</button>
                        <button type="button" class="secondary" id="reset-button">Batal</button>
                    </div>
                </form>
            </section>

            <section class="panel">
                <h2>Data Transaksi</h2>
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Keterangan</th>
                                <th>Jenis</th>
                                <th>Jumlah</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="transaction-table">
                            <tr><td colspan="5">Memuat data...</td></tr>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </main>

    <script>
        const urls = {
            list: "<?php echo site_url('crudjs/list'); ?>",
            store: "<?php echo site_url('crudjs/store'); ?>",
            show: "<?php echo site_url('crudjs/show/'); ?>",
            update: "<?php echo site_url('crudjs/update/'); ?>",
            delete: "<?php echo site_url('crudjs/delete/'); ?>"
        };

        const form = document.getElementById('transaction-form');
        const table = document.getElementById('transaction-table');
        const message = document.getElementById('message');
        const formTitle = document.getElementById('form-title');
        const submitButton = document.getElementById('submit-button');

        function rupiah(value) {
            return new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                maximumFractionDigits: 0
            }).format(Number(value || 0));
        }

        function showMessage(text, type) {
            message.className = 'message ' + (type || 'ok');
            message.textContent = text;
            window.setTimeout(() => {
                message.className = 'message';
                message.textContent = '';
            }, 3000);
        }

        function resetForm() {
            form.reset();
            document.getElementById('id').value = '';
            formTitle.textContent = 'Tambah Transaksi';
            submitButton.textContent = 'Simpan';
        }

        async function request(url, options = {}) {
            const response = await fetch(url, options);
            const payload = await response.json();

            if (!response.ok || payload.status === false) {
                throw new Error(payload.message || 'Request gagal.');
            }

            return payload;
        }

        async function loadTransactions() {
            try {
                const payload = await request(urls.list);
                renderRows(payload.data || []);
            } catch (error) {
                table.innerHTML = '<tr><td colspan="5">' + error.message + '</td></tr>';
            }
        }

        function renderRows(rows) {
            if (!rows.length) {
                table.innerHTML = '<tr><td colspan="5">Belum ada data transaksi.</td></tr>';
                return;
            }

            table.innerHTML = rows.map(row => {
                const jenis = String(row.jenis || '').toLowerCase();
                const badgeClass = jenis === 'pemasukan' ? 'in' : 'out';
                return `
                    <tr>
                        <td>${row.tanggal}</td>
                        <td>${escapeHtml(row.keterangan)}</td>
                        <td><span class="badge ${badgeClass}">${escapeHtml(row.jenis)}</span></td>
                        <td class="amount">${rupiah(row.jumlah)}</td>
                        <td>
                            <div class="table-actions">
                                <button type="button" class="secondary" onclick="editTransaction(${row.id})">Edit</button>
                                <button type="button" class="danger" onclick="deleteTransaction(${row.id})">Hapus</button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');
        }

        function escapeHtml(value) {
            return String(value || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        form.addEventListener('submit', async event => {
            event.preventDefault();

            const id = document.getElementById('id').value;
            const formData = new FormData(form);
            const targetUrl = id ? urls.update + id : urls.store;

            try {
                const payload = await request(targetUrl, {
                    method: 'POST',
                    body: formData
                });
                showMessage(payload.message, 'ok');
                resetForm();
                loadTransactions();
            } catch (error) {
                showMessage(error.message, 'err');
            }
        });

        document.getElementById('reset-button').addEventListener('click', resetForm);

        async function editTransaction(id) {
            try {
                const payload = await request(urls.show + id);
                const data = payload.data;
                document.getElementById('id').value = data.id;
                document.getElementById('tanggal').value = data.tanggal;
                document.getElementById('keterangan').value = data.keterangan;
                document.getElementById('jenis').value = String(data.jenis || '').toLowerCase();
                document.getElementById('jumlah').value = data.jumlah;
                formTitle.textContent = 'Edit Transaksi';
                submitButton.textContent = 'Update';
            } catch (error) {
                showMessage(error.message, 'err');
            }
        }

        async function deleteTransaction(id) {
            if (!confirm('Hapus data transaksi ini?')) {
                return;
            }

            try {
                const payload = await request(urls.delete + id, { method: 'POST' });
                showMessage(payload.message, 'ok');
                loadTransactions();
            } catch (error) {
                showMessage(error.message, 'err');
            }
        }

        loadTransactions();
    </script>
</body>
</html>
