<!DOCTYPE html>
<html lang="in">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NaviBiz - Login</title>
    <style>
        /* Menggunakan style asli dari login.html Anda */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            min-height: 100vh;
            background-color: #ebfbfa;
            background-image:
                radial-gradient(circle at 10% 100%, rgba(5, 12, 87, 0.607), rgba(70, 79, 184, 0.281), transparent 40%),
                radial-gradient(circle at 100% 10%, rgba(60, 252, 242, 0.42), rgba(207, 244, 248, 0.756), transparent 60%);
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .form-container { width: 100%; display: flex; justify-content: center; margin-top: 60px; }
        .form-box { width: 380px; padding: 20px; background: white; border-radius: 15px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .input-card { margin-bottom: 15px; }
        .input-card input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #956df3; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold; }
        header { text-align: center; padding-top: 50px; }
    </style>
</head>
<body>
    <header>
        <h1 style="color: #956df3;">NaviBiz</h1>
        <h2 style="color: #956df3;">Masuk / Login</h2>
    </header>

    <div class="form-container">
        <form class="form-box" action="<?= base_url('auth/proses_login') ?>" method="post">
            <div class="input-card">
                <input type="text" name="username" placeholder="Masukkan Nama Pengguna" required>
            </div>
            <div class="input-card">
                <input type="password" name="password" placeholder="Masukkan password" required>
            </div>
            <button type="submit">Login</button>
        </form>
    </div>

    <h4 style="text-align: center; color: grey; margin-top: 20px;">Atau Daftar Menggunakan</h4>
    <div style="text-align: center;">
        <p>Belum punya akun? <a href="<?= base_url('auth/daftar') ?>" style="color: #956df3;">Daftar di sini</a></p>
    </div>
</body>
</html>