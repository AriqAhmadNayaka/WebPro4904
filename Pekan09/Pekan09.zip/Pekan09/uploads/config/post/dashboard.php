<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>NaviBiz - Dashboard Keuangan</title>
  <link rel="stylesheet" href="<?= base_url('assets/css/logout.css') ?>">
  <style>
    /* Style utama diambil dari dompet.html Anda */
    :root { --primary: #3b82f6; --bg-card: #ffffff; --radius-lg: 16px; }
    body { font-family: 'Poppins', sans-serif; background-color: #ebfbfa; margin: 20px; }
    .form-card, .table-card { background: var(--bg-card); padding: 25px; border-radius: var(--radius-lg); box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 20px; }
    .form-group { margin-bottom: 15px; display: flex; flex-direction: column; }
    .form-group label { margin-bottom: 5px; font-weight: 500; }
    .form-group input, .form-group select { padding: 10px; border: 1px solid #e5e7eb; border-radius: 8px; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th, td { padding: 12px; text-align: left; border-bottom: 1px solid #f3f4f6; }
    th { background: #f9fafb; color: #6b7280; font-weight: 600; }
    .btn-simpan { background: var(--primary); color: white; padding: 10px 25px; border: none; border-radius: 8px; cursor: pointer; }
    .badge-pemasukan { color: #10b981; font-weight: 600; }
    .badge-pengeluaran { color: #ef4444; font-weight: 600; }
  </style>
</head>
<body>

  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <h2>Dashboard NaviBiz</h2>
    <a href="<?= base_url('auth/logout') ?>" onclick="return confirm('Apakah Anda yakin ingin keluar?')">
        <button style="background: #ef4444; color: white; border: none; padding: 8px 15px; border-radius: 8px; cursor: pointer;">Keluar</button>
    </a>
  </div>

  <div style="display: flex; gap: 20px; flex-wrap: wrap;">
    <div class="form-card" style="width: 350px;">
      <h3>Input Transaksi</h3>
      <hr style="margin: 15px 0; border: 0; border-top: 1px solid #eee;">
      
      <form action="<?= base_url('dashboard/simpan') ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
          <label>Tanggal</label>
          <input type="date" name="tanggal" required />
        </div>
        <div class="form-group">
          <label>Keterangan</label>
          <input type="text" name="keterangan" placeholder="Contoh: Jual Produk A" required />
        </div>
        <div class="form-group">
          <label>Jenis</label>
          <select name="jenis">
            <option value="Pemasukan">Pemasukan</option>
            <option value="Pengeluaran">Pengeluaran</option>
          </select>
        </div>
        <div class="form-group">
          <label>Jumlah (Rp)</label>
          <input type="number" name="jumlah" required />
        </div>
        <div class="form-group">
          <label>Bukti Transaksi (Gambar/PDF)</label>
          <input type="file" name="file_bukti" />
        </div>
        <button type="submit" class="btn-simpan">Simpan & Upload</button>
      </form>
    </div>

    <div class="table-card" style="flex: 1; min-width: 400px;">
      <h3>Riwayat Transaksi</h3>
      <table>
        <thead>
          <tr>
            <th>Tanggal</th>
            <th>Keterangan</th>
            <th>Jenis</th>
            <th>Jumlah</th>
            <th>Bukti</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if(empty($transaksi)): ?>
            <tr><td colspan="6" style="text-align:center;">Belum ada data.</td></tr>
          <?php else: ?>
            <?php foreach($transaksi as $t): ?>
            <tr>
              <td><?= date('d/m/Y', strtotime($t->tanggal)) ?></td>
              <td><?= $t->keterangan ?></td>
              <td>
                <span class="<?= $t->jenis == 'Pemasukan' ? 'badge-pemasukan' : 'badge-pengeluaran' ?>">
                  <?= $t->jenis ?>
                </span>
              </td>
              <td>Rp <?= number_format($t->jumlah, 0, ',', '.') ?></td>
              <td>
                <?php if($t->file_bukti): ?>
                  <a href="<?= base_url('uploads/'.$t->file_bukti) ?>" target="_blank" style="color: var(--primary);">Lihat File</a>
                <?php else: ?>
                  <span style="color: #ccc;">No File</span>
                <?php endif; ?>
              </td>
              <td>
                <a href="<?= base_url('dashboard/hapus/'.$t->id) ?>" 
                   style="color: #ef4444; text-decoration: none;" 
                   onclick="return confirm('Hapus data ini?')">Hapus</a>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</body>
</html>