# Laporan Praktikum Pekan 09

## Judul Praktikum
CodeIgniter 3 + HMVC + REST API + CRUD AJAX Tanpa Refresh

## Tujuan Praktikum
1. Membuat struktur aplikasi CodeIgniter 3 berbasis modul.
2. Memindahkan controller, model, dan view ke `application/modules`.
3. Membuat REST API JSON untuk autentikasi dan data posts.
4. Membuat CRUD AJAX untuk transaksi tanpa refresh halaman.
5. Menguji endpoint dengan browser dan Postman.

## Alat dan Bahan
1. XAMPP dengan Apache dan MySQL aktif.
2. PHP 7 atau PHP 8 dari XAMPP.
3. CodeIgniter 3.
4. Browser.
5. Postman.
6. VS Code atau editor lain.

## Jawaban Tugas Pendahuluan
1. MVC membagi aplikasi menjadi Model, View, dan Controller. HMVC memakai pola yang sama, tetapi setiap fitur punya folder MVC sendiri di dalam modul, misalnya `modules/Posts`.
2. Arsitektur modular membuat kode lebih rapi. Contoh: fitur `Api`, `Posts`, dan `Crudjs` bisa dikerjakan terpisah tanpa mencampur file.
3. REST API adalah layanan HTTP yang mengirim dan menerima data, biasanya JSON.
4. `GET` mengambil data, `POST` menambah data, `PUT` memperbarui data, dan `DELETE` menghapus data.
5. AJAX adalah teknik JavaScript untuk mengirim request ke server tanpa refresh halaman penuh.
6. AJAX membuat aplikasi lebih interaktif karena tabel bisa berubah setelah tambah, edit, atau hapus data tanpa reload.
7. Request synchronous menunggu proses selesai sebelum halaman lanjut bekerja. Request asynchronous berjalan di belakang layar, sehingga halaman tetap bisa dipakai.

## Langkah Praktikum
1. Menyiapkan proyek CodeIgniter 3 di folder `Pekan 09`.
2. Menyusun modul HMVC:
   - `application/modules/Auth`
   - `application/modules/Dashboard`
   - `application/modules/Posts`
   - `application/modules/Crudjs`
   - `application/modules/Api`
   - `application/modules/tugas_pekan_08`
3. Menambahkan `application/core/MX_Controller.php` sebagai controller dasar modul.
4. Membuat REST API:
   - `POST /index.php/api/auth/register`
   - `POST /index.php/api/auth/login`
   - `POST /index.php/api/auth/me`
   - `POST /index.php/api/auth/logout`
   - `GET /index.php/api/post`
   - `GET /index.php/api/post/{id}`
   - `POST /index.php/api/post`
   - `PUT /index.php/api/post/{id}`
   - `DELETE /index.php/api/post/{id}`
5. Membuat CRUD AJAX transaksi:
   - `GET /index.php/crudjs`
   - `GET /index.php/crudjs/list`
   - `POST /index.php/crudjs/store`
   - `GET /index.php/crudjs/show/{id}`
   - `POST /index.php/crudjs/update/{id}`
   - `POST /index.php/crudjs/delete/{id}`
6. Menambahkan tabel `posts`, `users`, dan `transaksi` di `navibiz_db.sql`.

## Hasil Program
1. Halaman login dan register tetap tersedia dari modul `Auth`.
2. Data transaksi lama dari aplikasi NaviBiz masuk ke modul CodeIgniter.
3. Halaman `crudjs` menampilkan tabel transaksi dan form input.
4. Tambah, edit, dan hapus transaksi berjalan lewat JavaScript `fetch()`.
5. REST API mengembalikan response JSON dan memakai token Bearer untuk endpoint posts.

## Analisis
Struktur HMVC membuat fitur lebih mudah dicari. Contoh, semua file CRUD AJAX transaksi ada di `application/modules/Crudjs`, sehingga controller, model, dan view tidak bercampur dengan fitur lain.

REST API memisahkan proses data dari tampilan. Postman atau aplikasi lain dapat memakai endpoint yang sama tanpa membuka halaman HTML.

AJAX mengurangi reload halaman. Saat kamu menambah transaksi, JavaScript mengirim data ke `crudjs/store`, lalu tabel dimuat ulang dari `crudjs/list`.

## Kesimpulan
Praktikum ini menghasilkan aplikasi CodeIgniter 3 dengan struktur modul, REST API JSON, autentikasi token, dan CRUD AJAX tanpa refresh halaman. Struktur ini lebih mudah dirawat dibanding file PHP tunggal karena setiap fitur punya folder dan tanggung jawab sendiri.

## Lampiran
Folder proyek: `/Applications/XAMPP/xamppfiles/htdocs/Pekan 09`

URL lokal setelah Apache XAMPP aktif:

- `http://localhost/Pekan%2009/index.php/auth/login`
- `http://localhost/Pekan%2009/index.php/crudjs`
- `http://localhost/Pekan%2009/index.php/api/auth/login`
