<?php
defined('BASEPATH') or exit('No direct script access allowed');

if (!function_exists('is_logged_in')) {
    function is_logged_in()
    {
        $ci = &get_instance();
        return (bool) $ci->session->userdata('logged_in');
    }
}

if (!function_exists('require_login')) {
    function require_login()
    {
        $ci = &get_instance();
        if (!is_logged_in()) {
            $ci->session->set_flashdata('error', 'Silakan login terlebih dahulu.');
            redirect('login');
        }
    }
}
