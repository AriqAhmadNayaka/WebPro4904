<div class="dashboard-shell">
    <header class="dashboard-header">
        <div>
            <p class="eyebrow">Dashboard</p>
            <h1>Manajemen Data Sampah</h1>
            <p class="dashboard-subtitle">Halo, <?= html_escape($user_name); ?>. Halaman ini hanya bisa diakses setelah login berhasil.</p>
        </div>
        <a href="<?= site_url('logout'); ?>" class="css-button-logout">Logout</a>
    </header>

    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success"><?= $this->session->flashdata('success'); ?></div>
    <?php endif; ?>

    <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-error"><?= $this->session->flashdata('error'); ?></div>
    <?php endif; ?>

    <section class="dashboard-grid">
        <div class="acrylic-card">
            <h2><?= $edit_item ? 'Edit Data Sampah' : 'Tambah Data Sampah'; ?></h2>
            <p class="section-copy">Gunakan satu tombol <strong>Simpan</strong> untuk create/update sekaligus upload file.</p>

            <form action="<?= site_url('dashboard/simpan'); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?= $edit_item ? (int) $edit_item->id : ''; ?>">

                <label for="nama_lokasi">Nama Lokasi</label>
                <input id="nama_lokasi" type="text" name="nama_lokasi" class="custom-input" placeholder="Contoh: TPS Fakultas Teknik" value="<?= set_value('nama_lokasi', $edit_item ? $edit_item->nama_lokasi : ''); ?>" required>

                <label for="berat">Berat Sampah (kg)</label>
                <input id="berat" type="number" step="0.1" name="berat" class="custom-input" placeholder="Contoh: 72.5" value="<?= set_value('berat', $edit_item ? $edit_item->berat : ''); ?>" required>

                <label for="kategori">Kategori Status</label>
                <select id="kategori" name="kategori" class="custom-input" required>
                    <?php $selected = set_value('kategori', $edit_item ? $edit_item->kategori : 'Aman'); ?>
                    <option value="Aman" <?= $selected === 'Aman' ? 'selected' : ''; ?>>Aman</option>
                    <option value="Waspada" <?= $selected === 'Waspada' ? 'selected' : ''; ?>>Waspada</option>
                    <option value="Overload" <?= $selected === 'Overload' ? 'selected' : ''; ?>>Overload</option>
                </select>

                <label for="deskripsi">Deskripsi</label>
                <textarea id="deskripsi" name="deskripsi" class="custom-input custom-textarea" placeholder="Jelaskan kondisi tempat sampah" required><?= set_value('deskripsi', $edit_item ? $edit_item->deskripsi : ''); ?></textarea>

                <label for="gambar">Upload Gambar</label>
                <input id="gambar" type="file" name="gambar" class="custom-input" accept=".jpg,.jpeg,.png">

                <?php if ($edit_item && !empty($edit_item->gambar)): ?>
                    <div class="preview-box">
                        <span>Gambar saat ini</span>
                        <img src="<?= base_url('uploads/' . $edit_item->gambar); ?>" alt="Preview gambar data">
                    </div>
                <?php endif; ?>

                <button type="submit" class="btn-primary">Simpan</button>
            </form>
        </div>

        <div class="acrylic-card">
            <h2>Data Tersimpan</h2>
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>Gambar</th>
                        <th>Lokasi</th>
                        <th>Berat</th>
                        <th>Kategori</th>
                        <th>Deskripsi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($items)): ?>
                        <tr>
                            <td colspan="6" class="empty-state">Belum ada data.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($items as $item): ?>
                            <tr>
                                <td>
                                    <?php if (!empty($item->gambar)): ?>
                                        <img class="table-image" src="<?= base_url('uploads/' . $item->gambar); ?>" alt="<?= html_escape($item->nama_lokasi); ?>">
                                    <?php else: ?>
                                        <span class="empty-label">Tidak ada</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= html_escape($item->nama_lokasi); ?></td>
                                <td><?= html_escape($item->berat); ?> kg</td>
                                <td><span class="badge badge-<?= strtolower($item->kategori); ?>"><?= html_escape($item->kategori); ?></span></td>
                                <td><?= html_escape($item->deskripsi); ?></td>
                                <td class="action-cell">
                                    <a class="css-button-login" href="<?= site_url('dashboard?edit=' . $item->id); ?>">Edit</a>
                                    <form action="<?= site_url('dashboard/hapus/' . $item->id); ?>" method="post" style="display:inline;">
                                        <button type="submit" class="css-button-logout" onclick="return confirm('Hapus data ini?');">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>
