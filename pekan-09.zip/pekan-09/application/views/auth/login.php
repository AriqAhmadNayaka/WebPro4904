<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= html_escape($title); ?></title>
    <link rel="stylesheet" href="<?= base_url('login.css'); ?>">
</head>
<body class="login-page">
    <div class="container-login">
        <div class="login-copy">
            <p class="eyebrow">CodeIgniter 3 Project</p>
            <h1 class="greeting">SmartTrash Dashboard</h1>
            <p class="login-subtitle">Login terlebih dahulu untuk mengelola data sampah, melakukan CRUD, dan upload file dalam satu form.</p>
        </div>

        <div class="acrylic-card">
            <h2 class="form-title">Masuk</h2>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-error"><?= $this->session->flashdata('error'); ?></div>
            <?php endif; ?>

            <form action="<?= site_url('login'); ?>" method="post">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input id="email" type="email" name="email" class="custom-input input-teal" placeholder="admin@smarttrash.test" value="<?= set_value('email'); ?>" required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input id="password" type="password" name="password" class="custom-input input-pink" placeholder="Masukkan password" required>
                </div>

                <button type="submit" class="btn-login">Login</button>
            </form>

            <p class="login-note">Akun default: <strong>admin@smarttrash.test</strong> / <strong>admin123</strong></p>
        </div>
    </div>
</body>
</html>
