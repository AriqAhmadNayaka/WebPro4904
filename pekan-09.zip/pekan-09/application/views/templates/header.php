<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= html_escape($title); ?></title>
    <link rel="stylesheet" href="<?= base_url('login.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('admin.css'); ?>">
</head>
<body>
