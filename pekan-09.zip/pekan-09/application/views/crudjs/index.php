<div class="dashboard-shell">
    <header class="dashboard-header">
        <div>
            <p class="eyebrow">CRUD JavaScript</p>
            <h1>Manajemen Data Sampah</h1>
            <p class="dashboard-subtitle">Halo, <?= html_escape($user_name); ?>. Data di halaman ini disimpan dengan request JavaScript.</p>
        </div>
        <div class="action-cell">
            <a href="<?= site_url('dashboard'); ?>" class="css-button-login">Dashboard</a>
            <a href="<?= site_url('logout'); ?>" class="css-button-logout">Logout</a>
        </div>
    </header>

    <div id="crud-alert" class="alert" style="display:none;"></div>

    <section class="dashboard-grid">
        <div class="acrylic-card">
            <h2 id="form-title">Tambah Data Sampah</h2>
            <p class="section-copy">Isi form, lalu data akan muncul di tabel tanpa reload halaman.</p>

            <form id="crud-form" enctype="multipart/form-data">
                <input type="hidden" name="id" id="id">

                <label for="nama_lokasi">Nama Lokasi</label>
                <input id="nama_lokasi" type="text" name="nama_lokasi" class="custom-input" placeholder="Contoh: TPS Fakultas Teknik" required>

                <label for="berat">Berat Sampah (kg)</label>
                <input id="berat" type="number" step="0.1" name="berat" class="custom-input" placeholder="Contoh: 72.5" required>

                <label for="kategori">Kategori Status</label>
                <select id="kategori" name="kategori" class="custom-input" required>
                    <option value="Aman">Aman</option>
                    <option value="Waspada">Waspada</option>
                    <option value="Overload">Overload</option>
                </select>

                <label for="deskripsi">Deskripsi</label>
                <textarea id="deskripsi" name="deskripsi" class="custom-input custom-textarea" placeholder="Jelaskan kondisi tempat sampah" required></textarea>

                <label for="gambar">Upload Gambar</label>
                <input id="gambar" type="file" name="gambar" class="custom-input" accept=".jpg,.jpeg,.png">

                <div class="action-cell" style="margin-top:18px;">
                    <button type="submit" class="btn-primary">Simpan</button>
                    <button type="button" id="btn-reset" class="css-button-login">Batal</button>
                </div>
            </form>
        </div>

        <div class="acrylic-card">
            <h2>Data Tersimpan</h2>
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>Gambar</th>
                        <th>Lokasi</th>
                        <th>Berat</th>
                        <th>Kategori</th>
                        <th>Deskripsi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody id="crud-table-body">
                    <tr>
                        <td colspan="6" class="empty-state">Memuat data...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>
</div>

<script>
const endpoints = {
    list: '<?= site_url('crudjs/list'); ?>',
    detail: '<?= site_url('crudjs/detail/'); ?>',
    save: '<?= site_url('crudjs/simpan'); ?>',
    delete: '<?= site_url('crudjs/hapus/'); ?>',
    uploads: '<?= base_url('uploads/'); ?>'
};

const form = document.getElementById('crud-form');
const alertBox = document.getElementById('crud-alert');
const tableBody = document.getElementById('crud-table-body');
const formTitle = document.getElementById('form-title');

function escapeHtml(value) {
    return String(value || '').replace(/[&<>"']/g, function (char) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        }[char];
    });
}

function showAlert(message, type) {
    alertBox.textContent = message;
    alertBox.className = 'alert ' + (type === 'success' ? 'alert-success' : 'alert-error');
    alertBox.style.display = 'block';
}

function resetForm() {
    form.reset();
    document.getElementById('id').value = '';
    formTitle.textContent = 'Tambah Data Sampah';
}

async function loadData() {
    const response = await fetch(endpoints.list);
    const result = await response.json();

    if (!result.status || !result.data.length) {
        tableBody.innerHTML = '<tr><td colspan="6" class="empty-state">Belum ada data.</td></tr>';
        return;
    }

    tableBody.innerHTML = result.data.map(function (item) {
        const image = item.gambar
            ? '<img class="table-image" src="' + endpoints.uploads + encodeURIComponent(item.gambar) + '" alt="' + escapeHtml(item.nama_lokasi) + '">'
            : '<span class="empty-label">Tidak ada</span>';

        return '<tr>' +
            '<td>' + image + '</td>' +
            '<td>' + escapeHtml(item.nama_lokasi) + '</td>' +
            '<td>' + escapeHtml(item.berat) + ' kg</td>' +
            '<td><span class="badge badge-' + escapeHtml(String(item.kategori).toLowerCase()) + '">' + escapeHtml(item.kategori) + '</span></td>' +
            '<td>' + escapeHtml(item.deskripsi) + '</td>' +
            '<td class="action-cell">' +
                '<button type="button" class="css-button-login" onclick="editData(' + Number(item.id) + ')">Edit</button>' +
                '<button type="button" class="css-button-logout" onclick="deleteData(' + Number(item.id) + ')">Hapus</button>' +
            '</td>' +
        '</tr>';
    }).join('');
}

async function editData(id) {
    const response = await fetch(endpoints.detail + id);
    const result = await response.json();

    if (!result.status) {
        showAlert(result.message, 'error');
        return;
    }

    const item = result.data;
    document.getElementById('id').value = item.id;
    document.getElementById('nama_lokasi').value = item.nama_lokasi;
    document.getElementById('berat').value = item.berat;
    document.getElementById('kategori').value = item.kategori;
    document.getElementById('deskripsi').value = item.deskripsi;
    document.getElementById('gambar').value = '';
    formTitle.textContent = 'Edit Data Sampah';
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function deleteData(id) {
    if (!confirm('Hapus data ini?')) {
        return;
    }

    const response = await fetch(endpoints.delete + id, { method: 'POST' });
    const result = await response.json();
    showAlert(result.message, result.status ? 'success' : 'error');

    if (result.status) {
        resetForm();
        loadData();
    }
}

form.addEventListener('submit', async function (event) {
    event.preventDefault();

    const response = await fetch(endpoints.save, {
        method: 'POST',
        body: new FormData(form)
    });
    const result = await response.json();

    showAlert(result.message, result.status ? 'success' : 'error');

    if (result.status) {
        resetForm();
        loadData();
    }
});

document.getElementById('btn-reset').addEventListener('click', resetForm);
loadData();
</script>
