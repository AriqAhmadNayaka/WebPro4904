<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Crudjs extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        require_login();
        $this->load->model('Crudjs_model');
    }

    public function index()
    {
        $data = array(
            'title'     => 'CRUD JavaScript SmartTrash',
            'user_name' => $this->session->userdata('name'),
        );

        $this->load->view('templates/header', $data);
        $this->load->view('crudjs/index', $data);
        $this->load->view('templates/footer');
    }

    public function list_data()
    {
        $this->json_response(array(
            'status' => true,
            'data'   => $this->Crudjs_model->get_all(),
        ));
    }

    public function detail($id)
    {
        $item = $this->Crudjs_model->find($id);

        if (!$item) {
            $this->json_response(array(
                'status'  => false,
                'message' => 'Data tidak ditemukan.',
            ), 404);
        }

        $this->json_response(array(
            'status' => true,
            'data'   => $item,
        ));
    }

    public function simpan()
    {
        if ($this->input->method() !== 'post') {
            $this->json_response(array(
                'status'  => false,
                'message' => 'Metode request tidak diizinkan.',
            ), 405);
        }

        $id = (int) $this->input->post('id');

        $this->form_validation->set_rules('nama_lokasi', 'Nama lokasi', 'required|trim');
        $this->form_validation->set_rules('berat', 'Berat sampah', 'required|numeric');
        $this->form_validation->set_rules('kategori', 'Kategori', 'required|trim|in_list[Aman,Waspada,Overload]');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required|trim');

        if (!$this->form_validation->run()) {
            $this->json_response(array(
                'status'  => false,
                'message' => strip_tags(validation_errors()),
            ), 422);
        }

        $existing = $id ? $this->Crudjs_model->find($id) : null;
        if ($id && !$existing) {
            $this->json_response(array(
                'status'  => false,
                'message' => 'Data yang ingin diperbarui tidak ditemukan.',
            ), 404);
        }

        $payload = array(
            'nama_lokasi' => $this->input->post('nama_lokasi', true),
            'berat'       => $this->input->post('berat', true),
            'kategori'    => $this->input->post('kategori', true),
            'deskripsi'   => $this->input->post('deskripsi', true),
        );

        $upload = $this->handle_upload();
        if (!$upload['status']) {
            $this->json_response(array(
                'status'  => false,
                'message' => $upload['message'],
            ), 422);
        }

        $new_file = null;
        if (!empty($upload['file_name'])) {
            $payload['gambar'] = $upload['file_name'];
            $new_file = $upload['file_name'];
        } elseif ($existing) {
            $payload['gambar'] = $existing->gambar;
        }

        if (!$id && empty($payload['gambar'])) {
            $this->json_response(array(
                'status'  => false,
                'message' => 'Gambar wajib diunggah saat menambah data baru.',
            ), 422);
        }

        if ($id) {
            $saved = $this->Crudjs_model->update($id, $payload);
            $message = 'Data berhasil diperbarui.';
        } else {
            $saved = $this->Crudjs_model->insert($payload);
            $message = 'Data berhasil ditambahkan.';
        }

        if (!$saved) {
            if ($new_file) {
                $this->remove_file($new_file);
            }

            $this->json_response(array(
                'status'  => false,
                'message' => 'Data gagal disimpan.',
            ), 500);
        }

        if ($id && $new_file && !empty($existing->gambar)) {
            $this->remove_file($existing->gambar);
        }

        $this->json_response(array(
            'status'  => true,
            'message' => $message,
        ));
    }

    public function hapus($id)
    {
        if ($this->input->method() !== 'post') {
            $this->json_response(array(
                'status'  => false,
                'message' => 'Metode request tidak diizinkan.',
            ), 405);
        }

        $item = $this->Crudjs_model->find($id);
        if (!$item) {
            $this->json_response(array(
                'status'  => false,
                'message' => 'Data yang ingin dihapus tidak ditemukan.',
            ), 404);
        }

        if (!$this->Crudjs_model->delete($id)) {
            $this->json_response(array(
                'status'  => false,
                'message' => 'Data gagal dihapus.',
            ), 500);
        }

        if (!empty($item->gambar)) {
            $this->remove_file($item->gambar);
        }

        $this->json_response(array(
            'status'  => true,
            'message' => 'Data berhasil dihapus.',
        ));
    }

    private function handle_upload()
    {
        if (empty($_FILES['gambar']['name'])) {
            return array(
                'status'    => true,
                'file_name' => null,
                'message'   => null,
            );
        }

        $config = array(
            'upload_path'   => FCPATH . 'uploads' . DIRECTORY_SEPARATOR,
            'allowed_types' => 'jpg|jpeg|png',
            'max_size'      => 2048,
            'encrypt_name'  => true,
        );

        if (!is_dir($config['upload_path']) && !mkdir($config['upload_path'], 0777, true)) {
            return array(
                'status'    => false,
                'file_name' => null,
                'message'   => 'Folder upload tidak dapat dibuat.',
            );
        }

        if (!is_writable($config['upload_path'])) {
            return array(
                'status'    => false,
                'file_name' => null,
                'message'   => 'Folder upload tidak bisa ditulisi.',
            );
        }

        $this->upload->initialize($config);

        if (!$this->upload->do_upload('gambar')) {
            return array(
                'status'    => false,
                'file_name' => null,
                'message'   => strip_tags($this->upload->display_errors()),
            );
        }

        $uploaded = $this->upload->data();

        return array(
            'status'    => true,
            'file_name' => $uploaded['file_name'],
            'message'   => null,
        );
    }

    private function remove_file($file_name)
    {
        $file_path = FCPATH . 'uploads' . DIRECTORY_SEPARATOR . $file_name;
        if (is_file($file_path)) {
            @unlink($file_path);
        }
    }

    private function json_response($data, $status_code = 200)
    {
        return $this->output
            ->set_status_header($status_code)
            ->set_content_type('application/json')
            ->set_output(json_encode($data));
    }
}
