<?php
defined('BASEPATH') or exit('No direct script access allowed');

$autoload['packages'] = array();
$autoload['libraries'] = array('database', 'session', 'form_validation', 'upload');
$autoload['drivers'] = array();
$autoload['helper'] = array('url', 'form', 'auth');
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array();
