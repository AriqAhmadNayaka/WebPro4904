<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard EcoTaste</title>
    <style>
        :root { --green: #2e8b57; --dark: #194d30; --soft: #f3fbf3; --line: #dce9dc; --danger: #cf3d3d; }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: Arial, sans-serif; background: #f6faf6; color: #243424; }
        .topbar { background: linear-gradient(120deg, #2e8b57, #194d30); color: #fff; padding: 22px 5%; display: flex; justify-content: space-between; align-items: center; gap: 16px; flex-wrap: wrap; }
        .topbar h1 { margin: 0; font-size: 28px; }
        .topbar p { margin: 6px 0 0; opacity: 0.9; }
        .actions { display: flex; gap: 12px; flex-wrap: wrap; }
        .btn { text-decoration: none; border-radius: 10px; padding: 11px 16px; font-weight: 700; display: inline-block; }
        .btn-light { background: #fff; color: var(--dark); }
        .btn-danger { background: #fff1f1; color: var(--danger); }
        .wrapper { width: min(1100px, 92%); margin: 24px auto 40px; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 20px; }
        .stat-card { background: #fff; border: 1px solid var(--line); border-radius: 18px; padding: 20px; box-shadow: 0 8px 18px rgba(25, 77, 48, 0.06); }
        .stat-card span { color: #608060; font-size: 14px; }
        .stat-card strong { display: block; margin-top: 8px; font-size: 28px; color: var(--dark); }
        .panel { background: #fff; border: 1px solid var(--line); border-radius: 18px; overflow: hidden; }
        .panel-head { padding: 18px 20px; border-bottom: 1px solid var(--line); display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; }
        .panel-head h2 { margin: 0; font-size: 22px; }
        .flash { margin-bottom: 16px; padding: 14px 16px; border-radius: 12px; background: #e1f6e7; color: #1d6d3b; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 14px 20px; border-bottom: 1px solid var(--line); text-align: left; vertical-align: middle; }
        th { background: var(--soft); }
        img { width: 72px; height: 72px; object-fit: cover; border-radius: 12px; }
        .empty-image { width: 72px; height: 72px; border-radius: 12px; background: #eef5ee; display: inline-flex; align-items: center; justify-content: center; color: #759075; font-size: 12px; text-align: center; padding: 8px; }
        .menu-actions a { margin-right: 12px; text-decoration: none; font-weight: 700; }
        .menu-actions .edit { color: var(--green); }
        .menu-actions .delete { color: var(--danger); }
        @media (max-width: 760px) {
            table, thead, tbody, th, td, tr { display: block; }
            thead { display: none; }
            tr { border-bottom: 1px solid var(--line); padding: 14px 0; }
            td { border: 0; padding: 8px 20px; }
            td::before { content: attr(data-label); display: block; margin-bottom: 4px; color: #688068; font-size: 12px; text-transform: uppercase; }
        }
    </style>
</head>
<body>
    <div class="topbar">
        <div>
            <h1>Dashboard EcoTaste</h1>
            <p>Halo, <?php echo html_escape($this->session->userdata('username')); ?>. Kelola data kuliner dan unggah foto menu dari satu halaman.</p>
        </div>
        <div class="actions">
            <a class="btn btn-light" href="<?php echo base_url('index.php?c=menu&m=create'); ?>">+ Tambah Menu</a>
            <a class="btn btn-danger" href="<?php echo base_url('index.php?c=auth&m=logout'); ?>">Logout</a>
        </div>
    </div>

    <div class="wrapper">
        <?php if ($this->session->flashdata('success')): ?>
            <div class="flash"><?php echo $this->session->flashdata('success'); ?></div>
        <?php endif; ?>

        <div class="stats">
            <div class="stat-card">
                <span>Total Menu</span>
                <strong><?php echo $total_menu; ?></strong>
            </div>
            <div class="stat-card">
                <span>Rata-rata Rating</span>
                <strong><?php echo number_format($average_rating, 1); ?></strong>
            </div>
        </div>

        <div class="panel">
            <div class="panel-head">
                <h2>Data Menu Kuliner</h2>
                <span>Fitur CRUD + Upload File dalam satu aplikasi CodeIgniter 3</span>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Foto</th>
                        <th>Nama</th>
                        <th>Deskripsi</th>
                        <th>Rating</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($menus)): ?>
                        <tr>
                            <td colspan="5">Belum ada data menu. Klik tombol Tambah Menu untuk mulai menyimpan data.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($menus as $menu): ?>
                            <tr>
                                <td data-label="Foto">
                                    <?php if (!empty($menu['gambar'])): ?>
                                        <img src="<?php echo base_url('uploads/menus/' . rawurlencode($menu['gambar'])); ?>" alt="<?php echo html_escape($menu['nama']); ?>">
                                    <?php else: ?>
                                        <div class="empty-image">Tidak ada foto</div>
                                    <?php endif; ?>
                                </td>
                                <td data-label="Nama"><?php echo html_escape($menu['nama']); ?></td>
                                <td data-label="Deskripsi"><?php echo html_escape($menu['deskripsi']); ?></td>
                                <td data-label="Rating"><?php echo html_escape($menu['rating']); ?></td>
                                <td data-label="Aksi" class="menu-actions">
                                    <a class="edit" href="<?php echo base_url('index.php?c=menu&m=edit&id=' . $menu['id']); ?>">Edit</a>
                                    <a class="delete" href="<?php echo base_url('index.php?c=menu&m=delete&id=' . $menu['id']); ?>" onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
