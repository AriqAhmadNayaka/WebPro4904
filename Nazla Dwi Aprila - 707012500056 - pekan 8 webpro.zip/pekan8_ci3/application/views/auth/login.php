<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login EcoTaste CI3</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: linear-gradient(135deg, #d7f3d1, #8acb88); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .card { width: 100%; max-width: 380px; background: #fff; border-radius: 18px; padding: 32px; box-shadow: 0 18px 45px rgba(30, 80, 30, 0.18); }
        h1 { margin: 0 0 8px; color: #216f32; }
        p { margin: 0 0 20px; color: #5f6f61; }
        label { display: block; margin-bottom: 6px; font-weight: 700; color: #1f3f27; }
        input { width: 100%; box-sizing: border-box; padding: 12px 14px; margin-bottom: 16px; border: 1px solid #cbd9cb; border-radius: 10px; }
        button { width: 100%; border: 0; border-radius: 10px; padding: 12px; background: #2e8b57; color: #fff; font-weight: 700; cursor: pointer; }
        .alert { margin-bottom: 16px; padding: 12px 14px; border-radius: 10px; font-size: 14px; }
        .alert-error { background: #ffe1e1; color: #b42318; }
        .hint { margin-top: 14px; font-size: 13px; color: #6c7d6d; }
    </style>
</head>
<body>
    <div class="card">
        <h1>EcoTaste</h1>
        <p>Masuk untuk membuka dashboard dan mengelola data menu.</p>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-error"><?php echo $this->session->flashdata('error'); ?></div>
        <?php endif; ?>

        <?php echo validation_errors('<div class="alert alert-error">', '</div>'); ?>

        <?php echo form_open(base_url('index.php?c=auth&m=index')); ?>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" value="<?php echo set_value('username'); ?>" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
        <?php echo form_close(); ?>

        <div class="hint">Akun default: <strong>admin</strong> / <strong>admin</strong></div>
    </div>
</body>
</html>
