<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?> EcoTaste</title>
    <style>
        :root { --green: #2e8b57; --soft: #f3fbf3; --line: #d7e5d7; --danger: #b42318; }
        body { margin: 0; font-family: Arial, sans-serif; background: linear-gradient(180deg, #eef8ef, #ffffff); color: #203420; }
        .wrapper { width: min(760px, 92%); margin: 40px auto; }
        .card { background: #fff; border: 1px solid var(--line); border-radius: 20px; padding: 28px; box-shadow: 0 16px 30px rgba(46, 139, 87, 0.08); }
        h1 { margin-top: 0; color: #1c5d37; }
        p { color: #627662; }
        label { display: block; margin: 16px 0 8px; font-weight: 700; }
        input[type="text"], input[type="number"], textarea, input[type="file"] { width: 100%; box-sizing: border-box; border: 1px solid #cfe0cf; border-radius: 12px; padding: 12px 14px; font-size: 15px; }
        textarea { min-height: 130px; resize: vertical; }
        .alert { margin: 16px 0; padding: 12px 14px; border-radius: 12px; background: #ffe8e8; color: var(--danger); }
        .preview { margin-top: 10px; width: 120px; height: 120px; object-fit: cover; border-radius: 14px; border: 1px solid var(--line); }
        .actions { display: flex; gap: 12px; margin-top: 24px; flex-wrap: wrap; }
        .btn { border: 0; border-radius: 12px; padding: 12px 18px; font-weight: 700; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-primary { background: var(--green); color: #fff; }
        .btn-secondary { background: var(--soft); color: #204220; }
        small { display: block; margin-top: 8px; color: #6b7b6b; }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="card">
            <h1><?php echo html_escape($title); ?></h1>
            <p>Gunakan satu tombol <strong>Simpan</strong> untuk memproses input data sekaligus upload file gambar.</p>

            <?php echo validation_errors('<div class="alert">', '</div>'); ?>

            <?php if (!empty($upload_error)): ?>
                <div class="alert"><?php echo html_escape($upload_error); ?></div>
            <?php endif; ?>

            <?php echo form_open_multipart(base_url('index.php?c=menu&m=save')); ?>
                <input type="hidden" name="id" value="<?php echo set_value('id', isset($menu['id']) ? $menu['id'] : ''); ?>">

                <label for="nama">Nama Kuliner</label>
                <input type="text" id="nama" name="nama" value="<?php echo set_value('nama', isset($menu['nama']) ? $menu['nama'] : ''); ?>" required>

                <label for="deskripsi">Deskripsi</label>
                <textarea id="deskripsi" name="deskripsi" required><?php echo set_value('deskripsi', isset($menu['deskripsi']) ? $menu['deskripsi'] : ''); ?></textarea>

                <label for="rating">Rating</label>
                <input type="number" step="0.1" min="0" max="5" id="rating" name="rating" value="<?php echo set_value('rating', isset($menu['rating']) ? $menu['rating'] : ''); ?>" required>

                <label for="gambar">Foto Menu <?php echo isset($menu['id']) ? '(opsional saat edit)' : ''; ?></label>
                <input type="file" id="gambar" name="gambar" accept=".jpg,.jpeg,.png,.gif,.webp" <?php echo isset($menu['id']) ? '' : 'required'; ?>>
                <small>Format file: jpg, jpeg, png, gif, atau webp. Maksimal 2 MB.</small>

                <?php if (!empty($menu['gambar'])): ?>
                    <img class="preview" src="<?php echo base_url('uploads/menus/' . rawurlencode($menu['gambar'])); ?>" alt="<?php echo html_escape($menu['nama']); ?>">
                <?php endif; ?>

                <div class="actions">
                    <button class="btn btn-primary" type="submit">Simpan</button>
                    <a class="btn btn-secondary" href="<?php echo base_url('index.php?c=dashboard&m=index'); ?>">Kembali</a>
                </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</body>
</html>
