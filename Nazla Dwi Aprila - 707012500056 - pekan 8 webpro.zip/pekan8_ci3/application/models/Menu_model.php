<?php
defined('BASEPATH') OR exit('No direct script access allowed');//ini untuk mencegah akses langsung ke file ini tanpa melalui index.php

class Menu_model extends CI_Model//model Menu_model untuk mengelola data menu
{
    private $table = 'beranda';//nama tabel di database yang digunakan untuk menyimpan data menu

    public function get_all()//method get_all untuk mengambil semua data menu dari database
    {
        return $this->db
            ->order_by('id', 'DESC')
            ->get($this->table)
            ->result_array();
    }

    public function count_all()//methode count_all untuk menghitung jumlah data menu di database
    {
        return (int) $this->db->count_all($this->table);
    }

    public function get_average_rating()//methode get_average_rating untuk menghitung rata-rata rating dari semua menu di database
    {
        $row = $this->db
            ->select_avg('rating')
            ->get($this->table)
            ->row_array();

        return isset($row['rating']) ? (float) $row['rating'] : 0.0;
    }

    public function find($id)//method find untuk mengambil data menu berdasarkan id dari database
    {
        return $this->db
            ->get_where($this->table, array('id' => (int) $id), 1)
            ->row_array();
    }

    public function insert($data)//method insert untuk menyimpan data menu ke database
    {
        $this->db->insert($this->table, $data);

        return $this->db->insert_id();
    }

    public function update($id, $data)//
    {
        return $this->db
            ->where('id', (int) $id)
            ->update($this->table, $data);
    }

    public function delete($id)//method delete untuk menghapus data menu dari database
    {
        return $this->db
            ->where('id', (int) $id)
            ->delete($this->table);
    }
}
