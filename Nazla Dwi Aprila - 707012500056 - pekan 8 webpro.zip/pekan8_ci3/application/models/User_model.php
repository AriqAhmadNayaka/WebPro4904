<?php
defined('BASEPATH') OR exit('No direct script access allowed');//ini untuk mencegah akses langsung ke file ini tanpa melalui index.php

class User_model extends CI_Model//model User_model untuk mengelola data pengguna
{
    private $table = 'ecotaste';//nama tabel di database yang digunakan untuk menyimpan data pengguna

    public function get_by_username($username)//method get_by_username untuk mengambil data pengguna berdasarkan username dari database
    {
        return $this->db
            ->get_where($this->table, array('username' => $username), 1)
            ->row_array();
    }
}
