<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
    protected function require_login()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url('index.php?c=auth&m=index'), 'location');
        }
    }

    protected function redirect_if_logged_in()
    {
        if ($this->session->userdata('logged_in')) {
            redirect(base_url('index.php?c=dashboard&m=index'), 'location');
        }
    }
}
