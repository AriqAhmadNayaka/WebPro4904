<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post_model extends CI_Model {//model Post_model untuk mengelola data artikel
    private $table = 'posts';//nama tabel di database yang digunakan untuk menyimpan data artikel

    public function __construct() {//method constructor untuk memuat database
        parent::__construct();
        $this->load->database();
    }

    public function get_all() {//method get_all untuk mengambil semua data artikel dari database
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function get_by_id($id) {//method get_by_id untuk mengambil data artikel berdasarkan id dari database
        $query = $this->db->get_where($this->table, array('id' => $id));
        return $query->row();
    }

    public function insert($data) {//method insert untuk menyimpan data artikel ke database
        return $this->db->insert($this->table, $data);
    }

    public function update($id, $data) {//method update untuk mengupdate data artikel di database
        $this->db->where('id', $id);
        return $this->db->update($this->table, $data);
    }

    public function delete($id) {//method delete untuk menghapus data artikel dari database
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
    }
}