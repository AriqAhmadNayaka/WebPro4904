<?php
defined('BASEPATH') OR exit('No direct script access allowed');//ini untuk mencegah akses langsung ke file ini tanpa melalui index.php

class Dashboard extends MY_Controller //model Dashboard untuk menampilkan halaman dashboard dengan data menu
{
    public function __construct()//method constructor untuk memuat model Menu_model dan memastikan user sudah login
    {
        parent::__construct();
        $this->require_login();
        $this->load->model('Menu_model');
    }

    public function index()//method index untuk menampilkan halaman dashboard
    {
        $data = array(
            'menus' => $this->Menu_model->get_all(),
            'total_menu' => $this->Menu_model->count_all(),
            'average_rating' => $this->Menu_model->get_average_rating(),
        );

        $this->load->view('dashboard/index', $data);
    }
}
