<?php
defined('BASEPATH') OR exit('No direct script access allowed');//untuk mencegah file ini akses langusng ke index php

class Menu extends MY_Controller//controller Menu untuk mengelola data menu kuliner
{
    private $upload_path;//variabel untuk menyimpan path upload gambar menu

    public function __construct()//method constructor untuk memuat model Menu_model dan library upload
    {
        parent::__construct();
        $this->require_login();
        $this->load->model('Menu_model');
        $this->load->library('upload');
        $this->upload_path = FCPATH . 'uploads/menus/';
    }

    public function index()//method index untuk menampilkan daftar menu kuliner
    {
        redirect(base_url('index.php?c=dashboard&m=index'), 'location');
    }

    public function create()//method create untuk menampilkan form tambah menu kuliner
    {
        $data = array(
            'title' => 'Tambah Menu',
            'menu' => NULL,
        );

        $this->load->view('menu/form', $data);
    }

    public function edit()//method edit untuk menampilkan form edit menu kuliner
    {
        $id = (int) $this->input->get('id');
        $menu = $this->Menu_model->find($id);

        if (!$menu) {
            show_404();
        }

        $data = array(
            'title' => 'Edit Menu',
            'menu' => $menu,
        );

        $this->load->view('menu/form', $data);
    }

    public function save()//method save untuk menyimpan data menu kuliner baik untuk tambah maupun edit
    {
        $id = (int) $this->input->post('id');
        $existing = $id ? $this->Menu_model->find($id) : NULL;

        if ($id && !$existing) {
            show_404();
        }

        $this->form_validation->set_rules('nama', 'Nama Kuliner', 'trim|required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'trim|required');
        $this->form_validation->set_rules('rating', 'Rating', 'trim|required|numeric|greater_than_equal_to[0]|less_than_equal_to[5]');

        if (!$id && empty($_FILES['gambar']['name'])) {
            $this->form_validation->set_rules('gambar_required', 'Gambar', 'required', array(
                'required' => 'Foto menu wajib diunggah.',
            ));
        }

        if (!$this->form_validation->run()) {//jika validasi gagal, set flashdata error dan redirect kembali ke form tambah atau edit menu
            $data = array(
                'title' => $id ? 'Edit Menu' : 'Tambah Menu',
                'menu' => $existing,
            );
            $this->load->view('menu/form', $data);

            return;
        }

        $payload = array( //siapkan data menu untuk disimpan ke database
            'nama' => $this->input->post('nama', TRUE),
            'deskripsi' => $this->input->post('deskripsi', TRUE),
            'rating' => (float) $this->input->post('rating', TRUE),
        );

        $file_name = $existing ? $existing['gambar'] : '';

        if (!empty($_FILES['gambar']['name'])) {
            $uploaded = $this->do_upload();

            if ($uploaded === FALSE) {
                $data = array(
                    'title' => $id ? 'Edit Menu' : 'Tambah Menu',
                    'menu' => $existing,
                    'upload_error' => strip_tags($this->upload->display_errors()),
                );
                $this->load->view('menu/form', $data);

                return;
            }

            $file_name = $uploaded['file_name'];
            if ($existing && !empty($existing['gambar'])) {
                $this->delete_file($existing['gambar']);
            }
        }

        $payload['gambar'] = $file_name;

        if ($id) {
            $this->Menu_model->update($id, $payload);
            $message = 'Data menu berhasil diperbarui.';
        } else {
            $this->Menu_model->insert($payload);
            $message = 'Data menu berhasil disimpan.';
        }

        $this->session->set_flashdata('success', $message);
        redirect(base_url('index.php?c=dashboard&m=index'), 'location');
    }

    public function delete()//method delete untuk menghapus data menu kuliner
    {
        $id = (int) $this->input->get('id');
        $menu = $this->Menu_model->find($id);

        if (!$menu) {
            show_404();
        }

        if ($this->Menu_model->delete($id) && !empty($menu['gambar'])) {
            $this->delete_file($menu['gambar']);
        }

        $this->session->set_flashdata('success', 'Data menu berhasil dihapus.');
        redirect(base_url('index.php?c=dashboard&m=index'), 'location');
    }

    private function do_upload()//method do_upload untuk memproses upload gambar menu kuliner
    {
        if (!is_dir($this->upload_path)) {
            mkdir($this->upload_path, 0777, TRUE);
        }

        $config = array(
            'upload_path' => $this->upload_path,
            'allowed_types' => 'jpg|jpeg|png|gif|webp',
            'max_size' => 2048,
            'encrypt_name' => TRUE,
        );

        $this->upload->initialize($config);

        if (!$this->upload->do_upload('gambar')) {
            return FALSE;
        }

        return $this->upload->data();
    }

    private function delete_file($file_name)//method delete_file untuk menghapus file gambar menu kuliner dari server
    {
        $file_path = $this->upload_path . $file_name;

        if (is_file($file_path)) {
            unlink($file_path);
        }
    }
}
