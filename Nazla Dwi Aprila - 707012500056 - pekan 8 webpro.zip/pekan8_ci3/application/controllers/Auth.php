<?php
defined('BASEPATH') OR exit('No direct script access allowed');//ini untuk mencegah akses langsung ke file ini tanpa melalui index.php

class Auth extends MY_Controller
{
    public function __construct()//method constructor untuk memuat model User_model
    {
        parent::__construct();
        $this->load->model('User_model');
    }

    public function index()
    {
        $this->redirect_if_logged_in();//redirect ke dashboard jika sudah login

        if ($this->input->method() === 'post') {
            $this->form_validation->set_rules('username', 'Username', 'trim|required');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');

            if ($this->form_validation->run()) {
                $username = $this->input->post('username', TRUE);
                $password = $this->input->post('password', TRUE);
                $user = $this->User_model->get_by_username($username);

                if ($user && $password === $user['password']) {
                    $this->session->set_userdata(array(
                        'logged_in' => TRUE,
                        'username' => $user['username'],
                    ));

                    redirect(base_url('index.php?c=dashboard&m=index'), 'location');
                }
            }

            $this->session->set_flashdata('error', 'Username atau password salah.');
            redirect(base_url('index.php?c=auth&m=index'), 'location');
        }

        $this->load->view('auth/login');
    }

    public function logout()//method logout untuk menghapus session dan redirect ke halaman login
    {
        $this->session->sess_destroy();
        redirect(base_url('index.php?c=auth&m=index'), 'location');
    }
}
