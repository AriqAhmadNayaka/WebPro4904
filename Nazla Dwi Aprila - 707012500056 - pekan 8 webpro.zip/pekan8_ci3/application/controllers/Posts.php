<?php
defined('BASEPATH') OR exit('No direct script access allowed');//ini untuk mencegah akses langsung ke file ini tanpa melalui index.php

class Posts extends CI_Controller {//controller Posts untuk mengelola data artikel
    public function __construct() {//method constructor untuk memuat model Post_model, helper url dan form, serta library form_validation, upload, dan session
        parent::__construct();
        $this->load->model('Post_model');
        $this->load->helper(array('url', 'form'));
        $this->load->library(array('form_validation', 'upload', 'session'));
    }

    public function index() {//method index untuk menampilkan daftar artikel
        $data['posts'] = $this->Post_model->get_all();
        $data['title'] = 'All Posts';
        $this->load->view('posts/index', $data);
    }

    public function create() {//method create untuk menampilkan form tambah artikel
        $data['title'] = 'Create New Post';
        $this->load->view('posts/create', $data);
    }

    public function store() {//method store untuk menyimpan data artikel yang dikirim dari form tambah artikel
        $this->form_validation->set_rules('title', 'Title', 'required|max_length[255]');
        $this->form_validation->set_rules('author', 'Author', 'required|max_length[255]');
        $this->form_validation->set_rules('article', 'Article', 'required');

        if ($this->form_validation->run() == FALSE) {//jika validasi gagal, set flashdata error dan redirect kembali ke form tambah artikel
            $this->session->set_flashdata('error', validation_errors());
            redirect('posts/create');
            return;
        }

        $data = array(//siapkan data untuk disimpan ke database
            'title' => $this->input->post('title'),
            'author' => $this->input->post('author'),
            'article' => $this->input->post('article'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );

        $post_id = $this->Post_model->insert($data);//simpan data artikel ke database menggunakan model Post_model
        if ($post_id) {
            $this->session->set_flashdata('success', 'Post created successfully!');
            redirect('posts');
        } else {
            $this->session->set_flashdata('error', 'Failed to create post');
            redirect('posts/create');
        }
    }
}
