CREATE DATABASE IF NOT EXISTS pekan6;
USE pekan6;

CREATE TABLE IF NOT EXISTS ecotaste (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS beranda (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    deskripsi TEXT NOT NULL,
    rating DECIMAL(2,1) NOT NULL,
    gambar VARCHAR(255) NOT NULL
);

INSERT INTO ecotaste (username, password)
SELECT 'admin', 'admin'
WHERE NOT EXISTS (
    SELECT 1 FROM ecotaste WHERE username = 'admin'
);
