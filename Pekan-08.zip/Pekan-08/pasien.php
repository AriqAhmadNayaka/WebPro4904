<?php
class Pasien {
    private $conn;

    public function __construct($db){
        $this->conn = $db;
    }

    public function simpan($data, $file){
        $nama = $data['nama'];
        $tanggal = $data['tanggal'];
        $jk = $data['jk'];
        $berat = $data['berat'];
        $tinggi = $data['tinggi'];
        $lingkar = $data['lingkar'];

        $namaFile = $file['name'];
        $tmp = $file['tmp_name'];
        move_uploaded_file($tmp, "upload/".$namaFile);

        $query = "INSERT INTO pasien
        (nama, tanggal, jk, berat, tinggi, lingkar, file)
        VALUES ('$nama','$tanggal','$jk','$berat','$tinggi','$lingkar','$namaFile')";

        return $this->conn->query($query);
    }

    public function tampil(){
        return $this->conn->query("SELECT * FROM pasien");
    }

    public function hapus($id){
        return $this->conn->query("DELETE FROM pasien WHERE id=$id");
    }

    public function getById($id){
        $result = $this->conn->query("SELECT * FROM pasien WHERE id=$id");
        return $result->fetch_assoc();
    }
}

function update($id, $data, $file){
    $nama = $data['nama'];
    $tanggal = $data['tanggal'];
    $jk = $data['jk'];
    $berat = $data['berat'];
    $tinggi = $data['tinggi'];
    $lingkar = $data['lingkar'];

    if($file['name'] != ""){
        $namaFile = $file['name'];
        $tmp = $file['tmp_name'];
        move_uploaded_file($tmp, "upload/".$namaFile);

        $query = "UPDATE pasien SET
            nama='$nama',
            tanggal='$tanggal',
            jk='$jk',
            berat='$berat',
            tinggi='$tinggi',
            lingkar='$lingkar',
            file='$namaFile'
            WHERE id=$id";
    } else {
        $query = "UPDATE pasien SET
            nama='$nama',
            tanggal='$tanggal',
            jk='$jk',
            berat='$berat',
            tinggi='$tinggi',
            lingkar='$lingkar'
            WHERE id=$id";
    }

    return $this->conn->query($query);
}

function getById($id){
    $result = $this->conn->query("SELECT * FROM pasien WHERE id=$id");
    return $result->fetch_assoc();
}
?>
