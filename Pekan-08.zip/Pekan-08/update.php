<?php
include "koneksi.php";
include "Pasien.php";

$db = new Koneksi();
$pasien = new Pasien($db->conn);

$id = $_GET['id'];

$pasien->update($id, $_POST, $_FILES['file']);

header("Location: inputdata.php");
?>
