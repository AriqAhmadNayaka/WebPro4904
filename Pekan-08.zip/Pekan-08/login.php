<style>
    :root {
    --main-color: #4a6fa5;
    --glass-bg: rgba(255, 255, 255, 0.4);
    --input-bg: rgba(255, 255, 255, 0.8);
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #e3f2fd, #f8f9fa);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.login-container {
    width: 350px;
    padding: 40px;
    border-radius: 20px;
    background: var(--glass-bg);
    backdrop-filter: blur(10px);
    box-shadow: 0 8px 32px rgba(0,0,0,0.1);
    text-align: center;
}

.login-container h2 {
    margin-bottom: 30px;
    color: #333;
}

.login-container input {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
    border-radius: 10px;
    border: none;
    background: var(--input-bg);
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.login-container input:focus {
    outline: none;
    background: white;
    box-shadow: 0 0 0 3px rgba(74,111,165,0.3);
}

.login-container button {
    width: 100%;
    padding: 12px;
    border-radius: 12px;
    border: none;
    background: rgba(0,123,255,0.85);
    color: white;
    font-weight: bold;
    cursor: pointer;
    transition: 0.3s;
}

.login-container button:hover {
    background: rgba(0,123,255,1);
}
</style>

<?php
session_start();

if(isset($_POST['login'])){
    $user = $_POST['username'];
    $pass = $_POST['password'];
 
    if($user == "admin" && $pass == "123"){
        $_SESSION['login'] = true;
        header("Location: inputdata.php");
        exit;
    } else {
        echo "<script>alert('Login gagal!');</script>";
    }
}
?>

<div class="login-container">
    <h2 class="login-title">Login</h2>
    
    <form method="POST">
        <input type="text" name="username" class="login-input" placeholder="Username">
        
        <input type="password" name="password" class="login-input" placeholder="Password">
        
        <button class="btn-login" name="login">Login</button>
    </form>
</div>
