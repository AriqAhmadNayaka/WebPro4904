<?php
$conn = mysqli_connect("localhost", "root", "", "db_pasien");

$nama = $_POST['nama'];
$tanggal = $_POST['tanggal'];
$jk = $_POST['jk'];
$berat = $_POST['berat'];
$tinggi = $_POST['tinggi'];
$lingkar = $_POST['lingkar'];

$namaFile = $_FILES['file']['name'];
$tmp = $_FILES['file']['tmp_name'];

move_uploaded_file($tmp, "upload/" . $namaFile);

$query = "INSERT INTO pasien
(nama, tanggal, jk, berat, tinggi, lingkar, file)
VALUES
('$nama','$tanggal','$jk','$berat','$tinggi','$lingkar','$namaFile')";

mysqli_query($conn, $query);

echo "sukses";
?>
