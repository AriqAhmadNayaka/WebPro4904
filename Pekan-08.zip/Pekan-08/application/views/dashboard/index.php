<!DOCTYPE html> <!-- Menetapkan dokumen sebagai HTML5. -->
<html lang="id"> <!-- Menentukan bahasa utama halaman adalah Indonesia. -->
<head> <!-- Membuka bagian metadata halaman. -->
    <meta charset="utf-8"> <!-- Mengatur encoding karakter ke UTF-8. -->
    <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- Menyesuaikan tampilan agar responsif di perangkat mobile. -->
    <title><?php echo html_escape($title); ?></title> <!-- Menampilkan judul halaman dari variabel PHP dengan aman. -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/app.css'); ?>"> <!-- Memuat file CSS utama dashboard. -->
</head> <!-- Menutup bagian metadata halaman. -->
<body class="dashboard-body"> <!-- Membuka body halaman dengan kelas khusus dashboard. -->
<?php // Memulai blok PHP untuk menyiapkan data awal view.
$selected_patient = isset($selected_patient) ? $selected_patient : NULL; // Menyimpan data pasien terpilih atau NULL jika belum ada.
$selected_gender = set_value('jk', $selected_patient ? $selected_patient['jk'] : ''); // Menentukan nilai default jenis kelamin pada form.
?> <!-- Menutup blok PHP persiapan data. -->
    <div class="dashboard-container"> <!-- Membungkus seluruh area dashboard. -->
        <aside class="sidebar"> <!-- Membuka sidebar navigasi. -->
            <a href="<?php echo site_url('dashboard'); ?>" class="sidebar-logo"> <!-- Membuat tautan logo ke halaman dashboard. -->
            <img src="<?php echo base_url('logo Nuids..png'); ?>" alt="Logo" width="40"> <!-- Menampilkan gambar logo aplikasi. -->
            </a> <!-- Menutup tautan logo. -->
            <nav class="sidebar-nav"> <!-- Membuka navigasi utama sidebar. -->
                <a href="<?php echo site_url('dashboard'); ?>" class="nav-item active">Home</a> <!-- Menampilkan menu Home sebagai menu aktif. -->
                <a href="#form-pasien" class="nav-item">Form</a> <!-- Menambahkan menu menuju bagian form pasien. -->
                <a href="#data-pasien" class="nav-item">Data</a> <!-- Menambahkan menu menuju tabel data pasien. -->
            </nav> <!-- Menutup navigasi sidebar. -->
            <div class="sidebar-bottom"> <!-- Membuka area bawah sidebar untuk profil dan logout. -->
                <div class="user-avatar-small"> <!-- Membuka wadah avatar kecil pengguna. -->
                    <?php echo strtoupper(substr($this->session->userdata('username'), 0, 1)); ?> <!-- Menampilkan huruf pertama username dalam huruf kapital. -->
                </div> <!-- Menutup wadah avatar kecil. -->
                <a href="<?php echo site_url('logout'); ?>" class="nav-item nav-item-logout">Out</a> <!-- Menambahkan tombol keluar dari sesi login. -->
            </div> <!-- Menutup area bawah sidebar. -->
        </aside> <!-- Menutup sidebar. -->

        <main class="main-content"> <!-- Membuka area konten utama dashboard. -->
            <div class="page-header"> <!-- Membuka bagian header halaman. -->
                <div> <!-- Membuka wadah teks judul halaman. -->
                    <h1 class="page-title">Input Data Pasien</h1> <!-- Menampilkan judul utama halaman. -->
                    <p class="page-subtitle"> <!-- Membuka subtitle yang menampilkan info login. -->
                        Login sebagai <strong><?php echo html_escape($this->session->userdata('nama_lengkap')); ?></strong> <!-- Menampilkan nama lengkap pengguna yang sedang login. -->
                        (<?php echo html_escape($this->session->userdata('username')); ?>) <!-- Menampilkan username pengguna yang sedang login. -->
                    </p> <!-- Menutup subtitle halaman. -->
                </div> <!-- Menutup wadah teks judul halaman. -->
            </div> <!-- Menutup header halaman. -->

            <section class="stats-grid"> <!-- Membuka bagian ringkasan statistik pasien. -->
                <article class="stat-box"> <!-- Membuka kartu statistik total data. -->
                    <span>Total Data</span> <!-- Menampilkan label total data pasien. -->
                    <strong><?php echo (int) $stats['total']; ?></strong> <!-- Menampilkan jumlah seluruh data pasien. -->
                </article> <!-- Menutup kartu statistik total data. -->
                <article class="stat-box"> <!-- Membuka kartu statistik pasien laki-laki. -->
                    <span>Pasien Laki-laki</span> <!-- Menampilkan label jumlah pasien laki-laki. -->
                    <strong><?php echo (int) $stats['laki_laki']; ?></strong> <!-- Menampilkan total pasien laki-laki. -->
                </article> <!-- Menutup kartu statistik pasien laki-laki. -->
                <article class="stat-box"> <!-- Membuka kartu statistik pasien perempuan. -->
                    <span>Pasien Perempuan</span> <!-- Menampilkan label jumlah pasien perempuan. -->
                    <strong><?php echo (int) $stats['perempuan']; ?></strong> <!-- Menampilkan total pasien perempuan. -->
                </article> <!-- Menutup kartu statistik pasien perempuan. -->
            </section> <!-- Menutup bagian statistik. -->

            <?php if ($this->session->flashdata('success')): ?> <!-- Mengecek apakah ada pesan sukses di session. -->
                <div class="alert alert-success"><?php echo html_escape($this->session->flashdata('success')); ?></div> <!-- Menampilkan notifikasi sukses ke pengguna. -->
            <?php endif; ?> <!-- Menutup pengecekan pesan sukses. -->

            <?php if ($this->session->flashdata('error')): ?> <!-- Mengecek apakah ada pesan error di session. -->
                <div class="alert alert-danger"><?php echo html_escape($this->session->flashdata('error')); ?></div> <!-- Menampilkan notifikasi error ke pengguna. -->
            <?php endif; ?> <!-- Menutup pengecekan pesan error. -->

            <?php if (validation_errors()): ?> <!-- Mengecek apakah form memiliki error validasi. -->
                <div class="alert alert-danger"> <!-- Membuka kotak peringatan untuk error validasi. -->
                    <ul class="error-list"><?php echo validation_errors(); ?></ul> <!-- Menampilkan daftar error validasi dari form. -->
                </div> <!-- Menutup kotak error validasi. -->
            <?php endif; ?> <!-- Menutup pengecekan error validasi. -->

            <?php if (!empty($upload_error)): ?> <!-- Mengecek apakah ada error saat upload file. -->
                <div class="alert alert-danger"><?php echo html_escape($upload_error); ?></div> <!-- Menampilkan pesan error upload file. -->
            <?php endif; ?> <!-- Menutup pengecekan error upload. -->

            <section id="form-pasien" class="glass-section input-form-section"> <!-- Membuka bagian form input pasien. -->
                <div class="section-header"> <!-- Membuka header bagian form. -->
                    <div> <!-- Membuka wadah judul bagian form. -->
                        <p class="section-kicker"><?php echo $selected_patient ? 'Mode Edit' : 'Input Baru'; ?></p> <!-- Menampilkan status mode form, edit atau input baru. -->
                        <h2 class="section-title"><?php echo $selected_patient ? 'Ubah Data Pasien' : 'Tambah Data Pasien'; ?></h2> <!-- Menampilkan judul form sesuai mode. -->
                    </div> <!-- Menutup wadah judul bagian form. -->
                    <?php if ($selected_patient): ?> <!-- Mengecek apakah form sedang dalam mode edit. -->
                        <a href="<?php echo site_url('dashboard'); ?>" class="btn-secondary-link">Batal Edit</a> <!-- Menampilkan tombol untuk membatalkan mode edit. -->
                    <?php endif; ?> <!-- Menutup pengecekan mode edit. -->
                </div> <!-- Menutup header bagian form. -->

                <?php echo form_open_multipart('dashboard/save', array('class' => 'patient-form')); ?> <!-- Membuka form dengan dukungan upload file. -->
                    <?php if ($selected_patient): ?> <!-- Mengecek apakah perlu menyisipkan ID pasien saat edit. -->
                        <input type="hidden" name="id" value="<?php echo (int) $selected_patient['id']; ?>"> <!-- Menyimpan ID pasien secara tersembunyi untuk proses update. -->
                    <?php endif; ?> <!-- Menutup pengecekan input ID tersembunyi. -->

                    <div class="input-grid"> <!-- Membuka grid tata letak untuk field input. -->
                        <div class="input-group"> <!-- Membuka grup input nama pasien. -->
                            <label for="nama">Nama Pasien</label> <!-- Menampilkan label untuk field nama. -->
                            <input id="nama" type="text" name="nama" value="<?php echo set_value('nama', $selected_patient ? $selected_patient['nama'] : ''); ?>" placeholder="Contoh: Haikal Syawal"> <!-- Menyediakan input teks untuk nama pasien. -->
                        </div> <!-- Menutup grup input nama pasien. -->

                        <div class="input-group"> <!-- Membuka grup input tanggal lahir. -->
                            <label for="tanggal">Tanggal Lahir</label> <!-- Menampilkan label untuk field tanggal lahir. -->
                            <input id="tanggal" type="date" name="tanggal" value="<?php echo set_value('tanggal', $selected_patient ? $selected_patient['tanggal'] : ''); ?>"> <!-- Menyediakan input tanggal lahir pasien. -->
                        </div> <!-- Menutup grup input tanggal lahir. -->

                        <div class="input-group"> <!-- Membuka grup input jenis kelamin. -->
                            <label for="jk">Jenis Kelamin</label> <!-- Menampilkan label untuk pilihan jenis kelamin. -->
                            <select id="jk" name="jk"> <!-- Membuka elemen pilihan jenis kelamin. -->
                                <option value="">Pilih jenis kelamin</option> <!-- Menampilkan opsi default yang belum dipilih. -->
                                <option value="Laki-laki" <?php echo $selected_gender === 'Laki-laki' ? 'selected' : ''; ?>>Laki-laki</option> <!-- Menampilkan opsi laki-laki dan memilihnya bila sesuai data. -->
                                <option value="Perempuan" <?php echo $selected_gender === 'Perempuan' ? 'selected' : ''; ?>>Perempuan</option> <!-- Menampilkan opsi perempuan dan memilihnya bila sesuai data. -->
                            </select> <!-- Menutup elemen pilihan jenis kelamin. -->
                        </div> <!-- Menutup grup input jenis kelamin. -->

                        <div class="input-group"> <!-- Membuka grup input berat badan. -->
                            <label for="berat">Berat Badan (kg)</label> <!-- Menampilkan label untuk field berat badan. -->
                            <input id="berat" type="text" name="berat" value="<?php echo set_value('berat', $selected_patient ? $selected_patient['berat'] : ''); ?>" placeholder="Contoh: 45"> <!-- Menyediakan input berat badan pasien. -->
                        </div> <!-- Menutup grup input berat badan. -->

                        <div class="input-group"> <!-- Membuka grup input tinggi badan. -->
                            <label for="tinggi">Tinggi Badan (cm)</label> <!-- Menampilkan label untuk field tinggi badan. -->
                            <input id="tinggi" type="text" name="tinggi" value="<?php echo set_value('tinggi', $selected_patient ? $selected_patient['tinggi'] : ''); ?>" placeholder="Contoh: 155"> <!-- Menyediakan input tinggi badan pasien. -->
                        </div> <!-- Menutup grup input tinggi badan. -->

                        <div class="input-group"> <!-- Membuka grup input lingkar kepala. -->
                            <label for="lingkar">Lingkar Kepala (cm)</label> <!-- Menampilkan label untuk field lingkar kepala. -->
                            <input id="lingkar" type="text" name="lingkar" value="<?php echo set_value('lingkar', $selected_patient ? $selected_patient['lingkar'] : ''); ?>" placeholder="Contoh: 45"> <!-- Menyediakan input lingkar kepala pasien. -->
                        </div> <!-- Menutup grup input lingkar kepala. -->

                        <div class="input-group input-group-wide"> <!-- Membuka grup input file pendukung. -->
                            <label for="file_pendukung">Upload Foto / File Pendukung</label> <!-- Menampilkan label untuk upload file pendukung. -->
                            <input id="file_pendukung" type="file" name="file_pendukung" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx"> <!-- Menyediakan input file dengan format yang diizinkan. -->
                            <small class="file-note"> <!-- Membuka catatan kecil tentang aturan upload. -->
                                Format: JPG, JPEG, PNG, PDF, DOC, DOCX. Maksimal 4 MB. <!-- Menampilkan keterangan format dan ukuran file maksimum. -->
                                <?php if ($selected_patient && !empty($selected_patient['file'])): ?> <!-- Mengecek apakah ada file lama saat mode edit. -->
                                    File saat ini: <strong><?php echo html_escape($selected_patient['file']); ?></strong> <!-- Menampilkan nama file yang saat ini tersimpan. -->
                                <?php endif; ?> <!-- Menutup pengecekan file lama. -->
                            </small> <!-- Menutup catatan aturan upload. -->
                        </div> <!-- Menutup grup input file pendukung. -->

                        <div class="input-group submit-group"> <!-- Membuka grup tombol aksi form. -->
                            <button type="submit" class="btn-submit">Simpan</button> <!-- Menampilkan tombol untuk menyimpan data pasien. -->
                            <a href="<?php echo site_url('dashboard'); ?>" class="btn-reset">Reset</a> <!-- Menampilkan tombol untuk mereset form ke halaman dashboard. -->
                        </div> <!-- Menutup grup tombol aksi form. -->
                    </div> <!-- Menutup grid input form. -->
                <?php echo form_close(); ?> <!-- Menutup form input pasien. -->
            </section> <!-- Menutup bagian form pasien. -->

            <section id="data-pasien" class="glass-section data-table-section"> <!-- Membuka bagian tabel data pasien. -->
                <div class="section-header"> <!-- Membuka header bagian data pasien. -->
                    <div> <!-- Membuka wadah judul bagian data. -->
                        <p class="section-kicker">Daftar Pasien</p> <!-- Menampilkan label pengantar bagian data. -->
                        <h2 class="section-title">Data Tersimpan</h2> <!-- Menampilkan judul tabel data pasien. -->
                    </div> <!-- Menutup wadah judul bagian data. -->
                </div> <!-- Menutup header bagian data pasien. -->

                <div class="table-responsive"> <!-- Membuka pembungkus tabel agar responsif. -->
                    <table class="data-pasien-table"> <!-- Membuka tabel data pasien. -->
                        <thead> <!-- Membuka bagian kepala tabel. -->
                            <tr> <!-- Membuka baris header tabel. -->
                                <th>Nama</th> <!-- Menampilkan kolom header nama pasien. -->
                                <th>Tanggal Lahir</th> <!-- Menampilkan kolom header tanggal lahir. -->
                                <th>Jenis Kelamin</th> <!-- Menampilkan kolom header jenis kelamin. -->
                                <th>Berat</th> <!-- Menampilkan kolom header berat badan. -->
                                <th>Tinggi</th> <!-- Menampilkan kolom header tinggi badan. -->
                                <th>Lingkar</th> <!-- Menampilkan kolom header lingkar kepala. -->
                                <th>File</th> <!-- Menampilkan kolom header file pendukung. -->
                                <th>Aksi</th> <!-- Menampilkan kolom header aksi. -->
                            </tr> <!-- Menutup baris header tabel. -->
                        </thead> <!-- Menutup kepala tabel. -->
                        <tbody> <!-- Membuka isi tabel data pasien. -->
                        <?php if (empty($patients)): ?> <!-- Mengecek apakah data pasien masih kosong. -->
                            <tr> <!-- Membuka baris untuk kondisi data kosong. -->
                                <td colspan="8" class="empty-state">Belum ada data pasien.</td> <!-- Menampilkan pesan saat belum ada data pasien. -->
                            </tr> <!-- Menutup baris kondisi data kosong. -->
                        <?php else: ?> <!-- Menandai bahwa data pasien tersedia untuk ditampilkan. -->
                            <?php foreach ($patients as $patient): ?> <!-- Memulai perulangan untuk setiap data pasien. -->
                                <tr> <!-- Membuka baris tabel untuk satu pasien. -->
                                    <td><?php echo html_escape($patient['nama']); ?></td> <!-- Menampilkan nama pasien. -->
                                    <td><?php echo html_escape($patient['tanggal']); ?></td> <!-- Menampilkan tanggal lahir pasien. -->
                                    <td><?php echo html_escape($patient['jk']); ?></td> <!-- Menampilkan jenis kelamin pasien. -->
                                    <td><?php echo html_escape($patient['berat']); ?> kg</td> <!-- Menampilkan berat badan pasien dalam kilogram. -->
                                    <td><?php echo html_escape($patient['tinggi']); ?> cm</td> <!-- Menampilkan tinggi badan pasien dalam sentimeter. -->
                                    <td><?php echo html_escape($patient['lingkar']); ?> cm</td> <!-- Menampilkan lingkar kepala pasien dalam sentimeter. -->
                                    <td> <!-- Membuka kolom file pendukung pasien. -->
                                        <?php if (!empty($patient['file'])): ?> <!-- Mengecek apakah pasien memiliki file pendukung. -->
                                            <a href="<?php echo base_url('uploads/'.$patient['file']); ?>" target="_blank" class="table-link">Lihat File</a> <!-- Menampilkan tautan untuk membuka file pendukung. -->
                                        <?php else: ?> <!-- Menangani kondisi saat file pendukung tidak tersedia. -->
                                            <span class="subtle-text">Tidak ada</span> <!-- Menampilkan teks bahwa file belum tersedia. -->
                                        <?php endif; ?> <!-- Menutup pengecekan file pendukung. -->
                                    </td> <!-- Menutup kolom file pendukung. -->
                                    <td> <!-- Membuka kolom aksi untuk pasien. -->
                                        <div class="table-actions"> <!-- Membuka wadah tombol aksi tabel. -->
                                            <a href="<?php echo site_url('dashboard').'?edit='.(int) $patient['id']; ?>" class="btn-table btn-table-edit">Edit</a> <!-- Menampilkan tombol untuk mengedit data pasien. -->
                                            <a href="<?php echo site_url('dashboard/delete/'.(int) $patient['id']); ?>" class="btn-table btn-table-delete" onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a> <!-- Menampilkan tombol untuk menghapus data pasien dengan konfirmasi. -->
                                        </div> <!-- Menutup wadah tombol aksi tabel. -->
                                    </td> <!-- Menutup kolom aksi. -->
                                </tr> <!-- Menutup baris data satu pasien. -->
                            <?php endforeach; ?> <!-- Menutup perulangan data pasien. -->
                        <?php endif; ?> <!-- Menutup pengecekan kondisi data pasien. -->
                        </tbody> <!-- Menutup isi tabel. -->
                    </table> <!-- Menutup tabel data pasien. -->
                </div> <!-- Menutup pembungkus tabel responsif. -->
            </section> <!-- Menutup bagian data pasien. -->
        </main> <!-- Menutup konten utama dashboard. -->
    </div> <!-- Menutup pembungkus utama dashboard. -->
</body> <!-- Menutup body halaman. -->
<!-- Menutup dokumen HTML. --></html>
