<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo html_escape($title); ?></title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/app.css'); ?>">
</head>
<body class="auth-body">
    <div class="login-container">
        <h2 class="login-title">Login</h2>
        <p class="login-copy">Masuk terlebih dahulu untuk membuka dashboard data pasien.</p>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success"><?php echo html_escape($this->session->flashdata('success')); ?></div>
        <?php endif; ?>

        <?php if ($auth_error): ?>
            <div class="alert alert-danger"><?php echo html_escape($auth_error); ?></div>
        <?php endif; ?>

        <?php if (validation_errors()): ?>
            <div class="alert alert-danger">
                <ul class="error-list"><?php echo validation_errors(); ?></ul>
            </div>
        <?php endif; ?>

        <?php echo form_open('login', array('class' => 'login-form')); ?>
            <div class="field">
                <label for="username">Username</label>
                <input id="username" type="text" name="username" value="<?php echo set_value('username'); ?>" placeholder="Masukkan username">
            </div>

            <div class="field">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" placeholder="Masukkan password">
            </div>

            <button type="submit" class="btn-submit">Login</button>
        <?php echo form_close(); ?>

        <p class="login-hint">Akun demo: <strong>admin</strong> / <strong>admin123</strong></p>
    </div>
</body>
</html>
