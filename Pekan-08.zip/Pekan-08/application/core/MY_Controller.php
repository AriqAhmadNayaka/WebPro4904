<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
    protected function is_logged_in()
    {
        return (bool) $this->session->userdata('is_logged_in');
    }

    protected function require_login()
    {
        if (!$this->is_logged_in()) {
            redirect('login');
        }
    }

    protected function redirect_if_authenticated()
    {
        if ($this->is_logged_in()) {
            redirect('dashboard');
        }
    }
}
