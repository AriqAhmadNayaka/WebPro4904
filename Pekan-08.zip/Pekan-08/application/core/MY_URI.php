<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_URI extends CI_URI
{
    protected function _parse_request_uri()
    {
        if (!isset($_SERVER['REQUEST_URI'], $_SERVER['SCRIPT_NAME'])) {
            return '';
        }

        $uri_parts = parse_url('http://dummy'.$_SERVER['REQUEST_URI']);
        $query = isset($uri_parts['query']) ? $uri_parts['query'] : '';
        $uri = isset($uri_parts['path']) ? $uri_parts['path'] : '';

        if (isset($_SERVER['SCRIPT_NAME'][0])) {
            $script_name = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
            $script_dir = str_replace('\\', '/', dirname($script_name));
            $stripped = FALSE;

            foreach (array($script_name, $this->encode_path($script_name)) as $candidate) {
                if ($candidate !== '' && strpos($uri, $candidate) === 0) {
                    $uri = (string) substr($uri, strlen($candidate));
                    $stripped = TRUE;
                    break;
                }
            }

            if (!$stripped) {
                foreach (array($script_dir, $this->encode_path($script_dir)) as $candidate) {
                    if ($candidate !== '' && $candidate !== '.' && strpos($uri, $candidate) === 0) {
                        $uri = (string) substr($uri, strlen($candidate));
                        break;
                    }
                }
            }
        }

        if (trim($uri, '/') === '' && strncmp($query, '/', 1) === 0) {
            $query = explode('?', $query, 2);
            $uri = $query[0];
            $_SERVER['QUERY_STRING'] = isset($query[1]) ? $query[1] : '';
        } else {
            $_SERVER['QUERY_STRING'] = $query;
        }

        parse_str($_SERVER['QUERY_STRING'], $_GET);

        if ($uri === '/' OR $uri === '') {
            return '/';
        }

        return $this->_remove_relative_directory($uri);
    }

    private function encode_path($path)
    {
        $segments = explode('/', $path);

        foreach ($segments as &$segment) {
            $segment = rawurlencode(rawurldecode($segment));
        }

        return implode('/', $segments);
    }
}
