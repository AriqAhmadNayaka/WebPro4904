<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->require_login();
        $this->load->model('Patient_model', 'patients');
        $this->form_validation->set_error_delimiters('<li>', '</li>');
        $this->form_validation->set_message('required', '%s wajib diisi.');
        $this->form_validation->set_message('in_list', '%s tidak valid.');
        $this->form_validation->set_message('max_length', '%s terlalu panjang.');
    }

    public function index()
    {
        $edit_id = (int) $this->input->get('edit');
        $selected_patient = NULL;

        if ($edit_id > 0) {
            $selected_patient = $this->patients->find($edit_id);

            if (!$selected_patient) {
                $this->session->set_flashdata('error', 'Data pasien yang dipilih tidak ditemukan.');
                redirect('dashboard');
            }
        }

        $this->render_dashboard($selected_patient);
    }

    public function save()
    {
        $id = (int) $this->input->post('id');
        $selected_patient = $id > 0 ? $this->patients->find($id) : NULL;

        if ($id > 0 && !$selected_patient) {
            $this->session->set_flashdata('error', 'Data pasien yang akan diubah tidak ditemukan.');
            redirect('dashboard');
        }

        $this->set_patient_rules();

        if (!$this->form_validation->run()) {
            return $this->render_dashboard($selected_patient);
        }

        $uploaded_file = $this->handle_upload($selected_patient);

        if (isset($uploaded_file['error'])) {
            return $this->render_dashboard($selected_patient, $uploaded_file['error']);
        }

        $payload = array(
            'nama' => $this->input->post('nama', TRUE),
            'tanggal' => $this->input->post('tanggal', TRUE),
            'jk' => $this->input->post('jk', TRUE),
            'berat' => $this->input->post('berat', TRUE),
            'tinggi' => $this->input->post('tinggi', TRUE),
            'lingkar' => $this->input->post('lingkar', TRUE),
            'file' => $selected_patient ? $selected_patient['file'] : NULL,
        );

        if (isset($uploaded_file['file_name'])) {
            $payload['file'] = $uploaded_file['file_name'];
        }

        $saved = $id > 0
            ? $this->patients->update($id, $payload)
            : $this->patients->create($payload);

        if (!$saved) {
            if (isset($uploaded_file['file_name'])) {
                $this->delete_uploaded_file($uploaded_file['file_name']);
            }

            $this->session->set_flashdata('error', 'Data pasien gagal disimpan. Silakan coba lagi.');
            redirect('dashboard');
        }

        if ($selected_patient && isset($uploaded_file['file_name']) && !empty($selected_patient['file'])) {
            $this->delete_uploaded_file($selected_patient['file']);
        }

        $this->session->set_flashdata(
            'success',
            $id > 0 ? 'Data pasien berhasil diperbarui.' : 'Data pasien berhasil ditambahkan.'
        );

        redirect('dashboard');
    }

    public function delete($id = 0)
    {
        $id = (int) $id;
        $patient = $this->patients->find($id);

        if (!$patient) {
            $this->session->set_flashdata('error', 'Data pasien yang akan dihapus tidak ditemukan.');
            redirect('dashboard');
        }

        $deleted = $this->patients->delete($id);

        if ($deleted && !empty($patient['file'])) {
            $this->delete_uploaded_file($patient['file']);
        }

        $this->session->set_flashdata(
            $deleted ? 'success' : 'error',
            $deleted ? 'Data pasien berhasil dihapus.' : 'Data pasien gagal dihapus.'
        );

        redirect('dashboard');
    }

    private function render_dashboard($selected_patient = NULL, $upload_error = '')
    {
        $data = array(
            'title' => 'Dashboard Pasien',
            'selected_patient' => $selected_patient,
            'patients' => $this->patients->get_all(),
            'stats' => $this->patients->get_statistics(),
            'upload_error' => $upload_error,
        );

        $this->load->view('dashboard/index', $data);
    }

    private function set_patient_rules()
    {
        $this->form_validation->set_rules('nama', 'Nama Pasien', 'trim|required|max_length[100]');
        $this->form_validation->set_rules('tanggal', 'Tanggal Lahir', 'required');
        $this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required|in_list[Laki-laki,Perempuan]');
        $this->form_validation->set_rules('berat', 'Berat Badan', 'trim|required|max_length[10]');
        $this->form_validation->set_rules('tinggi', 'Tinggi Badan', 'trim|required|max_length[10]');
        $this->form_validation->set_rules('lingkar', 'Lingkar Kepala', 'trim|required|max_length[10]');
    }

    private function handle_upload($selected_patient = NULL)
    {
        $has_new_file = isset($_FILES['file_pendukung']) && $_FILES['file_pendukung']['name'] !== '';

        if (!$has_new_file) {
            if ($selected_patient && !empty($selected_patient['file'])) {
                return array();
            }

            return array('error' => 'File pendukung wajib diunggah saat data belum memiliki berkas.');
        }

        $upload_path = FCPATH.'uploads'.DIRECTORY_SEPARATOR;

        if (!is_dir($upload_path)) {
            mkdir($upload_path, 0755, TRUE);
        }

        $config = array(
            'upload_path' => $upload_path,
            'allowed_types' => 'jpg|jpeg|png|pdf|doc|docx',
            'max_size' => 4096,
            'remove_spaces' => TRUE,
            'overwrite' => FALSE,
            'file_name' => $this->generate_upload_name($_FILES['file_pendukung']['name']),
        );

        $this->upload->initialize($config);

        if (!$this->upload->do_upload('file_pendukung')) {
            return array('error' => strip_tags($this->upload->display_errors('', '')));
        }

        $uploaded = $this->upload->data();

        return array('file_name' => $uploaded['file_name']);
    }

    private function generate_upload_name($original_name)
    {
        $extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
        $filename = pathinfo($original_name, PATHINFO_FILENAME);
        $filename = preg_replace('/[^A-Za-z0-9]+/', '-', $filename);
        $filename = trim($filename, '-');

        if ($filename === '') {
            $filename = 'berkas';
        }

        return strtolower($filename.'-'.date('YmdHis').'.'.$extension);
    }

    private function delete_uploaded_file($file_name)
    {
        $path = FCPATH.'uploads'.DIRECTORY_SEPARATOR.basename($file_name);

        if (is_file($path)) {
            unlink($path);
        }
    }
}
