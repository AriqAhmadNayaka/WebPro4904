<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model', 'users');
        $this->form_validation->set_error_delimiters('<li>', '</li>');
        $this->form_validation->set_message('required', '%s wajib diisi.');
    }

    public function index()
    {
        $this->redirect_if_authenticated();

        $data = array(
            'title' => 'Login Dashboard Pasien',
            'auth_error' => '',
        );

        if ($this->input->method() === 'post') {
            $this->form_validation->set_rules('username', 'Username', 'trim|required');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');

            if ($this->form_validation->run()) {
                $username = $this->input->post('username', TRUE);
                $password = $this->input->post('password');
                $user = $this->users->find_by_username($username);

                if ($user && password_verify($password, $user['password'])) {
                    $this->session->sess_regenerate(TRUE);
                    $this->session->set_userdata(array(
                        'is_logged_in' => TRUE,
                        'user_id' => $user['id'],
                        'username' => $user['username'],
                        'nama_lengkap' => $user['nama_lengkap'],
                    ));

                    redirect('dashboard');
                }

                $data['auth_error'] = 'Username atau password tidak sesuai.';
            }
        }

        $this->load->view('auth/login', $data);
    }

    public function logout()
    {
        $this->session->unset_userdata(array(
            'is_logged_in',
            'user_id',
            'username',
            'nama_lengkap',
        ));
        $this->session->set_flashdata('success', 'Anda berhasil logout.');
        redirect('login');
    }
}
