<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'auth';
$route['login'] = 'auth';
$route['logout'] = 'auth/logout';
$route['dashboard'] = 'dashboard';
$route['dashboard/save'] = 'dashboard/save';
$route['dashboard/delete/(:num)'] = 'dashboard/delete/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
