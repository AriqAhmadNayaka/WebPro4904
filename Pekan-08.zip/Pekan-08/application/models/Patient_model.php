<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patient_model extends CI_Model
{
    private $table = 'pasien';

    public function get_all()
    {
        return $this->db
            ->order_by('id', 'DESC')
            ->get($this->table)
            ->result_array();
    }

    public function find($id)
    {
        return $this->db
            ->get_where($this->table, array('id' => $id))
            ->row_array();
    }

    public function create($data)
    {
        return $this->db->insert($this->table, $data);
    }

    public function update($id, $data)
    {
        return $this->db
            ->where('id', $id)
            ->update($this->table, $data);
    }

    public function delete($id)
    {
        return $this->db
            ->where('id', $id)
            ->delete($this->table);
    }

    public function get_statistics()
    {
        return array(
            'total' => (int) $this->db->count_all($this->table),
            'laki_laki' => (int) $this->db->where('jk', 'Laki-laki')->count_all_results($this->table),
            'perempuan' => (int) $this->db->where('jk', 'Perempuan')->count_all_results($this->table),
        );
    }
}
