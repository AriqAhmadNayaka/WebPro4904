<?php
include "koneksi.php";
include "Pasien.php";

$db = new Koneksi();
$pasien = new Pasien($db->conn);

$id = $_GET['id'];
$pasien->hapus($id);

header("Location: inputdata.php");
?>
