CREATE DATABASE IF NOT EXISTS smarttrash_ci3;
USE smarttrash_ci3;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS data_sampah (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_lokasi VARCHAR(150) NOT NULL,
    berat DECIMAL(10,2) NOT NULL,
    kategori ENUM('Aman', 'Waspada', 'Overload') NOT NULL,
    deskripsi TEXT NOT NULL,
    gambar VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO users (name, email, password)
SELECT 'Administrator', 'admin@smarttrash.test', '$2y$10$o7/SBNmdJGTmQPmR7lAHYeODCmQrDZQ1obP6EMcjppuBRarZ2wqq.'
WHERE NOT EXISTS (
    SELECT 1 FROM users WHERE email = 'admin@smarttrash.test'
);
