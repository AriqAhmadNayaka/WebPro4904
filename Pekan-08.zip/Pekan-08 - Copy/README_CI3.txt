Project ini sudah saya ubah ke struktur aplikasi CodeIgniter 3:
- `application/controllers/Auth.php` untuk login dan logout
- `application/controllers/Dashboard.php` untuk dashboard protected, CRUD, dan upload file
- `application/models/` untuk akses database
- `application/views/` untuk halaman login dan dashboard
- `sql_smarttrash_ci3.sql` untuk database dan akun default

Yang masih perlu ditambahkan agar aplikasi bisa dijalankan:
1. Salin folder inti CodeIgniter 3 bernama `system` ke dalam folder `Pekan-08`
2. Import file `sql_smarttrash_ci3.sql` ke MySQL
3. Sesuaikan `application/config/database.php` jika username/password MySQL berbeda

Login default:
- Email: admin@smarttrash.test
- Password: admin123
