<?php
defined('BASEPATH') or exit('No direct script access allowed');

$route['default_controller'] = 'Auth';
$route['dashboard'] = 'dashboard';
$route['dashboard/simpan'] = 'dashboard/simpan';
$route['dashboard/hapus/(:num)'] = 'dashboard/hapus/$1';
$route['login'] = 'auth';
$route['logout'] = 'auth/logout';
$route['404_override'] = '';
$route['translate_uri_dashes'] = false;
