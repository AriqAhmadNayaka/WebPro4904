<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
    }

    public function index()
    {
        // if (is_logged_in()) {
        //     redirect('dashboard');
        // }

        // $data['title'] = 'Login SmartTrash';

        // if ($this->input->method() === 'post') {
        //     $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
        //     $this->form_validation->set_rules('password', 'Password', 'required');

        //     if ($this->form_validation->run()) {
        //         $user = $this->User_model->find_by_email($this->input->post('email', true));
        //         $password = $this->input->post('password');

        //         if ($user && password_verify($password, $user->password)) {
        //             $this->session->set_userdata(array(
        //                 'user_id'   => $user->id,
        //                 'name'      => $user->name,
        //                 'email'     => $user->email,
        //                 'logged_in' => true,
        //             ));

        //             redirect('dashboard');
        //         }

        //         $this->session->set_flashdata('error', 'Email atau password salah.');
        //         redirect('login');
        //     }
        // }

        // $this->load->view('auth/login', $data);
        $this->load->view('test_view');
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('login');
    }
}