<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        require_login();
        $this->load->model('Sampah_model');
    }

    public function index()
    {
        $edit_id = (int) $this->input->get('edit');

        $data = array(
            'title'      => 'Dashboard SmartTrash',
            'user_name'  => $this->session->userdata('name'),
            'items'      => $this->Sampah_model->get_all(),
            'edit_item'  => $edit_id ? $this->Sampah_model->find($edit_id) : null,
        );

        $this->load->view('templates/header', $data);
        $this->load->view('dashboard/index', $data);
        $this->load->view('templates/footer');
    }

    public function simpan()
    {
        $id = (int) $this->input->post('id');

        $this->form_validation->set_rules('nama_lokasi', 'Nama lokasi', 'required|trim');
        $this->form_validation->set_rules('berat', 'Berat sampah', 'required|numeric');
        $this->form_validation->set_rules('kategori', 'Kategori', 'required|trim');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required|trim');

        if (!$this->form_validation->run()) {
            $this->session->set_flashdata('error', validation_errors('<div>', '</div>'));
            redirect($id ? 'dashboard?edit=' . $id : 'dashboard');
        }

        $payload = array(
            'nama_lokasi' => $this->input->post('nama_lokasi', true),
            'berat'       => $this->input->post('berat', true),
            'kategori'    => $this->input->post('kategori', true),
            'deskripsi'   => $this->input->post('deskripsi', true),
        );

        $existing = $id ? $this->Sampah_model->find($id) : null;
        if ($id && !$existing) {
            $this->session->set_flashdata('error', 'Data yang ingin diperbarui tidak ditemukan.');
            redirect('dashboard');
        }

        $upload = $this->handle_upload();

        if (!$upload['status']) {
            $this->session->set_flashdata('error', $upload['message']);
            redirect($id ? 'dashboard?edit=' . $id : 'dashboard');
        }

        $new_file = null;
        if (!empty($upload['file_name'])) {
            $payload['gambar'] = $upload['file_name'];
            $new_file = $upload['file_name'];
        } elseif ($existing) {
            $payload['gambar'] = $existing->gambar;
        }

        if ($id && $existing) {
            $updated = $this->Sampah_model->update($id, $payload);

            if (!$updated) {
                if ($new_file) {
                    $this->remove_file($new_file);
                }

                $this->session->set_flashdata('error', 'Data gagal diperbarui.');
                redirect('dashboard?edit=' . $id);
            }

            if ($new_file && !empty($existing->gambar)) {
                $this->remove_file($existing->gambar);
            }

            $this->session->set_flashdata('success', 'Data berhasil diperbarui.');
        } else {
            if (empty($payload['gambar'])) {
                $this->session->set_flashdata('error', 'Gambar wajib diunggah saat menambah data baru.');
                redirect('dashboard');
            }

            $created = $this->Sampah_model->insert($payload);
            if (!$created) {
                if ($new_file) {
                    $this->remove_file($new_file);
                }

                $this->session->set_flashdata('error', 'Data gagal ditambahkan.');
                redirect('dashboard');
            }

            $this->session->set_flashdata('success', 'Data berhasil ditambahkan.');
        }

        redirect('dashboard');
    }

    public function hapus($id)
    {
        if ($this->input->method() !== 'post') {
            show_error('Metode request tidak diizinkan.', 405);
        }

        $item = $this->Sampah_model->find((int) $id);

        if (!$item) {
            $this->session->set_flashdata('error', 'Data yang ingin dihapus tidak ditemukan.');
            redirect('dashboard');
        }

        $deleted = $this->Sampah_model->delete((int) $id);
        if (!$deleted) {
            $this->session->set_flashdata('error', 'Data gagal dihapus.');
            redirect('dashboard');
        }

        if (!empty($item->gambar)) {
            $this->remove_file($item->gambar);
        }

        $this->session->set_flashdata('success', 'Data berhasil dihapus.');
        redirect('dashboard');
    }

    private function handle_upload()
    {
        if (empty($_FILES['gambar']['name'])) {
            return array(
                'status'    => true,
                'file_name' => null,
                'message'   => null,
            );
        }

        $config = array(
            'upload_path'   => FCPATH . 'uploads' . DIRECTORY_SEPARATOR,
            'allowed_types' => 'jpg|jpeg|png',
            'max_size'      => 2048,
            'encrypt_name'  => true,
        );

        if (!is_dir($config['upload_path']) && !mkdir($config['upload_path'], 0777, true)) {
            return array(
                'status'    => false,
                'file_name' => null,
                'message'   => 'Folder upload tidak dapat dibuat.',
            );
        }

        if (!is_writable($config['upload_path'])) {
            return array(
                'status'    => false,
                'file_name' => null,
                'message'   => 'Folder upload tidak bisa ditulisi.',
            );
        }

        $this->upload->initialize($config);

        if (!$this->upload->do_upload('gambar')) {
            return array(
                'status'    => false,
                'file_name' => null,
                'message'   => strip_tags($this->upload->display_errors()),
            );
        }

        $uploaded = $this->upload->data();

        return array(
            'status'    => true,
            'file_name' => $uploaded['file_name'],
            'message'   => null,
        );
    }

    private function remove_file($file_name)
    {
        $file_path = FCPATH . 'uploads' . DIRECTORY_SEPARATOR . $file_name;
        if (is_file($file_path)) {
            @unlink($file_path);
        }
    }
}
