<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User_model extends CI_Model
{
    private $table = 'users';

    public function find_by_email($email)
    {
        return $this->db
            ->get_where($this->table, array('email' => $email))
            ->row();
    }
}
