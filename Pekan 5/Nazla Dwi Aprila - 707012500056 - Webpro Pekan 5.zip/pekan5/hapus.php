<?php
session_start();// Proteksi halaman agar tidak bisa diakses tanpa login
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }
require 'koneksi.php';

$id = $_GET['id'];// Ambil data menu berdasarkan id

mysqli_query($conn, "DELETE FROM beranda WHERE id = $id");// Hapus data menu berdasarkan id

if (mysqli_affected_rows($conn) > 0) {// Cek apakah data berhasil dihapus
    echo "<script>alert('Data berhasil dihapus!'); document.location.href = 'homepage.php';</script>";
} else {
    echo "<script>alert('Gagal menghapus!'); document.location.href = 'homepage.php';</script>";
}
?>