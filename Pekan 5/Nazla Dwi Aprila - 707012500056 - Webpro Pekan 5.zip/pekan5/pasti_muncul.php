<?php
echo "Satu dua tiga, tes!";
die();
?>