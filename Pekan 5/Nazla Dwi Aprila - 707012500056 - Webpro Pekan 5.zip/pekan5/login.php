<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();// 1. Cek apakah pengguna sudah login, jika belum redirect ke halaman login

//  Cek apakah file koneksi ada
if (!file_exists('koneksi.php')) {
    die("File koneksi.php tidak ditemukan di folder ini!");
}
require 'koneksi.php';

//  Logika Login
if (isset($_POST['login_btn'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Ambil data dari tabel ecotaste
    $result = mysqli_query($conn, "SELECT * FROM ecotaste WHERE username = '$username'");

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        
        // Cek password (admin)
        if ($password === $row['password']) {
            $_SESSION['login'] = true;
            $_SESSION['user'] = $row['username'];
            header("Location: homepage.php");
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login EcoTaste</title>
    <style>
        body { background: #8BC34A; font-family: sans-serif; display: flex; justify-content: center; padding-top: 100px; }
        .card { background: white; padding: 20px; border-radius: 10px; width: 300px; box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        h2 { text-align: center; color: #4CAF50; }
        input { width: 100%; padding: 10px; margin: 10px 0; box-sizing: border-box; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 10px; background: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; }
        .err { color: red; text-align: center; font-size: 14px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>EcoTaste Login</h2>
        <?php if(isset($error)) echo "<p class='err'>$error</p>"; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login_btn">LOGIN</button>
        </form>
    </div>
</body>
</html>