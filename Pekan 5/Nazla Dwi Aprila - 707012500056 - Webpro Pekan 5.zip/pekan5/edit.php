<?php
session_start(); // Cek apakah pengguna sudah login, jika belum redirect ke halaman login
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; } // Cek apakah file koneksi.php ada
require 'koneksi.php';// Ambil data untuk menyambungkan 

$id = $_GET['id'];// Ambil data menu berdasarkan id
$data = mysqli_query($conn, "SELECT * FROM beranda WHERE id = $id");// Ambil data menu sebagai array
$row = mysqli_fetch_assoc($data);

if (isset($_POST['submit'])) {//    Ambil data dari form
    $nama = $_POST['nama'];
    $deskripsi = $_POST['deskripsi'];
    $rating = $_POST['rating'];
    $icon = $_POST['icon'];

    $query = "UPDATE beranda SET // Update data menu berdasarkan id
                nama = '$nama', 
                deskripsi = '$deskripsi', 
                rating = '$rating', 
                icon = '$icon' 
              WHERE id = $id";
    
    mysqli_query($conn, $query);// Cek apakah data berhasil diubah

    if (mysqli_affected_rows($conn) >= 0) {
        echo "<script>alert('Data berhasil diubah!'); document.location.href = 'homepage.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Menu EcoTaste</title>
    <style>
        body { font-family: sans-serif; background: #F4F9F4; padding: 50px; }
        .form-box { background: white; padding: 30px; border-radius: 10px; width: 400px; margin: auto; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        input, textarea, select { width: 100%; padding: 10px; margin: 10px 0; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #FFC107; color: black; border: none; cursor: pointer; font-weight: bold; }
    </style>
</head>
<body>
    <div class="form-box">
        <h2>Edit Menu Kuliner</h2>
        <form action="" method="POST">
            <input type="text" name="nama" value="<?= $row['nama']; ?>" required>
            <textarea name="deskripsi" required><?= $row['deskripsi']; ?></textarea>
            <input type="number" step="0.1" name="rating" value="<?= $row['rating']; ?>" required>
            <select name="icon">
                <option value="fas fa-utensils" <?= $row['icon'] == 'fas fa-utensils' ? 'selected' : ''; ?>>Default</option>
                <option value="fas fa-leaf" <?= $row['icon'] == 'fas fa-leaf' ? 'selected' : ''; ?>>Eco Leaf</option>
                <option value="fas fa-bowl-rice" <?= $row['icon'] == 'fas fa-bowl-rice' ? 'selected' : ''; ?>>Nasi</option>
                <option value="fas fa-coffee" <?= $row['icon'] == 'fas fa-coffee' ? 'selected' : ''; ?>>Kopi</option>
            </select>
            <button type="submit" name="submit">UPDATE DATA</button>
        </form>
    </div>
</body>
</html>