<?php
session_start();// Proteksi halaman agar tidak bisa diakses tanpa login
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }// Cek apakah file koneksi ada
require 'koneksi.php';

if (isset($_POST['submit'])) {// Ambil data dari form
    $nama = $_POST['nama'];
    $deskripsi = $_POST['deskripsi'];
    $rating = $_POST['rating'];
    $icon = $_POST['icon'];

    $query = "INSERT INTO beranda VALUES ('', '$nama', '$deskripsi', '$rating', '$icon')";// Simpan data menu ke database
    mysqli_query($conn, $query);

    if (mysqli_affected_rows($conn) > 0) {// Cek apakah data berhasil ditambahkan
        echo "<script>alert('Data berhasil ditambahkan!'); document.location.href = 'homepage.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Menu EcoTaste</title>
    <style>
        body { font-family: sans-serif; background: #F4F9F4; padding: 50px; }
        .form-box { background: white; padding: 30px; border-radius: 10px; width: 400px; margin: auto; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        input, textarea, select { width: 100%; padding: 10px; margin: 10px 0; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #4CAF50; color: white; border: none; cursor: pointer; font-weight: bold; }
    </style>
</head>
<body>
    <div class="form-box">
        <h2>Tambah Menu Kuliner</h2>
        <form action="" method="POST">
            <input type="text" name="nama" placeholder="Nama Kuliner" required>
            <textarea name="deskripsi" placeholder="Deskripsi Singkat" required></textarea>
            <input type="number" step="0.1" name="rating" placeholder="Rating (contoh: 4.5)" required>
            <select name="icon">
                <option value="fas fa-utensils">Default (Alat Makan)</option>
                <option value="fas fa-leaf">Eco Leaf (Sayuran)</option>
                <option value="fas fa-bowl-rice">Nasi/Mangkuk</option>
                <option value="fas fa-coffee">Kopi/Minuman</option>
            </select>
            <button type="submit" name="submit">SIMPAN DATA</button>
            <br><br>
            <a href="homepage.php" style="text-decoration:none; color:gray; font-size:12px;">Kembali ke Beranda</a>
        </form>
    </div>
</body>
</html>