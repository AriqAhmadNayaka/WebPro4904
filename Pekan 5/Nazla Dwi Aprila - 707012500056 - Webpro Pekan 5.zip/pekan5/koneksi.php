<?php
$conn = mysqli_connect("localhost", "root", "", "wepro5");// Koneksi ke database

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());// Cek koneksi
}