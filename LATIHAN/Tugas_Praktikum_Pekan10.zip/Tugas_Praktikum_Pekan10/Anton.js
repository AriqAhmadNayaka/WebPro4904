const formatRupiah = (angka) => "Rp " + angka.toLocaleString('id-ID');

const daftarProduk = [
    { id: 1, nama: "Laptop", harga: 7000000, stok: 5 },
    { id: 2, nama: "Mouse", harga: 150000, stok: 0 },
    { id: 3, nama: "Keyboard", harga: 300000, stok: 12 },
    { id: 4, nama: "Monitor", harga: 1200000, stok: 3 }
];

// 1. Menampilkan semua produk
const htmlSemuaProduk = daftarProduk.map(produk =>
    `<tr>
        <td>${produk.id}</td>
        <td>${produk.nama}</td>
        <td>${formatRupiah(produk.harga)}</td>
        <td>${produk.stok}</td>
    </tr>`
).join("");
document.getElementById("tabel-semua-produk").innerHTML = htmlSemuaProduk;

// 2. Filter produk yang stoknya > 0
const produkTersedia = daftarProduk.filter(produk => produk.stok > 0);

const htmlProdukTersedia = produkTersedia.map(produk =>
    `<tr>
        <td>${produk.id}</td>
        <td>${produk.nama}</td>
        <td>${formatRupiah(produk.harga)}</td>
        <td>${produk.stok}</td>
    </tr>`
).join("");
document.getElementById("tabel-produk-tersedia").innerHTML = htmlProdukTersedia;

// 3. Daftar nama produk tersedia (List)
const namaProduk = produkTersedia.map(produk => produk.nama);
const htmlNamaProduk = namaProduk.map(nama => `<li>${nama}</li>`).join("");
document.getElementById("list-nama-produk").innerHTML = htmlNamaProduk;

// 4. Menghitung Total Aset menggunakan reduce
// reduce digunakan untuk mengeksekusi fungsi "penyederhana" pada setiap elemen array, 
// sehingga menghasilkan satu nilai tunggal di akhir
const totalAset = daftarProduk.reduce((akumulator, produk) => {
    return akumulator + (produk.harga * produk.stok);
}, 0);

document.getElementById("total-aset").innerText = formatRupiah(totalAset);

// 5. Demo Immutability (Update harga laptop tanpa merusak data asli)
const [laptop, mouse, keyboard, monitor] = daftarProduk;

const laptopBaru = {
    ...laptop,
    harga: 7500000
};

const htmlImmutability = `
    <p><b>Produk Lama:</b> ${laptop.nama} - ${formatRupiah(laptop.harga)}</p>
    <p><b>Produk Baru:</b> ${laptopBaru.nama} - ${formatRupiah(laptopBaru.harga)}</p>
`;
document.getElementById("demo-immutability").innerHTML = htmlImmutability;