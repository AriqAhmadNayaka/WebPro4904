# UI Overhaul — Tampilan Berbeda per Modul + Efek Glass

## Status
- [x] **Auth (login, register)** — Tema pastel hangat + glassmorphism pada auth-card
- [x] **Produk / Dashboard** — Tema pastel hangat + glassmorphism pada navbar, hero-panel, glass-card, stat-card, info-panel, table-shell
- [x] **Posts** — Tema gelap neon + glassmorphism pada navbar, glow-hero, surface-card, stat-pill, info-panel, table rows
- [x] **Welcome** — Tema minimal bersih + glassmorphism pada hub-card dan feature-tile
- [x] Teks dashboard dibersihkan dari label "lama/klasik"

## Identitas Visual
| Halaman | Tema | Warna Dominan | Font | Efek Glass |
|---------|------|---------------|------|------------|
| Login, Register, Produk, Dashboard | Pastel Hangat | Krem, biru, hijau mint | Baloo 2 + Nunito | Navbar, card, hero, stat, info panel |
| Posts (index, create, edit, show) | Gelap Neon | Navy gelap, ungu, cyan, rose | Space Grotesk + Inter | Navbar, hero, card, stat, table, info panel |
| Welcome / Landing | Minimal Bersih | Putih, abu, teal, coral | Outfit + Plus Jakarta Sans | Hub card, feature tiles |

