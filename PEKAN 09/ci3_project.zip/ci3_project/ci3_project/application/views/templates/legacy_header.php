<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($title) ? $title : 'Aplikasi CRUD CI3'; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@600;700;800&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --bg-paper: #f8efe2;
            --bg-soft: #fff7ec;
            --ink-main: #2f3b52;
            --ink-soft: #69758a;
            --line-blue: #6fa6f4;
            --line-deep: #4e7dcb;
            --panel-blue: #d9ebff;
            --panel-blue-strong: #c9e1ff;
            --panel-white: #fffdf8;
            --accent-green: #9cd0b0;
            --accent-green-deep: #6fb48d;
            --accent-orange: #ff9f8f;
            --accent-orange-deep: #eb7e6c;
            --accent-purple: #d9b8f5;
            --accent-purple-deep: #b585ea;
            --accent-yellow: #ffd48d;
            --shadow-soft: 0 14px 0 rgba(111, 166, 244, 0.10);
        }
        body {
            font-family: 'Nunito', sans-serif;
            color: var(--ink-main);
            background:
                radial-gradient(circle at top left, rgba(255, 212, 141, 0.32), transparent 24%),
                radial-gradient(circle at bottom right, rgba(217, 184, 245, 0.25), transparent 22%),
                linear-gradient(180deg, var(--bg-paper) 0%, #fbf3e8 100%);
            min-height: 100vh;
        }
        .app-navbar {
            background: rgba(248, 239, 226, 0.75);
            backdrop-filter: blur(18px) saturate(1.3);
            -webkit-backdrop-filter: blur(18px) saturate(1.3);
            border-bottom: 4px solid var(--line-blue);
            box-shadow: 0 8px 0 rgba(111, 166, 244, 0.08);
        }
        .app-brand {
            font-family: 'Baloo 2', cursive;
            font-weight: 800;
            color: var(--ink-main) !important;
            font-size: 1.6rem;
        }
        .app-navbar .nav-link {
            color: var(--ink-main) !important;
            font-weight: 800;
            border: 3px solid transparent;
            border-radius: 16px;
            padding: 0.45rem 0.9rem !important;
        }
        .app-navbar .nav-link:hover {
            background: #fffaf1;
            border-color: var(--accent-yellow);
        }
        .page-shell { padding-top: 2rem; padding-bottom: 2.5rem; }
        .glass-card, .table-shell {
            background: rgba(255, 253, 248, 0.82);
            backdrop-filter: blur(18px) saturate(1.2);
            -webkit-backdrop-filter: blur(18px) saturate(1.2);
            border: 4px solid var(--line-blue);
            border-radius: 26px;
            box-shadow: var(--shadow-soft), inset 0 1px 0 rgba(255,255,255,0.50);
        }
        .hero-panel {
            position: relative;
            overflow: hidden;
            padding: 2rem;
            border-radius: 28px;
            background: linear-gradient(180deg, rgba(217, 235, 255, 0.85) 0%, rgba(201, 225, 255, 0.80) 100%);
            backdrop-filter: blur(14px) saturate(1.2);
            -webkit-backdrop-filter: blur(14px) saturate(1.2);
            border: 4px solid var(--line-deep);
            box-shadow: var(--shadow-soft), inset 0 1px 0 rgba(255,255,255,0.45);
            color: var(--ink-main);
        }
        .hero-panel::before {
            content: "";
            position: absolute;
            inset: 0;
            background: linear-gradient(transparent 0, transparent 28px, rgba(78, 125, 203, 0.10) 28px, rgba(78, 125, 203, 0.10) 30px, transparent 30px);
            background-size: 100% 48px;
            pointer-events: none;
            opacity: 0.7;
        }
        .hero-panel > * { position: relative; z-index: 1; }
        .hero-title {
            font-family: 'Baloo 2', cursive;
            font-size: clamp(2rem, 3vw, 3rem);
            font-weight: 800;
            line-height: 1;
            margin-bottom: 0.35rem;
        }
        .hero-text { max-width: 760px; color: var(--ink-soft); }
        .hero-actions { display: flex; gap: 0.75rem; flex-wrap: wrap; align-items: center; }
        .stat-card {
            height: 100%;
            padding: 1.2rem;
            border-radius: 22px;
            background: rgba(255, 253, 248, 0.78);
            backdrop-filter: blur(14px) saturate(1.15);
            -webkit-backdrop-filter: blur(14px) saturate(1.15);
            border: 4px solid var(--line-blue);
            box-shadow: var(--shadow-soft), inset 0 1px 0 rgba(255,255,255,0.50);
        }
        .stat-label {
            color: var(--ink-soft);
            font-size: 0.86rem;
            text-transform: uppercase;
            font-weight: 800;
            letter-spacing: 0.06em;
            margin-bottom: 0.35rem;
        }
        .stat-value {
            font-family: 'Baloo 2', cursive;
            font-size: 2rem;
            line-height: 1;
            margin-bottom: 0.35rem;
        }
        .stat-accent {
            width: 44px;
            height: 44px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 14px;
            margin-bottom: 0.75rem;
            font-weight: 800;
            color: var(--ink-main);
            background: var(--accent-yellow);
            border: 3px solid #f0b454;
        }
        .section-title {
            font-family: 'Baloo 2', cursive;
            font-weight: 800;
            font-size: 1.65rem;
        }
        .btn {
            font-weight: 800;
            border-radius: 14px;
            border-width: 3px;
            padding: 0.6rem 1rem;
            box-shadow: 0 6px 0 rgba(47, 59, 82, 0.06);
        }
        .btn-primary { background: var(--accent-green); border-color: var(--accent-green-deep); color: #fff; }
        .btn-warning { background: var(--accent-purple); border-color: var(--accent-purple-deep); color: #fff; }
        .btn-danger { background: var(--accent-orange); border-color: var(--accent-orange-deep); color: #fff; }
        .btn-secondary { background: #eef4ff; border-color: var(--line-blue); color: var(--ink-main); }
        .btn-light { background: var(--accent-green); border-color: var(--accent-green-deep); color: #fff; }
        .form-control {
            border-radius: 14px;
            border: 3px solid var(--line-blue);
            padding: 0.8rem 0.95rem;
            background: #fffdf8;
            color: var(--ink-main);
        }
        .form-control:focus {
            border-color: var(--accent-purple-deep);
            box-shadow: 0 0 0 0.22rem rgba(181, 133, 234, 0.18);
            background: #fff;
        }
        .table {
            margin-bottom: 0;
            border-collapse: separate;
            border-spacing: 0 10px;
        }
        .table thead th {
            border: none;
            color: var(--ink-main);
            font-size: 0.84rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            font-weight: 800;
        }
        .table > :not(caption) > * > * {
            padding: 0.95rem 0.85rem;
            border-color: transparent;
            vertical-align: middle;
        }
        .table tbody tr td {
            background: #fffdf8;
            border-top: 3px solid var(--line-blue);
            border-bottom: 3px solid var(--line-blue);
        }
        .table tbody tr td:first-child {
            border-left: 3px solid var(--line-blue);
            border-top-left-radius: 16px;
            border-bottom-left-radius: 16px;
        }
        .table tbody tr td:last-child {
            border-right: 3px solid var(--line-blue);
            border-top-right-radius: 16px;
            border-bottom-right-radius: 16px;
        }
        .soft-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.42rem 0.78rem;
            border-radius: 999px;
            background: #fff8ea;
            border: 3px solid var(--accent-yellow);
            color: var(--ink-main);
            font-size: 0.78rem;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            font-weight: 800;
        }
        .table-shell-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }
        .table-shell-meta, .muted-note { color: var(--ink-soft); }
        .file-pill {
            display: inline-flex;
            align-items: center;
            padding: 0.45rem 0.75rem;
            border-radius: 12px;
            background: #eef4ff;
            border: 3px solid var(--line-blue);
            color: var(--line-deep);
            text-decoration: none;
            font-weight: 800;
        }
        .info-panel {
            background: rgba(238, 246, 255, 0.75);
            backdrop-filter: blur(14px) saturate(1.15);
            -webkit-backdrop-filter: blur(14px) saturate(1.15);
            border: 4px solid var(--line-blue);
            border-radius: 22px;
            padding: 1rem;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.45);
        }
        .field-block + .field-block { margin-top: 1rem; }
        .empty-state { padding: 2rem 1rem; text-align: center; color: var(--ink-soft); }
        @media (max-width: 991px) {
            .page-shell { padding-top: 1.1rem; }
            .hero-panel { padding: 1.4rem; }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg app-navbar">
        <div class="container">
            <a class="navbar-brand app-brand" href="<?php echo site_url('dashboard-lama'); ?>">CRUD Board</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="<?php echo site_url('produk'); ?>">Produk</a>
                <a class="nav-link" href="<?php echo site_url('dashboard-lama'); ?>">Post</a>
                <a class="nav-link" href="<?php echo site_url('auth/logout'); ?>">Logout</a>
            </div>
        </div>
    </nav>
    <div class="container page-shell">
        <?php echo $this->session->flashdata('message'); ?>
        <?php echo $this->session->flashdata('error'); ?>
