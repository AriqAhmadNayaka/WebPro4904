<?php
$category_options = array(
    'Elektronik',
    'Alat Tulis',
    'Rumah Tangga',
    'Fashion',
    'Makanan & Minuman',
    'Kesehatan',
);
?>

<div class="hero-panel mb-4">
    <span class="soft-badge mb-3"><?php echo $product ? 'Edit Inventory Item' : 'Add Inventory Item'; ?></span>
    <h1 class="hero-title mb-2"><?php echo $product ? 'Perbarui data produk di papan inventori' : 'Tambahkan item baru ke katalog inventori'; ?></h1>
    <p class="hero-text">Form ini mengikuti tema baru yang lebih hangat dan seperti lembar pencatatan gudang, tapi alur CRUD-nya tetap sederhana dan mudah dipresentasikan.</p>
</div>

<?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>

<div class="glass-card p-4 p-lg-5">
    <?php echo form_open('produk/save'); ?>
        <?php if ($product): ?>
            <?php echo form_hidden('id', $product['id']); ?>
        <?php endif; ?>

        <div class="row g-4">
            <div class="col-lg-7">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Kode Produk</label>
                        <?php echo form_input(array(
                            'name' => 'product_code',
                            'class' => 'form-control',
                            'placeholder' => 'Contoh: PRD-001',
                            'value' => set_value('product_code', $product ? $product['product_code'] : '')
                        )); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Nama Produk</label>
                        <?php echo form_input(array(
                            'name' => 'product_name',
                            'class' => 'form-control',
                            'placeholder' => 'Masukkan nama produk',
                            'value' => set_value('product_name', $product ? $product['product_name'] : '')
                        )); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Kategori</label>
                        <select name="category" class="form-control">
                            <option value="">Pilih kategori</option>
                            <?php foreach ($category_options as $category): ?>
                                <option value="<?php echo html_escape($category); ?>" <?php echo set_select('category', $category, ($product && $product['category'] === $category)); ?>>
                                    <?php echo html_escape($category); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Supplier</label>
                        <?php echo form_input(array(
                            'name' => 'supplier',
                            'class' => 'form-control',
                            'placeholder' => 'Opsional',
                            'value' => set_value('supplier', $product ? $product['supplier'] : '')
                        )); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Harga</label>
                        <?php echo form_input(array(
                            'name' => 'price',
                            'class' => 'form-control',
                            'type' => 'number',
                            'step' => '0.01',
                            'min' => '0',
                            'placeholder' => 'Contoh: 25000',
                            'value' => set_value('price', $product ? $product['price'] : '')
                        )); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Stok</label>
                        <?php echo form_input(array(
                            'name' => 'stock',
                            'class' => 'form-control',
                            'type' => 'number',
                            'min' => '0',
                            'placeholder' => 'Jumlah stok',
                            'value' => set_value('stock', $product ? $product['stock'] : '')
                        )); ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="info-panel h-100">
                    <div class="field-block">
                        <label class="form-label">Status Produk</label>
                        <select name="status" class="form-control">
                            <option value="">Pilih status</option>
                            <?php foreach ($status_options as $status): ?>
                                <option value="<?php echo html_escape($status); ?>" <?php echo set_select('status', $status, ($product && $product['status'] === $status)); ?>>
                                    <?php echo html_escape($status); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field-block pt-3 border-top">
                        <div class="stat-label">Tips Pengisian</div>
                        <div class="muted-note">Gunakan kode unik untuk setiap produk. Jika stok di bawah 5, pilih status <strong>Stok Menipis</strong> supaya item tersebut mudah dikenali di halaman utama.</div>
                    </div>

                    <div class="field-block">
                        <div class="stat-label">Nuansa Tampilan</div>
                        <div class="muted-note">Tema baru ini memakai palet krem, cokelat, dan merah bata agar tampil beda dari dashboard biru sebelumnya dan terasa lebih unik saat demo.</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?php echo site_url('produk'); ?>" class="btn btn-secondary">Batal</a>
        </div>
    <?php echo form_close(); ?>
</div>
