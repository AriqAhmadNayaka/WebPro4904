<?php
$formatter = function ($amount) {
    return 'Rp ' . number_format((float) $amount, 0, ',', '.');
};

$status_class = function ($status) {
    $status = strtolower($status);

    if ($status === 'tersedia') {
        return 'bg-success';
    }

    if ($status === 'stok menipis') {
        return 'bg-warning text-dark';
    }

    if ($status === 'preorder') {
        return 'bg-info text-dark';
    }

    return 'bg-secondary';
};
?>

<div class="hero-panel mb-4">
    <div class="d-lg-flex justify-content-between align-items-end">
        <div class="mb-3 mb-lg-0">
            <span class="soft-badge mb-3">Warehouse Board</span>
            <h1 class="hero-title">Inventori produk dengan nuansa katalog gudang yang lebih hangat dan tegas.</h1>
            <p class="hero-text">Tampilan ini sengaja dibuat beda dari tema sebelumnya: lebih editorial, lebih earthy, dan terasa seperti dashboard operasional toko atau gudang.</p>
        </div>
        <div class="hero-actions">
            <span class="soft-badge"><?php echo (int) $summary['total_products']; ?> item aktif</span>
            <a href="<?php echo site_url('produk/form'); ?>" class="btn btn-light text-primary fw-bold px-4">Tambah Produk</a>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-accent">01</div>
            <div class="stat-label">Total Produk</div>
            <div class="stat-value"><?php echo (int) $summary['total_products']; ?></div>
            <div class="muted-note">Jumlah item yang sedang dikelola.</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-accent">02</div>
            <div class="stat-label">Kategori Aktif</div>
            <div class="stat-value"><?php echo (int) $summary['active_categories']; ?></div>
            <div class="muted-note">Kategori yang sudah dipakai dalam inventori.</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-accent">03</div>
            <div class="stat-label">Stok Menipis</div>
            <div class="stat-value"><?php echo (int) $summary['low_stock']; ?></div>
            <div class="muted-note">Produk dengan stok 5 atau kurang.</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-accent">04</div>
            <div class="stat-label">Estimasi Nilai</div>
            <div class="stat-value" style="font-size:1.4rem;"><?php echo $formatter($summary['inventory_value']); ?></div>
            <div class="muted-note">Akumulasi harga dikali stok seluruh produk.</div>
        </div>
    </div>
</div>

<div class="table-shell p-3 p-lg-4">
    <div class="table-shell-header">
        <div>
            <h3 class="section-title mb-1">Papan Inventori</h3>
            <p class="muted-note mb-0">Gunakan tabel ini untuk memantau barang aktif, restock, dan status penjualan setiap produk.</p>
        </div>
        <div class="table-shell-meta">Produk terbaru ditampilkan lebih dulu</div>
    </div>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Produk</th>
                    <th>Kategori</th>
                    <th>Supplier</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="8" class="empty-state">Belum ada produk di inventori. Tambahkan data pertama dari tombol di atas.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><strong><?php echo html_escape($product['product_code']); ?></strong></td>
                            <td>
                                <div class="fw-bold"><?php echo html_escape($product['product_name']); ?></div>
                                <small class="muted-note">Input: <?php echo date('d/m/Y H:i', strtotime($product['created_at'])); ?></small>
                            </td>
                            <td><?php echo html_escape($product['category']); ?></td>
                            <td><?php echo !empty($product['supplier']) ? html_escape($product['supplier']) : '<span class="muted-note">Tidak ada</span>'; ?></td>
                            <td><?php echo $formatter($product['price']); ?></td>
                            <td>
                                <span class="fw-bold"><?php echo (int) $product['stock']; ?></span>
                                <small class="d-block muted-note"><?php echo (int) $product['stock'] <= 5 ? 'Perlu restock' : 'Stok aman'; ?></small>
                            </td>
                            <td><span class="badge <?php echo $status_class($product['status']); ?>"><?php echo html_escape($product['status']); ?></span></td>
                            <td>
                                <a href="<?php echo site_url('produk/form/' . $product['id']); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="<?php echo site_url('produk/delete/' . $product['id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus produk ini dari inventori?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
