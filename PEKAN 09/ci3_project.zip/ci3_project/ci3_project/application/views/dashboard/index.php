<div class="hero-panel mb-4">
    <div class="d-lg-flex justify-content-between align-items-end">
        <div class="mb-3 mb-lg-0">
            <span class="soft-badge mb-3">Dashboard Post</span>
            <h1 class="hero-title">Kelola post dan lampiran dalam satu dashboard.</h1>
            <p class="hero-text">Modul ini menyediakan CRUD lengkap untuk post dengan upload file, statistik ringkas, dan tabel data yang mudah dibaca.</p>
        </div>
        <div class="hero-actions">
            <span class="soft-badge"><?php echo count($posts); ?> data tersimpan</span>
            <a href="<?php echo site_url('dashboard/form'); ?>" class="btn btn-light text-primary fw-bold px-4">Tambah Data</a>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="stat-card">
            <div class="stat-accent">01</div>
            <div class="stat-label">Total Post</div>
            <div class="stat-value"><?php echo count($posts); ?></div>
            <div class="muted-note">Jumlah data yang tersimpan pada sistem.</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card">
            <div class="stat-accent">02</div>
            <div class="stat-label">Dengan Lampiran</div>
            <div class="stat-value"><?php echo count(array_filter($posts, function ($post) { return !empty($post['file_path']); })); ?></div>
            <div class="muted-note">Data yang sudah memiliki file pendukung.</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card">
            <div class="stat-accent">03</div>
            <div class="stat-label">Status Dashboard</div>
            <div class="stat-value">Aktif</div>
            <div class="muted-note">Siap dipakai untuk demo CRUD dan upload file.</div>
        </div>
    </div>
</div>

<div class="table-shell p-3 p-lg-4">
    <div class="table-shell-header">
        <div>
            <h3 class="section-title mb-1">Daftar Data Post</h3>
            <p class="muted-note mb-0">Klik edit untuk memperbarui data atau hapus untuk menghapus post dari sistem.</p>
        </div>
        <div class="table-shell-meta">Menampilkan data terbaru lebih dahulu</div>
    </div>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>Konten</th>
                    <th>File</th>
                    <th>Dibuat</th>
                    <th>Diubah</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($posts)): ?>
                    <tr>
                        <td colspan="7" class="empty-state">Belum ada data post. Tambahkan data pertama Anda dari tombol di atas.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($posts as $post): ?>
                    <tr>
                        <td><strong>#<?php echo $post['id']; ?></strong></td>
                        <td>
                            <div class="fw-bold"><?php echo htmlspecialchars($post['title']); ?></div>
                            <small class="muted-note"><?php echo strlen($post['content']); ?> karakter konten</small>
                        </td>
                        <td><?php echo character_limiter(htmlspecialchars($post['content']), 100); ?></td>
                        <td>
                            <?php if (!empty($post['file_path'])): ?>
                                <a class="file-pill" href="<?php echo base_url($post['file_path']); ?>" target="_blank">Lihat File</a>
                            <?php else: ?>
                                <span class="muted-note">Tidak ada</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo date('d/m/Y H:i', strtotime($post['created_at'])); ?></td>
                        <td><?php echo !empty($post['updated_at']) ? date('d/m/Y H:i', strtotime($post['updated_at'])) : '-'; ?></td>
                        <td>
                            <a href="<?php echo site_url('dashboard/form/' . $post['id']); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="<?php echo site_url('dashboard/delete/' . $post['id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus data ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
