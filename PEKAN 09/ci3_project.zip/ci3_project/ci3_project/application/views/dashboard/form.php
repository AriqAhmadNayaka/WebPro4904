<div class="hero-panel mb-4">
    <span class="soft-badge mb-3"><?php echo $post ? 'Edit Post' : 'Tambah Post'; ?></span>
    <h1 class="hero-title mb-2"><?php echo $post ? 'Perbarui Data Post' : 'Tambah Data Post Baru'; ?></h1>
    <p class="hero-text">Isi judul dan konten dengan lengkap, lalu unggah file pendukung jika diperlukan sebelum menyimpan data.</p>
</div>

<?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>

<div class="glass-card p-4 p-lg-5">
    <?php echo form_open_multipart('dashboard/save'); ?>
        <?php if ($post): ?>
            <?php echo form_hidden('id', $post['id']); ?>
        <?php endif; ?>

        <div class="row g-4">
            <div class="col-lg-7">
                <div class="field-block">
                    <label class="form-label">Judul Post</label>
                    <?php echo form_input(array('name' => 'title', 'class' => 'form-control', 'placeholder' => 'Masukkan judul post', 'value' => set_value('title', $post ? $post['title'] : ''))); ?>
                </div>

                <div class="field-block">
                    <label class="form-label">Konten</label>
                    <?php echo form_textarea(array('name' => 'content', 'class' => 'form-control', 'rows' => 9, 'placeholder' => 'Tulis isi konten post di sini'), set_value('content', $post ? $post['content'] : '')); ?>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="info-panel h-100">
                    <div class="field-block">
                        <label class="form-label">File Lampiran <?php echo $post ? '(kosongkan jika tidak ingin mengganti file)' : '(opsional)'; ?></label>
                        <input type="file" name="file" class="form-control">
                        <?php if ($post && $post['file_path']): ?>
                            <small class="text-muted d-block mt-2">File saat ini: <a href="<?php echo base_url($post['file_path']); ?>" target="_blank"><?php echo basename($post['file_path']); ?></a></small>
                        <?php endif; ?>
                        <small class="text-muted d-block mt-2">Format yang diizinkan: jpg, jpeg, png, pdf, doc, docx. Maksimal 2 MB. Data tetap bisa disimpan tanpa file.</small>
                    </div>

                    <div class="field-block pt-3 border-top">
                        <div class="stat-label">Tips Pengisian</div>
                        <div class="muted-note">Isi judul dengan singkat dan jelas, tambahkan konten deskriptif, lalu unggah file pendukung sebelum menekan tombol <strong>Simpan</strong>.</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?php echo site_url('dashboard'); ?>" class="btn btn-secondary">Batal</a>
        </div>
    <?php echo form_close(); ?>
</div>
