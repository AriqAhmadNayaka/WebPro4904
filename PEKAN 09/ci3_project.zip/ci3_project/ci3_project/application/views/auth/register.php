<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun - CI3 CRUD App</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@600;700;800&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --bg-paper: #f8efe2;
            --ink-main: #2f3b52;
            --ink-soft: #69758a;
            --line-blue: #6fa6f4;
            --line-deep: #4e7dcb;
            --panel-blue: #d9ebff;
            --panel-white: #fffdf8;
            --accent-purple: #d9b8f5;
            --accent-purple-deep: #b585ea;
            --accent-yellow: #ffd48d;
        }
        * { box-sizing: border-box; }
        body {
            min-height: 100vh;
            margin: 0;
            padding: 1rem;
            font-family: 'Nunito', sans-serif;
            color: var(--ink-main);
            background:
                radial-gradient(circle at top left, rgba(255, 212, 141, 0.32), transparent 24%),
                radial-gradient(circle at bottom right, rgba(217, 184, 245, 0.25), transparent 22%),
                linear-gradient(180deg, var(--bg-paper) 0%, #fbf3e8 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .auth-card {
            width: 100%;
            max-width: 520px;
            background: rgba(255, 253, 248, 0.82);
            backdrop-filter: blur(20px) saturate(1.3);
            -webkit-backdrop-filter: blur(20px) saturate(1.3);
            border: 4px solid var(--line-blue);
            border-radius: 28px;
            box-shadow: 0 14px 0 rgba(111, 166, 244, 0.10), 0 8px 32px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        .auth-card::before {
            content: "";
            display: block;
            height: 10px;
            background: linear-gradient(90deg, #9cd0b0, var(--accent-yellow), var(--accent-purple));
        }
        .card-body { padding: 2rem; }
        .auth-title {
            font-family: 'Baloo 2', cursive;
            font-size: 2.2rem;
            line-height: 1;
            margin: 0 0 0.4rem;
        }
        .auth-subtitle {
            color: var(--ink-soft);
            margin-bottom: 1.4rem;
        }
        .form-label { font-weight: 800; margin-bottom: 0.45rem; }
        .form-control {
            border-radius: 14px;
            border: 3px solid var(--line-blue);
            padding: 0.85rem 0.95rem;
            background: #fffdf8;
        }
        .form-control:focus {
            border-color: var(--accent-purple-deep);
            box-shadow: 0 0 0 0.22rem rgba(181, 133, 234, 0.18);
        }
        .btn-auth {
            border: 3px solid var(--accent-purple-deep);
            border-radius: 14px;
            padding: 0.8rem 1rem;
            font-weight: 800;
            color: #fff;
            background: var(--accent-purple);
            box-shadow: 0 6px 0 rgba(47, 59, 82, 0.06);
        }
        .auth-link {
            margin-top: 1rem;
            color: var(--ink-soft);
            text-align: center;
        }
        .auth-link a {
            color: var(--line-deep);
            font-weight: 800;
            text-decoration: none;
        }
        .alert {
            border-radius: 14px;
            border-width: 3px;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <div class="auth-card">
        <div class="card-body">
            <h1 class="auth-title">Daftar Akun</h1>
            <p class="auth-subtitle">Buat akun baru dengan tema CRUD pastel seperti referensi.</p>
            <?php echo $this->session->flashdata('message'); ?>
            <?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>

            <?php echo form_open('auth/store_register'); ?>
                <div class="mb-3">
                    <label class="form-label">Nama</label>
                    <?php echo form_input(array('name' => 'nama', 'class' => 'form-control', 'value' => set_value('nama'), 'placeholder' => 'Masukkan nama')); ?>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <?php echo form_input(array('name' => 'email', 'type' => 'email', 'class' => 'form-control', 'value' => set_value('email'), 'placeholder' => 'Masukkan email')); ?>
                </div>

                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <?php echo form_password(array('name' => 'password', 'class' => 'form-control', 'placeholder' => 'Minimal 6 karakter')); ?>
                </div>

                <div class="mb-4">
                    <label class="form-label">Konfirmasi Password</label>
                    <?php echo form_password(array('name' => 'password_confirm', 'class' => 'form-control', 'placeholder' => 'Ulangi password')); ?>
                </div>

                <button type="submit" class="btn btn-auth w-100">Daftar</button>
            <?php echo form_close(); ?>

            <div class="auth-link">
                Sudah punya akun? <a href="<?php echo site_url('auth'); ?>">Login</a>
            </div>
        </div>
    </div>
</body>
</html>
