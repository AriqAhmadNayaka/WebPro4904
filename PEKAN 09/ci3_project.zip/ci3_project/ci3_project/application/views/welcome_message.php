<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Board - CodeIgniter 3</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --bg-clean: #f6f7f9;
            --bg-card: #ffffff;
            --ink-main: #1a1d2b;
            --ink-soft: #5a5f72;
            --ink-muted: #8b8fa3;
            --accent-teal: #14b8a6;
            --accent-teal-soft: #ccfbf1;
            --accent-indigo: #6366f1;
            --accent-indigo-soft: #e0e7ff;
            --accent-coral: #f472b6;
            --accent-coral-soft: #fce7f3;
            --border-light: #e8e9ef;
        }
        * { box-sizing: border-box; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--ink-main);
            background: var(--bg-clean);
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
            padding: 1.5rem;
        }
        .hub-card {
            width: 100%; max-width: 900px;
            background: rgba(255, 255, 255, 0.72);
            backdrop-filter: blur(24px) saturate(1.3);
            -webkit-backdrop-filter: blur(24px) saturate(1.3);
            border: 1px solid rgba(255, 255, 255, 0.50);
            border-radius: 28px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.04), 0 12px 40px rgba(0,0,0,0.08), inset 0 1px 0 rgba(255,255,255,0.60);
            padding: 3.5rem 2.5rem;
            text-align: center;
        }
        .hub-title {
            font-family: 'Outfit', sans-serif;
            font-size: clamp(2.2rem, 4vw, 3.2rem);
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 0.5rem;
            color: var(--ink-main);
        }
        .hub-subtitle {
            color: var(--ink-soft);
            font-size: 1.05rem;
            max-width: 520px;
            margin: 0 auto 2.6rem;
            line-height: 1.6;
        }
        .feature-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1rem;
            margin-bottom: 2.4rem;
        }
        .feature-tile {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(16px) saturate(1.2);
            -webkit-backdrop-filter: blur(16px) saturate(1.2);
            border: 1px solid rgba(255, 255, 255, 0.45);
            border-radius: 18px;
            padding: 1.4rem 1.2rem;
            text-align: left;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.50);
        }
        .feature-tile:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 24px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,0.60);
            background: rgba(255, 255, 255, 0.70);
        }
        .feature-icon {
            width: 42px; height: 42px;
            border-radius: 12px;
            display: inline-flex; align-items: center; justify-content: center;
            font-size: 1.2rem;
            margin-bottom: 0.7rem;
        }
        .icon-teal { background: var(--accent-teal-soft); }
        .icon-indigo { background: var(--accent-indigo-soft); }
        .icon-coral { background: var(--accent-coral-soft); }
        .feature-tile strong {
            font-family: 'Outfit', sans-serif;
            font-size: 1.05rem;
            font-weight: 700;
            display: block;
            margin-bottom: 0.25rem;
        }
        .feature-tile small {
            color: var(--ink-muted);
            font-size: 0.86rem;
            line-height: 1.45;
        }
        .btn-hub {
            display: inline-block;
            border-radius: 14px;
            padding: 0.9rem 2.2rem;
            font-weight: 700;
            font-size: 1rem;
            text-decoration: none;
            transition: all 0.2s ease;
            border: none;
        }
        .btn-hub-main {
            background: var(--ink-main);
            color: #fff;
            box-shadow: 0 4px 16px rgba(26,29,43,0.18);
        }
        .btn-hub-main:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 22px rgba(26,29,43,0.24);
            color: #fff;
        }
        .btn-hub-ghost {
            background: transparent;
            color: var(--ink-soft);
            border: 1px solid var(--border-light);
            margin-left: 0.5rem;
        }
        .btn-hub-ghost:hover {
            border-color: var(--ink-muted);
            color: var(--ink-main);
        }
        .footer-note {
            margin-top: 1.8rem;
            color: var(--ink-muted);
            font-size: 0.85rem;
        }
        .divider-dot {
            display: inline-block;
            width: 4px; height: 4px;
            background: var(--ink-muted);
            border-radius: 50%;
            margin: 0 0.5rem;
            vertical-align: middle;
        }
    </style>
</head>
<body>
    <div class="hub-card">
        <h1 class="hub-title">CRUD Board</h1>
        <p class="hub-subtitle">Aplikasi manajemen data berbasis CodeIgniter 3 dengan tiga identitas visual berbeda: hangat, gelap, dan minimal.</p>

        <div class="feature-grid">
            <div class="feature-tile">
                <div class="feature-icon icon-teal">📝</div>
                <strong>Posts</strong>
                <small>Tema gelap dengan aksen neon ungu dan cyan. Cocok untuk fokus menulis.</small>
            </div>
            <div class="feature-tile">
                <div class="feature-icon icon-indigo">📦</div>
                <strong>Produk</strong>
                <small>Tema pastel hangat dengan border biru lembut. Nuansa katalog yang ramah.</small>
            </div>
            <div class="feature-tile">
                <div class="feature-icon icon-coral">🔐</div>
                <strong>Autentikasi</strong>
                <small>Form login dan register dengan warna krem, hijau mint, dan ungu lembut.</small>
            </div>
        </div>

        <div>
            <a href="<?php echo site_url('auth'); ?>" class="btn-hub btn-hub-main">Masuk Aplikasi</a>
            <a href="<?php echo base_url('posts'); ?>" class="btn-hub btn-hub-ghost">Lihat Posts</a>
        </div>

        <div class="footer-note">
            CodeIgniter <strong><?php echo CI_VERSION; ?></strong> <span class="divider-dot"></span> Rendered in <strong>{elapsed_time}</strong> seconds
        </div>
    </div>
</body>
</html>

