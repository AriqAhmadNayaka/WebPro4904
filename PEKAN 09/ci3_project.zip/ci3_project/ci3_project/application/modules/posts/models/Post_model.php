<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post_model extends CI_Model {

    private $table = 'posts';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->ensure_table();
    }

    public function ensure_table()
    {
        if (!$this->db->table_exists($this->table)) {
            $this->db->query("CREATE TABLE `posts` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `title` VARCHAR(255) NOT NULL,
                `author` VARCHAR(255) DEFAULT NULL,
                `article` TEXT,
                `content` TEXT,
                `image` VARCHAR(255) DEFAULT NULL,
                `file_path` VARCHAR(255) DEFAULT NULL,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` DATETIME DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
            return;
        }

        $fields = $this->db->list_fields($this->table);
        $columns = array(
            'author' => "ALTER TABLE `posts` ADD `author` VARCHAR(255) DEFAULT NULL",
            'article' => "ALTER TABLE `posts` ADD `article` TEXT",
            'image' => "ALTER TABLE `posts` ADD `image` VARCHAR(255) DEFAULT NULL",
            'updated_at' => "ALTER TABLE `posts` ADD `updated_at` DATETIME DEFAULT NULL"
        );

        foreach ($columns as $field => $sql) {
            if (!in_array($field, $fields, TRUE)) {
                $this->db->query($sql);
            }
        }
    }

    /**
     * Get all posts
     */
    public function get_all()
    {
        $query = $this->db->get($this->table);
        $posts = $query->result();

        // Add image_url to each post
        foreach ($posts as $post) {
            $post = $this->normalize_post($post);
            if ($post->image) {
                $imagePath = str_replace('posts/', '', $post->image);
                $post->image_url = base_url('uploads/posts/' . $imagePath);
            } else {
                $post->image_url = null;
            }
        }

        return $posts;
    }

    /**
     * Get post by ID
     */
    public function get_by_id($id)
    {
        $query = $this->db->get_where($this->table, array('id' => $id));
        $post = $query->row();

        if ($post) {
            $post = $this->normalize_post($post);
        }

        if ($post && $post->image) {
            $imagePath = str_replace('posts/', '', $post->image);
            $post->image_url = base_url('uploads/posts/' . $imagePath);
        }

        return $post;
    }

    private function normalize_post($post)
    {
        if (!isset($post->author) || $post->author === null) {
            $post->author = 'Admin';
        }
        if (!isset($post->article) || $post->article === null) {
            $post->article = isset($post->content) ? $post->content : '';
        }
        if (!isset($post->image) || $post->image === null) {
            $post->image = isset($post->file_path) ? $post->file_path : null;
        }

        return $post;
    }

    /**
     * Insert new post
     */
    public function insert($data)
    {
        $data = $this->prepare_data($data);
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    /**
     * Update post
     */
    public function update($id, $data)
    {
        $data = $this->prepare_data($data);
        $this->db->where('id', $id);
        return $this->db->update($this->table, $data);
    }

    /**
     * Delete post
     */
    public function delete($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
    }

    /**
     * Check if post exists
     */
    public function exists($id)
    {
        $query = $this->db->get_where($this->table, array('id' => $id));
        return $query->num_rows() > 0;
    }

    private function prepare_data($data)
    {
        $fields = $this->db->list_fields($this->table);
        if (isset($data['article']) && in_array('content', $fields, TRUE)) {
            $data['content'] = $data['article'];
        }
        if (isset($data['image']) && in_array('file_path', $fields, TRUE)) {
            $data['file_path'] = $data['image'];
        }

        return $data;
    }
}
