<?php $this->load->view('header'); ?>

<div class="glow-hero mb-4">
    <span class="soft-badge mb-3">New Post</span>
    <h1 class="hero-title mb-2">Tulis Post Baru</h1>
    <p class="hero-text">Buat postingan dengan judul menarik, tambahkan nama penulis, dan lampirkan gambar jika diperlukan.</p>
</div>

<?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>

<div class="surface-card p-4 p-lg-5">
    <?php echo form_open_multipart('posts/store'); ?>

        <div class="row g-4">
            <div class="col-lg-7">
                <div class="field-block">
                    <label class="form-label">Judul</label>
                    <?php echo form_input(array('name' => 'title', 'class' => 'form-control', 'placeholder' => 'Masukkan judul post', 'value' => set_value('title'), 'required' => 'required')); ?>
                </div>

                <div class="field-block">
                    <label class="form-label">Penulis</label>
                    <?php echo form_input(array('name' => 'author', 'class' => 'form-control', 'placeholder' => 'Nama penulis', 'value' => set_value('author'), 'required' => 'required')); ?>
                </div>

                <div class="field-block">
                    <label class="form-label">Konten</label>
                    <?php echo form_textarea(array('name' => 'article', 'class' => 'form-control', 'rows' => 9, 'placeholder' => 'Tulis isi artikel di sini...', 'required' => 'required'), set_value('article')); ?>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="info-panel h-100">
                    <div class="field-block">
                        <label class="form-label">Gambar</label>
                        <input type="file" name="image" class="form-control" accept="image/jpeg,image/jpg,image/png">
                        <small class="muted-note d-block mt-2">JPG, JPEG, PNG. Maksimal 2 MB.</small>
                    </div>

                    <div class="field-block pt-3 border-top" style="border-color:var(--border-subtle)!important;">
                        <div class="stat-label" style="color:var(--ink-muted);font-size:0.78rem;text-transform:uppercase;font-weight:600;letter-spacing:0.08em;">Tips</div>
                        <div class="muted-note">Gunakan judul yang jelas dan deskriptif. Konten yang panjang akan dipotong di tabel daftar, tapi tetap lengkap di halaman detail.</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?php echo base_url('posts'); ?>" class="btn btn-secondary">Batal</a>
        </div>

    <?php echo form_close(); ?>
</div>

<?php $this->load->view('footer'); ?>

