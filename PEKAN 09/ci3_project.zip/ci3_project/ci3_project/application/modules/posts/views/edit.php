<?php $this->load->view('header'); ?>

<div class="glow-hero mb-4">
    <span class="soft-badge mb-3">Edit Post</span>
    <h1 class="hero-title mb-2">Perbarui Post</h1>
    <p class="hero-text">Ubah informasi post yang sudah ada. Gambar lama akan diganti jika Anda mengunggah file baru.</p>
</div>

<?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>

<div class="surface-card p-4 p-lg-5">
    <?php echo form_open_multipart('posts/update/' . $post->id); ?>

        <div class="row g-4">
            <div class="col-lg-7">
                <div class="field-block">
                    <label class="form-label">Judul</label>
                    <?php echo form_input(array('name' => 'title', 'class' => 'form-control', 'placeholder' => 'Masukkan judul post', 'value' => set_value('title', $post->title), 'required' => 'required')); ?>
                </div>

                <div class="field-block">
                    <label class="form-label">Penulis</label>
                    <?php echo form_input(array('name' => 'author', 'class' => 'form-control', 'placeholder' => 'Nama penulis', 'value' => set_value('author', $post->author), 'required' => 'required')); ?>
                </div>

                <div class="field-block">
                    <label class="form-label">Konten</label>
                    <?php echo form_textarea(array('name' => 'article', 'class' => 'form-control', 'rows' => 9, 'placeholder' => 'Tulis isi artikel di sini...', 'required' => 'required'), set_value('article', $post->article)); ?>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="info-panel h-100">
                    <div class="field-block">
                        <label class="form-label">Gambar Saat Ini</label>
                        <?php if($post->image): ?>
                            <div class="mb-2">
                                <img src="<?php echo base_url('uploads/' . $post->image); ?>" class="post-detail-image" alt="Current Image">
                            </div>
                            <small class="muted-note d-block"><?php echo basename($post->image); ?></small>
                        <?php else: ?>
                            <p class="muted-note">Belum ada gambar</p>
                        <?php endif; ?>
                    </div>

                    <div class="field-block">
                        <label class="form-label">Ganti Gambar</label>
                        <input type="file" name="image" class="form-control" accept="image/jpeg,image/jpg,image/png">
                        <small class="muted-note d-block mt-2">Kosongkan jika tidak ingin mengganti. JPG, JPEG, PNG. Maksimal 2 MB.</small>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="<?php echo base_url('posts'); ?>" class="btn btn-secondary">Batal</a>
        </div>

    <?php echo form_close(); ?>
</div>

<?php $this->load->view('footer'); ?>

