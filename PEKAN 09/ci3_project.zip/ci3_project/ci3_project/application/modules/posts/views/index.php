<?php $this->load->view('header'); ?>

<div class="glow-hero mb-4">
    <div class="d-lg-flex justify-content-between align-items-end">
        <div class="mb-3 mb-lg-0">
            <span class="soft-badge mb-3">Post Board</span>
            <h1 class="hero-title">Kelola postingan dalam ruang kerja gelap yang fokus.</h1>
            <p class="hero-text">Tampilan ini sengaja dibuat berbeda: nuansa gelap, tipografi bersih, dan aksen neon lembut untuk pengalaman menulis yang lebih immersive.</p>
        </div>
        <div class="hero-actions">
            <span class="soft-badge"><?php echo count($posts); ?> post</span>
            <a href="<?php echo base_url('posts/create'); ?>" class="btn btn-light-cta px-4">Tulis Baru</a>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="stat-pill">
            <div class="stat-accent accent-violet">01</div>
            <div class="stat-label">Total Post</div>
            <div class="stat-value"><?php echo count($posts); ?></div>
            <div class="muted-note">Postingan tersimpan.</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-pill">
            <div class="stat-accent accent-cyan">02</div>
            <div class="stat-label">Dengan Gambar</div>
            <div class="stat-value"><?php echo count(array_filter($posts, function ($p) { return !empty($p->image); })); ?></div>
            <div class="muted-note">Post memiliki lampiran visual.</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-pill">
            <div class="stat-accent accent-rose">03</div>
            <div class="stat-label">Status Board</div>
            <div class="stat-value">Aktif</div>
            <div class="muted-note">Siap digunakan kapan saja.</div>
        </div>
    </div>
</div>

<div class="surface-card p-3 p-lg-4">
    <div class="table-shell-header">
        <div>
            <h3 class="section-title mb-1">Daftar Post</h3>
            <p class="muted-note mb-0">Klik detail, edit, atau hapus untuk mengelola setiap post.</p>
        </div>
        <div class="table-shell-meta">Data terbaru di atas</div>
    </div>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Konten</th>
                    <th>Gambar</th>
                    <th>Dibuat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($posts)): ?>
                    <tr>
                        <td colspan="7" class="empty-state">Belum ada post. Tambahkan data pertama Anda.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($posts as $post): ?>
                    <tr>
                        <td><strong>#<?php echo $post->id; ?></strong></td>
                        <td>
                            <div style="color:#fff;font-weight:600;"><?php echo htmlspecialchars($post->title); ?></div>
                            <small class="muted-note"><?php echo strlen($post->article); ?> karakter</small>
                        </td>
                        <td><?php echo htmlspecialchars($post->author); ?></td>
                        <td><div class="article-preview"><?php echo htmlspecialchars($post->article); ?></div></td>
                        <td>
                            <?php if (!empty($post->image)): ?>
                                <img src="<?php echo base_url('uploads/' . $post->image); ?>" class="post-image" alt="Thumbnail">
                            <?php else: ?>
                                <span class="muted-note">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo date('d/m/Y H:i', strtotime($post->created_at)); ?></td>
                        <td>
                            <a href="<?php echo base_url('posts/show/' . $post->id); ?>" class="btn btn-sm btn-info">Detail</a>
                            <a href="<?php echo base_url('posts/edit/' . $post->id); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="<?php echo base_url('posts/delete/' . $post->id); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus post ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $this->load->view('footer'); ?>

