<?php $this->load->view('header'); ?>

<a href="<?php echo base_url('posts'); ?>" class="btn btn-secondary back-link">← Kembali ke Daftar</a>

<div class="glow-hero mb-4">
    <span class="soft-badge mb-3">Detail Post</span>
    <h1 class="hero-title mb-2"><?php echo htmlspecialchars($post->title); ?></h1>
    <p class="hero-text">Ditulis oleh <strong style="color:#fff;"><?php echo htmlspecialchars($post->author); ?></strong> &middot; <?php echo date('d F Y H:i', strtotime($post->created_at)); ?></p>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="surface-card p-4 p-lg-5">
            <?php if($post->image_url): ?>
                <div class="mb-4 text-center">
                    <img src="<?php echo $post->image_url; ?>" alt="<?php echo htmlspecialchars($post->title); ?>" class="post-detail-image">
                </div>
            <?php endif; ?>

            <h4 class="section-title mb-3">Konten</h4>
            <div style="line-height: 1.8; color: var(--ink-soft); white-space: pre-wrap;">
                <?php echo nl2br(htmlspecialchars($post->article)); ?>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="info-panel">
            <div class="field-block">
                <div class="stat-label" style="color:var(--ink-muted);font-size:0.78rem;text-transform:uppercase;font-weight:600;letter-spacing:0.08em;">Informasi</div>
                <div class="meta-line mb-2"><strong>ID:</strong> #<?php echo $post->id; ?></div>
                <div class="meta-line mb-2"><strong>Penulis:</strong> <?php echo htmlspecialchars($post->author); ?></div>
                <div class="meta-line mb-2"><strong>Dibuat:</strong> <?php echo date('d/m/Y H:i', strtotime($post->created_at)); ?></div>
                <?php if(isset($post->updated_at) && $post->updated_at != $post->created_at): ?>
                    <div class="meta-line mb-2"><strong>Diubah:</strong> <?php echo date('d/m/Y H:i', strtotime($post->updated_at)); ?></div>
                <?php endif; ?>
                <div class="meta-line"><strong>Gambar:</strong> <?php echo $post->image ? 'Ya' : 'Tidak ada'; ?></div>
            </div>

            <div class="field-block pt-3 border-top" style="border-color:var(--border-subtle)!important;">
                <div class="stat-label" style="color:var(--ink-muted);font-size:0.78rem;text-transform:uppercase;font-weight:600;letter-spacing:0.08em;">Aksi</div>
                <div class="d-flex flex-wrap gap-2 mt-2">
                    <a href="<?php echo base_url('posts/edit/' . $post->id); ?>" class="btn btn-warning">Edit</a>
                    <a href="<?php echo base_url('posts/delete/' . $post->id); ?>" class="btn btn-danger" onclick="return confirm('Hapus post ini?')">Hapus</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('footer'); ?>

