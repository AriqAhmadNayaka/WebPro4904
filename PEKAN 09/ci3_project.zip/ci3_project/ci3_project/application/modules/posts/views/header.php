<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($title) ? $title : 'Posts Application'; ?> - CI3 CRUD</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --bg-deep: #0b0f19;
            --bg-surface: #111827;
            --bg-elevated: #1a2235;
            --ink-main: #e2e8f0;
            --ink-soft: #94a3b8;
            --ink-muted: #64748b;
            --accent-violet: #8b5cf6;
            --accent-violet-glow: rgba(139, 92, 246, 0.35);
            --accent-cyan: #22d3ee;
            --accent-cyan-glow: rgba(34, 211, 238, 0.30);
            --accent-rose: #fb7185;
            --accent-rose-glow: rgba(251, 113, 133, 0.30);
            --accent-emerald: #34d399;
            --border-subtle: rgba(148, 163, 184, 0.12);
            --border-glow: rgba(139, 92, 246, 0.25);
        }
        * { box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            color: var(--ink-main);
            background: var(--bg-deep);
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }
        .app-navbar {
            background: rgba(17, 24, 39, 0.65);
            backdrop-filter: blur(20px) saturate(1.4);
            -webkit-backdrop-filter: blur(20px) saturate(1.4);
            border-bottom: 1px solid rgba(148, 163, 184, 0.08);
        }
        .app-brand {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 700;
            color: var(--ink-main) !important;
            font-size: 1.5rem;
            letter-spacing: -0.02em;
        }
        .app-brand span { color: var(--accent-violet); }
        .app-navbar .nav-link {
            color: var(--ink-soft) !important;
            font-weight: 500;
            border-radius: 10px;
            padding: 0.4rem 0.85rem !important;
            transition: 0.2s ease;
            font-size: 0.92rem;
        }
        .app-navbar .nav-link:hover {
            color: var(--ink-main) !important;
            background: rgba(139, 92, 246, 0.10);
        }
        .page-shell {
            padding-top: 2rem;
            padding-bottom: 2.5rem;
        }
        .surface-card {
            background: rgba(17, 24, 39, 0.55);
            backdrop-filter: blur(24px) saturate(1.3);
            -webkit-backdrop-filter: blur(24px) saturate(1.3);
            border: 1px solid rgba(148, 163, 184, 0.10);
            border-radius: 20px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.25), 0 8px 32px rgba(0,0,0,0.35);
        }
        .glow-hero {
            position: relative;
            overflow: hidden;
            padding: 2.2rem;
            border-radius: 24px;
            background: linear-gradient(145deg, rgba(26,16,64,0.75) 0%, rgba(17,24,39,0.60) 60%, rgba(11,18,34,0.70) 100%);
            backdrop-filter: blur(20px) saturate(1.4);
            -webkit-backdrop-filter: blur(20px) saturate(1.4);
            border: 1px solid rgba(139, 92, 246, 0.22);
            box-shadow: 0 0 40px rgba(139, 92, 246, 0.12), inset 0 1px 0 rgba(255,255,255,0.06);
        }
        .glow-hero::before {
            content: "";
            position: absolute;
            top: -40%;
            right: -10%;
            width: 320px;
            height: 320px;
            background: radial-gradient(circle, var(--accent-violet-glow), transparent 70%);
            pointer-events: none;
        }
        .glow-hero::after {
            content: "";
            position: absolute;
            bottom: -30%;
            left: -5%;
            width: 260px;
            height: 260px;
            background: radial-gradient(circle, var(--accent-cyan-glow), transparent 70%);
            pointer-events: none;
        }
        .glow-hero > * { position: relative; z-index: 1; }
        .hero-title {
            font-family: 'Space Grotesk', sans-serif;
            font-size: clamp(1.8rem, 3vw, 2.6rem);
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 0.4rem;
            color: #fff;
        }
        .hero-text { max-width: 680px; color: var(--ink-soft); font-size: 0.98rem; }
        .hero-actions { display: flex; gap: 0.75rem; flex-wrap: wrap; align-items: center; }
        .stat-pill {
            height: 100%;
            padding: 1.1rem;
            border-radius: 18px;
            background: rgba(17, 24, 39, 0.50);
            backdrop-filter: blur(18px) saturate(1.2);
            -webkit-backdrop-filter: blur(18px) saturate(1.2);
            border: 1px solid rgba(148, 163, 184, 0.10);
            box-shadow: 0 1px 2px rgba(0,0,0,0.20), inset 0 1px 0 rgba(255,255,255,0.04);
            transition: transform 0.2s ease, border-color 0.2s ease;
        }
        .stat-pill:hover {
            transform: translateY(-3px);
            border-color: rgba(139, 92, 246, 0.30);
            background: rgba(17, 24, 39, 0.60);
        }
        .stat-label {
            color: var(--ink-muted);
            font-size: 0.78rem;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.08em;
            margin-bottom: 0.3rem;
        }
        .stat-value {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.8rem;
            line-height: 1;
            margin-bottom: 0.3rem;
            color: #fff;
        }
        .stat-accent {
            width: 36px; height: 36px;
            display: inline-flex; align-items: center; justify-content: center;
            border-radius: 10px; margin-bottom: 0.7rem;
            font-weight: 700; font-size: 0.8rem;
            color: #fff;
        }
        .accent-violet { background: linear-gradient(135deg, #8b5cf6, #6366f1); box-shadow: 0 4px 12px rgba(139,92,246,0.35); }
        .accent-cyan { background: linear-gradient(135deg, #22d3ee, #0ea5e9); box-shadow: 0 4px 12px rgba(34,211,238,0.35); }
        .accent-rose { background: linear-gradient(135deg, #fb7185, #f43f5e); box-shadow: 0 4px 12px rgba(251,113,133,0.35); }
        .section-title {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 700;
            font-size: 1.35rem;
            color: #fff;
            margin-bottom: 0;
        }
        .btn {
            font-weight: 600;
            border-radius: 12px;
            border-width: 1px;
            padding: 0.55rem 1.1rem;
            font-size: 0.92rem;
            transition: all 0.2s ease;
        }
        .btn-primary {
            background: linear-gradient(135deg, #8b5cf6, #6366f1);
            border-color: transparent;
            color: #fff;
            box-shadow: 0 4px 14px rgba(139, 92, 246, 0.35);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(139, 92, 246, 0.45);
            color: #fff;
        }
        .btn-warning {
            background: linear-gradient(135deg, #f59e0b, #f97316);
            border-color: transparent;
            color: #fff;
            box-shadow: 0 4px 14px rgba(245, 158, 11, 0.30);
        }
        .btn-warning:hover { color: #fff; transform: translateY(-2px); }
        .btn-danger {
            background: linear-gradient(135deg, #fb7185, #e11d48);
            border-color: transparent;
            color: #fff;
            box-shadow: 0 4px 14px rgba(251, 113, 133, 0.30);
        }
        .btn-danger:hover { color: #fff; transform: translateY(-2px); }
        .btn-secondary {
            background: var(--bg-elevated);
            border-color: var(--border-subtle);
            color: var(--ink-soft);
        }
        .btn-secondary:hover {
            border-color: var(--border-glow);
            color: var(--ink-main);
        }
        .btn-info {
            background: linear-gradient(135deg, #22d3ee, #0ea5e9);
            border-color: transparent;
            color: #0f172a;
            box-shadow: 0 4px 14px rgba(34, 211, 238, 0.25);
        }
        .btn-info:hover { color: #0f172a; transform: translateY(-2px); }
        .btn-light-cta {
            background: linear-gradient(135deg, #34d399, #10b981);
            border-color: transparent;
            color: #0f172a;
            box-shadow: 0 4px 14px rgba(52, 211, 153, 0.30);
            font-weight: 700;
        }
        .btn-light-cta:hover { color: #0f172a; transform: translateY(-2px); }
        .form-control {
            border-radius: 12px;
            border: 1px solid var(--border-subtle);
            padding: 0.75rem 0.95rem;
            background: var(--bg-elevated);
            color: var(--ink-main);
            font-size: 0.95rem;
        }
        .form-control:focus {
            border-color: var(--accent-violet);
            box-shadow: 0 0 0 0.2rem rgba(139, 92, 246, 0.20);
            background: #141d2e;
            color: #fff;
        }
        .form-label {
            font-weight: 600;
            color: var(--ink-soft);
            font-size: 0.88rem;
            margin-bottom: 0.4rem;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }
        .table {
            margin-bottom: 0;
            border-collapse: separate;
            border-spacing: 0 8px;
            color: var(--ink-main);
        }
        .table thead th {
            border: none;
            color: var(--ink-muted);
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            font-weight: 600;
            padding: 0.6rem 0.85rem;
        }
        .table tbody tr td {
            background: rgba(17, 24, 39, 0.45);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border-top: 1px solid rgba(148, 163, 184, 0.08);
            border-bottom: 1px solid rgba(148, 163, 184, 0.08);
            vertical-align: middle;
            padding: 1rem 0.85rem;
        }
        .table tbody tr td:first-child {
            border-left: 1px solid rgba(148, 163, 184, 0.08);
            border-top-left-radius: 14px;
            border-bottom-left-radius: 14px;
        }
        .table tbody tr td:last-child {
            border-right: 1px solid rgba(148, 163, 184, 0.08);
            border-top-right-radius: 14px;
            border-bottom-right-radius: 14px;
        }
        .table tbody tr:hover td {
            background: rgba(26, 34, 53, 0.55);
        }
        .soft-badge {
            display: inline-flex; align-items: center;
            padding: 0.35rem 0.7rem; border-radius: 999px;
            background: rgba(139, 92, 246, 0.12);
            border: 1px solid rgba(139, 92, 246, 0.25);
            color: #c4b5fd;
            font-size: 0.75rem;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            font-weight: 600;
        }
        .table-shell-header {
            display: flex; justify-content: space-between; align-items: center;
            gap: 1rem; flex-wrap: wrap; margin-bottom: 0.8rem;
        }
        .table-shell-meta, .muted-note { color: var(--ink-muted); font-size: 0.88rem; }
        .info-panel {
            background: rgba(26, 34, 53, 0.50);
            backdrop-filter: blur(18px) saturate(1.2);
            -webkit-backdrop-filter: blur(18px) saturate(1.2);
            border: 1px solid rgba(148, 163, 184, 0.10);
            border-radius: 18px;
            padding: 1.1rem;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.04);
        }
        .field-block + .field-block { margin-top: 1rem; }
        .empty-state {
            padding: 2.5rem 1rem;
            text-align: center;
            color: var(--ink-muted);
        }
        .alert {
            border-radius: 14px;
            border-width: 1px;
            font-weight: 500;
            font-size: 0.92rem;
        }
        .alert-success {
            background: rgba(52, 211, 153, 0.10);
            border-color: rgba(52, 211, 153, 0.25);
            color: #34d399;
        }
        .alert-danger {
            background: rgba(251, 113, 133, 0.10);
            border-color: rgba(251, 113, 133, 0.25);
            color: #fb7185;
        }
        .post-image {
            max-width: 70px; height: auto;
            border-radius: 10px;
            border: 1px solid var(--border-subtle);
            box-shadow: 0 2px 8px rgba(0,0,0,0.30);
        }
        .post-detail-image {
            max-width: 520px; width: 100%; height: auto;
            border-radius: 18px;
            border: 1px solid var(--border-subtle);
            box-shadow: 0 8px 32px rgba(0,0,0,0.35);
        }
        .article-preview {
            max-width: 240px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: var(--ink-soft);
        }
        .back-link { display: inline-block; margin-bottom: 1.2rem; }
        .meta-line { color: var(--ink-soft); font-size: 0.9rem; }
        .meta-line strong { color: var(--ink-main); }
        @media (max-width: 991px) {
            .page-shell { padding-top: 1.1rem; }
            .glow-hero { padding: 1.5rem; }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg app-navbar">
        <div class="container">
            <a class="navbar-brand app-brand" href="<?php echo base_url('posts'); ?>"><span>//</span> Posts</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="<?php echo base_url(); ?>">Home</a>
                <a class="nav-link" href="<?php echo base_url('posts'); ?>">All Posts</a>
                <a class="nav-link" href="<?php echo base_url('posts/create'); ?>">Create New</a>
                <a class="nav-link" href="<?php echo site_url('crudjs'); ?>">CRUD AJAX</a>
                <a class="nav-link" href="<?php echo site_url('produk'); ?>">Produk</a>
                <a class="nav-link" href="<?php echo site_url('auth/logout'); ?>">Logout</a>
            </div>
        </div>
    </nav>
    <div class="container page-shell">
        <?php if($this->session->flashdata('success')): ?>
            <div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
        <?php endif; ?>
        <?php if($this->session->flashdata('error')): ?>
            <div class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></div>
        <?php endif; ?>

