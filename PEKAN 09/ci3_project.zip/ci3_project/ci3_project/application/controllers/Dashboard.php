<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('App_setup_model');
        $this->load->model('Post_model');
        $this->load->library('form_validation');
        $this->load->library('upload');
        $this->load->helper(array('project', 'form'));
        $this->App_setup_model->ensure_posts_table();
        is_login();
    }

    public function index() {
        $data['posts'] = $this->Post_model->get_posts();
        $data['title'] = 'Dashboard Klasik';
        $this->load->view('templates/legacy_header', $data);
        $this->load->view('dashboard/index', $data);
        $this->load->view('templates/legacy_footer');
    }

    public function form($id = NULL) {
        $data['post'] = $id ? $this->Post_model->get_post($id) : null;
        if ($id && empty($data['post'])) {
            show_404();
        }

        $data['title'] = $id ? 'Edit Data Post' : 'Tambah Data Post';
        $this->load->view('templates/legacy_header', $data);
        $this->load->view('dashboard/form', $data);
        $this->load->view('templates/legacy_footer');
    }

    public function save() {
        if (strtoupper($this->input->server('REQUEST_METHOD')) !== 'POST') {
            show_404();
        }

        $id = $this->input->post('id');
        $existing_post = $id ? $this->Post_model->get_post($id) : NULL;

        if ($id && empty($existing_post)) {
            show_404();
        }

        $this->form_validation->set_rules('title', 'Title', 'required|trim');
        $this->form_validation->set_rules('content', 'Content', 'required');

        if ($this->form_validation->run() === FALSE) {
            $data['post'] = $existing_post;
            $data['title'] = $id ? 'Edit Data Post' : 'Tambah Data Post';
            $this->session->set_flashdata('error', '<div class="alert alert-danger">Judul dan konten wajib diisi.</div>');
            $this->load->view('templates/legacy_header', $data);
            $this->load->view('dashboard/form', $data);
            $this->load->view('templates/legacy_footer');
            return;
        }

        $post_data = array(
            'title' => trim($this->input->post('title', TRUE)),
            'content' => trim($this->input->post('content', TRUE))
        );

        if ($id) {
            $post_data['id'] = $id;
        }

        $upload_result = $this->handle_upload($existing_post);
        if (is_array($upload_result)) {
            $post_data['file_path'] = $upload_result['file_path'];
        } elseif (is_string($upload_result)) {
            $this->session->set_flashdata('error', '<div class="alert alert-danger">' . $upload_result . '</div>');
            redirect($id ? 'dashboard/form/' . $id : 'dashboard/form');
            return;
        }

        if ($this->Post_model->save_post($post_data)) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil disimpan.</div>');
            redirect('dashboard');
            return;
        }

        $db_error = $this->db->error();
        $error_message = !empty($db_error['message']) ? $db_error['message'] : 'Data gagal disimpan.';
        $this->session->set_flashdata('error', '<div class="alert alert-danger">' . html_escape($error_message) . '</div>');
        redirect($id ? 'dashboard/form/' . $id : 'dashboard/form');
    }

    public function delete($id) {
        if ($this->Post_model->delete_post($id)) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil dihapus.</div>');
        } else {
            $this->session->set_flashdata('error', '<div class="alert alert-danger">Data gagal dihapus.</div>');
        }
        redirect('dashboard');
    }

    private function handle_upload($existing_post = NULL) {
        if (empty($_FILES['file']['name'])) {
            return NULL;
        }

        $upload_path = FCPATH . 'uploads/posts/';
        if (!is_dir($upload_path)) {
            mkdir($upload_path, 0755, TRUE);
        }

        $config = array(
            'upload_path' => $upload_path,
            'allowed_types' => 'jpg|jpeg|png|pdf|doc|docx',
            'max_size' => 2048,
            'encrypt_name' => TRUE
        );

        $this->upload->initialize($config);

        if (!$this->upload->do_upload('file')) {
            return trim(strip_tags($this->upload->display_errors('', '')));
        }

        $upload_data = $this->upload->data();
        $file_path = 'uploads/posts/' . $upload_data['file_name'];

        if (!empty($existing_post['file_path'])) {
            $old_file = FCPATH . $existing_post['file_path'];
            if (is_file($old_file)) {
                unlink($old_file);
            }
        }

        return array('file_path' => $file_path);
    }
}

