<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('App_setup_model');
        $this->load->model('Auth_model');
        $this->App_setup_model->ensure_users_table();
        $this->Auth_model->ensure_default_user();
    }

    public function index() {
        if ($this->session->userdata('login_status')) {
            redirect('produk');
        }
        $this->load->view('auth/login');
    }

    public function register() {
        if ($this->session->userdata('login_status')) {
            redirect('produk');
        }

        $this->load->view('auth/register');
    }

    public function login() {
        $this->form_validation->set_rules('username', 'Username', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->index();
            return;
        }

        $username = trim($this->input->post('username', TRUE));
        $password = (string) $this->input->post('password');
        $user = $this->Auth_model->find_user($username);

        if ($user && isset($user['password']) && password_verify($password, $user['password'])) {
            $this->session->set_userdata(array(
                'login_status' => 1,
                'user_id' => $user['id'],
                'username' => $this->Auth_model->get_display_name($user)
            ));
            $this->session->set_flashdata('message', '<div class="alert alert-success">Login berhasil.</div>');
            redirect('produk');
            return;
        }

        $this->session->set_flashdata('message', '<div class="alert alert-danger">Username atau password salah.</div>');
        redirect('auth');
    }

    public function store_register() {
        if ($this->session->userdata('login_status')) {
            redirect('produk');
        }

        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('password_confirm', 'Konfirmasi Password', 'required|matches[password]');

        if ($this->form_validation->run() === FALSE) {
            $this->register();
            return;
        }

        $nama = trim($this->input->post('nama', TRUE));
        $email = trim($this->input->post('email', TRUE));
        $password = (string) $this->input->post('password');

        if ($this->Auth_model->email_exists($email)) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Email sudah terdaftar.</div>');
            redirect('auth/register');
            return;
        }

        $saved = $this->Auth_model->create_user(array(
            'nama' => $nama,
            'email' => $email,
            'password' => $password,
            'username' => $email
        ));

        if ($saved) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Pendaftaran berhasil. Silakan login.</div>');
            redirect('auth');
            return;
        }

        $this->session->set_flashdata('message', '<div class="alert alert-danger">Pendaftaran gagal. Coba lagi.</div>');
        redirect('auth/register');
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('auth');
    }
}

