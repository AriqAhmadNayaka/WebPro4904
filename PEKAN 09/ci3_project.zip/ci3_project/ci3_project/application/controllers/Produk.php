<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produk extends CI_Controller {

    private $status_options = array('Tersedia', 'Stok Menipis', 'Preorder', 'Nonaktif');

    public function __construct() {
        parent::__construct();
        $this->load->model('App_setup_model');
        $this->load->model('Product_model');
        $this->load->library('form_validation');
        $this->load->helper(array('project', 'form'));
        $this->App_setup_model->ensure_products_table();
        is_login();
    }

    public function index() {
        $data['products'] = $this->Product_model->get_all();
        $data['summary'] = $this->Product_model->get_summary();
        $data['title'] = 'Inventori Produk';
        $this->load->view('templates/header', $data);
        $this->load->view('produk/index', $data);
        $this->load->view('templates/footer');
    }

    public function form($id = NULL) {
        $data['product'] = $id ? $this->Product_model->get_by_id($id) : NULL;

        if ($id && empty($data['product'])) {
            show_404();
        }

        $data['title'] = $id ? 'Edit Produk' : 'Tambah Produk';
        $data['status_options'] = $this->status_options;

        $this->load->view('templates/header', $data);
        $this->load->view('produk/form', $data);
        $this->load->view('templates/footer');
    }

    public function save() {
        if (strtoupper($this->input->server('REQUEST_METHOD')) !== 'POST') {
            show_404();
        }

        $id = $this->input->post('id');
        $product = $id ? $this->Product_model->get_by_id($id) : NULL;

        if ($id && empty($product)) {
            show_404();
        }

        $this->form_validation->set_rules('product_code', 'Kode Produk', 'required|trim');
        $this->form_validation->set_rules('product_name', 'Nama Produk', 'required|trim');
        $this->form_validation->set_rules('category', 'Kategori', 'required|trim');
        $this->form_validation->set_rules('supplier', 'Supplier', 'trim');
        $this->form_validation->set_rules('price', 'Harga', 'required|numeric');
        $this->form_validation->set_rules('stock', 'Stok', 'required|integer');
        $this->form_validation->set_rules('status', 'Status', 'required|trim');

        if ($this->form_validation->run() === FALSE) {
            $data['product'] = $product;
            $data['title'] = $id ? 'Edit Produk' : 'Tambah Produk';
            $data['status_options'] = $this->status_options;
            $this->session->set_flashdata('error', '<div class="alert alert-danger">Semua field penting wajib diisi dengan format yang benar.</div>');
            $this->load->view('templates/header', $data);
            $this->load->view('produk/form', $data);
            $this->load->view('templates/footer');
            return;
        }

        $payload = array(
            'product_code' => strtoupper(trim($this->input->post('product_code', TRUE))),
            'product_name' => trim($this->input->post('product_name', TRUE)),
            'category' => trim($this->input->post('category', TRUE)),
            'supplier' => trim($this->input->post('supplier', TRUE)),
            'price' => (float) $this->input->post('price'),
            'stock' => (int) $this->input->post('stock'),
            'status' => trim($this->input->post('status', TRUE)),
        );

        if ($this->Product_model->product_code_exists($payload['product_code'], $id ? (int) $id : NULL)) {
            $this->session->set_flashdata('error', '<div class="alert alert-danger">Kode produk sudah dipakai. Gunakan kode lain.</div>');
            redirect($id ? 'produk/form/' . $id : 'produk/form');
            return;
        }

        if ($this->Product_model->save($payload, $id ? (int) $id : NULL)) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data produk berhasil disimpan.</div>');
            redirect('produk');
            return;
        }

        $this->session->set_flashdata('error', '<div class="alert alert-danger">Data produk gagal disimpan.</div>');
        redirect($id ? 'produk/form/' . $id : 'produk/form');
    }

    public function delete($id) {
        $product = $this->Product_model->get_by_id($id);

        if (empty($product)) {
            show_404();
        }

        if ($this->Product_model->delete($id)) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Produk berhasil dihapus dari inventori.</div>');
        } else {
            $this->session->set_flashdata('error', '<div class="alert alert-danger">Produk gagal dihapus.</div>');
        }

        redirect('produk');
    }
}
