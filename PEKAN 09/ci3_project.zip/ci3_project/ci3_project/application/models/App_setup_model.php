<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class App_setup_model extends CI_Model {

    public function ensure_tables() {
        $this->ensure_users_table();
        $this->ensure_posts_table();
        $this->ensure_products_table();
    }

    public function ensure_users_table() {
        if ($this->db->table_exists('users')) {
            return;
        }

        $sql = "CREATE TABLE `users` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `username` VARCHAR(50) NOT NULL,
            `password` VARCHAR(255) NOT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `username_unique` (`username`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8";

        $this->db->query($sql);
    }

    public function ensure_posts_table() {
        if ($this->db->table_exists('posts')) {
            return;
        }

        $sql = "CREATE TABLE `posts` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `title` VARCHAR(255) NOT NULL,
            `content` TEXT NOT NULL,
            `file_path` VARCHAR(255) DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8";

        $this->db->query($sql);
    }

    public function ensure_products_table() {
        if ($this->db->table_exists('products')) {
            return;
        }

        $sql = "CREATE TABLE `products` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `product_code` VARCHAR(30) NOT NULL,
            `product_name` VARCHAR(150) NOT NULL,
            `category` VARCHAR(80) NOT NULL,
            `supplier` VARCHAR(120) DEFAULT NULL,
            `price` DECIMAL(12,2) NOT NULL DEFAULT 0,
            `stock` INT NOT NULL DEFAULT 0,
            `status` VARCHAR(30) NOT NULL DEFAULT 'tersedia',
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME DEFAULT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `product_code_unique` (`product_code`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8";

        $this->db->query($sql);
    }
}
