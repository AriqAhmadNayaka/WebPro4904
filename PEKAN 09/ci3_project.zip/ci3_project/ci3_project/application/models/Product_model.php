<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {

    private $table = 'products';

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_all() {
        return $this->db
            ->order_by('created_at', 'DESC')
            ->get($this->table)
            ->result_array();
    }

    public function get_by_id($id) {
        return $this->db
            ->get_where($this->table, array('id' => (int) $id))
            ->row_array();
    }

    public function product_code_exists($product_code, $ignore_id = NULL) {
        $this->db->from($this->table);
        $this->db->where('product_code', $product_code);

        if ($ignore_id !== NULL) {
            $this->db->where('id !=', (int) $ignore_id);
        }

        return $this->db->count_all_results() > 0;
    }

    public function save($data, $id = NULL) {
        if ($id === NULL) {
            $data['created_at'] = date('Y-m-d H:i:s');
            return $this->db->insert($this->table, $data);
        }

        $data['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->where('id', (int) $id)->update($this->table, $data);
    }

    public function delete($id) {
        return $this->db->where('id', (int) $id)->delete($this->table);
    }

    public function get_summary() {
        $products = $this->get_all();

        $summary = array(
            'total_products' => count($products),
            'active_categories' => 0,
            'low_stock' => 0,
            'inventory_value' => 0,
        );

        $categories = array();

        foreach ($products as $product) {
            $categories[] = $product['category'];

            if ((int) $product['stock'] <= 5) {
                $summary['low_stock']++;
            }

            $summary['inventory_value'] += ((float) $product['price']) * ((int) $product['stock']);
        }

        $summary['active_categories'] = count(array_unique($categories));

        return $summary;
    }
}
