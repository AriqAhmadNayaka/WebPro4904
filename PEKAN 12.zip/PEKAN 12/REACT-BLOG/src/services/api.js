import axios from 'axios'

// Base URL API CI3. Bisa diganti lewat file .env dengan VITE_API_URL.
const API_URL = import.meta.env.VITE_API_URL || '/ci3_project/ci3_project/api'

// Instance Axios utama supaya semua request memakai konfigurasi yang sama.
const api = axios.create({
  baseURL: API_URL,
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  },
  transformResponse: [
    (data) => {
      // CI3 kadang mengirim warning HTML sebelum JSON; bagian ini tetap mengambil JSON-nya.
      if (typeof data !== 'string' || data.length === 0) {
        return data
      }

      try {
        return JSON.parse(data)
      } catch {
        const jsonStart = data.indexOf('{')
        const jsonEnd = data.lastIndexOf('}')

        if (jsonStart >= 0 && jsonEnd > jsonStart) {
          return JSON.parse(data.slice(jsonStart, jsonEnd + 1))
        }

        return data
      }
    },
  ],
})

// Mengambil token dari localStorage untuk dipasang pada header Authorization.
function getStoredToken() {
  try {
    const raw = localStorage.getItem('react_posts_auth')
    return raw ? JSON.parse(raw).token : null
  } catch {
    return null
  }
}

// Interceptor request otomatis menambahkan token JWT saat user sudah login.
api.interceptors.request.use((config) => {
  const token = getStoredToken()

  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }

  return config
})

// Interceptor response menyederhanakan pesan error agar mudah ditampilkan di UI.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const message =
      error.response?.data?.message ||
      error.message ||
      'Terjadi kesalahan saat memproses request.'

    return Promise.reject(new Error(message))
  },
)

// Kumpulan request untuk fitur autentikasi.
export const authAPI = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  logout: () => api.post('/auth/logout'),
  me: () => api.get('/auth/me'),
}

// Kumpulan request untuk data posts.
export const postsAPI = {
  getAll: (params = {}) => api.get('/posts', { params }),
  getById: (id) => api.get(`/posts/${id}`),
  create: (data) => api.post('/posts', data),
  update: (id, data) => api.put(`/posts/${id}`, data),
  delete: (id) => api.delete(`/posts/${id}`),
}

export default api
