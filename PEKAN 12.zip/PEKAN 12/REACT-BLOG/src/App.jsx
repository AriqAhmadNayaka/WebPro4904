import { Navigate, Route, Routes } from 'react-router-dom'
import ProtectedRoute from './components/ProtectedRoute'
import { AuthProvider } from './context/AuthContext'
import Login from './pages/Login'
import PostDetail from './pages/PostDetail'
import PostList from './pages/PostList'

function App() {
  return (
    // AuthProvider membungkus seluruh route supaya semua halaman bisa memakai data login.
    <AuthProvider>
      <Routes>
        {/* Saat user membuka root "/", langsung diarahkan ke halaman posts. */}
        <Route path="/" element={<Navigate to="/posts" replace />} />
        <Route path="/login" element={<Login />} />

        {/* Route posts dilindungi, jadi user harus login terlebih dahulu. */}
        <Route
          path="/posts"
          element={
            <ProtectedRoute>
              <PostList />
            </ProtectedRoute>
          }
        />

        {/* Detail post juga hanya bisa dibuka setelah login. */}
        <Route
          path="/posts/:id"
          element={
            <ProtectedRoute>
              <PostDetail />
            </ProtectedRoute>
          }
        />

        {/* Kalau path tidak dikenali, arahkan kembali ke posts. */}
        <Route path="*" element={<Navigate to="/posts" replace />} />
      </Routes>
    </AuthProvider>
  )
}

export default App
