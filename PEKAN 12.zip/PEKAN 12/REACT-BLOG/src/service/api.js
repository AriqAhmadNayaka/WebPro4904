// File ini hanya alias agar import lama dari folder "service" tetap berjalan.
export * from '../services/api'
export { default } from '../services/api'
