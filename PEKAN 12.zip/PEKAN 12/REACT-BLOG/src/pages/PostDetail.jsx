import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { postsAPI } from '../services/api'

// Mengubah format tanggal dari database menjadi format Indonesia.
function formatDate(value) {
  if (!value) return '-'

  return new Intl.DateTimeFormat('id-ID', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(value.replace(' ', 'T')))
}

function PostDetail() {
  // id diambil dari URL /posts/:id.
  const { id } = useParams()
  const [post, setPost] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // Mengambil detail post dari API setiap id berubah.
  useEffect(() => {
    let ignore = false

    async function fetchPost() {
      setLoading(true)
      setError('')

      try {
        const response = await postsAPI.getById(id)
        if (!ignore) {
          setPost(response.data.data)
        }
      } catch {
        if (!ignore) {
          setError('Post tidak ditemukan atau gagal dimuat.')
        }
      } finally {
        if (!ignore) {
          setLoading(false)
        }
      }
    }

    fetchPost()

    return () => {
      // Mencegah update state jika user pindah halaman saat request masih berjalan.
      ignore = true
    }
  }, [id])

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-8 text-slate-950">
      <article className="mx-auto max-w-4xl overflow-hidden rounded-lg bg-white shadow-sm ring-1 ring-slate-200">
        <div className="border-b border-slate-200 p-5">
          <Link
            className="inline-flex rounded-md border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
            to="/posts"
          >
            Kembali
          </Link>
        </div>

        {loading ? (
          <div className="space-y-5 p-6">
            <div className="h-72 animate-pulse rounded-lg bg-slate-200" />
            <div className="h-8 w-2/3 animate-pulse rounded bg-slate-200" />
            <div className="h-32 animate-pulse rounded bg-slate-200" />
          </div>
        ) : error ? (
          <div className="p-6">
            <div className="rounded-md border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
              {error}
            </div>
          </div>
        ) : post ? (
          <>
            {post.image_url ? (
              <img
                className="h-80 w-full object-cover"
                src={post.image_url}
                alt={post.title}
              />
            ) : (
              <div className="flex h-72 items-center justify-center bg-slate-950 text-sm font-semibold uppercase tracking-widest text-cyan-200">
                React Posts
              </div>
            )}

            <div className="p-6 text-left sm:p-8">
              <p className="text-sm font-semibold uppercase tracking-widest text-blue-700">
                {post.author || 'Tanpa author'}
              </p>
              <h1 className="mt-4 text-4xl font-bold leading-tight text-slate-950">
                {post.title}
              </h1>

              <dl className="mt-6 grid gap-4 rounded-lg bg-slate-50 p-4 text-sm sm:grid-cols-2">
                <div>
                  <dt className="font-semibold text-slate-500">Dibuat</dt>
                  <dd className="mt-1 text-slate-800">
                    {formatDate(post.created_at)}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-slate-500">Diupdate</dt>
                  <dd className="mt-1 text-slate-800">
                    {formatDate(post.updated_at)}
                  </dd>
                </div>
              </dl>

              <div className="mt-8 whitespace-pre-line text-base leading-8 text-slate-700">
                {post.article || post.description || 'Tidak ada isi artikel.'}
              </div>
            </div>
          </>
        ) : null}
      </article>
    </main>
  )
}

export default PostDetail
