import { useState } from 'react'
import { Navigate, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/useAuth'

function Login() {
  const { isAuthenticated, login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  // Jika user sebelumnya diarahkan dari halaman tertentu, setelah login dikembalikan ke halaman itu.
  const from = location.state?.from?.pathname || '/posts'

  // State form menyimpan nilai input email dan password.
  const [form, setForm] = useState({
    email: '',
    password: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // User yang sudah login tidak perlu melihat halaman login lagi.
  if (isAuthenticated) {
    return <Navigate to={from} replace />
  }

  // Mengubah state form sesuai input yang sedang diketik.
  const handleChange = (event) => {
    setForm((current) => ({
      ...current,
      [event.target.name]: event.target.value,
    }))
  }

  // Submit login ke backend. Jika berhasil, pindah ke halaman posts.
  const handleSubmit = async (event) => {
    event.preventDefault()
    setLoading(true)
    setError('')

    try {
      await login(form.email, form.password)
      navigate(from, { replace: true })
    } catch (err) {
      setError(err.message || 'Login gagal. Periksa email dan password.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-10 text-slate-900">
      <section className="mx-auto flex min-h-[calc(100vh-5rem)] max-w-md items-center">
        <div className="w-full rounded-md bg-white p-7 shadow-md shadow-slate-200 ring-1 ring-slate-200">
          <div className="mb-7 text-center">
            <div className="mx-auto mb-4 grid h-8 w-8 grid-cols-2 gap-1">
              <span className="rounded-sm bg-blue-600" />
              <span className="rounded-sm bg-blue-600" />
              <span className="rounded-sm bg-blue-600" />
              <span className="rounded-sm bg-blue-600" />
            </div>
            <h1 className="text-2xl font-bold text-slate-800">Blog Posts</h1>
            <p className="mt-2 text-sm text-slate-500">
              Silakan login untuk masuk ke halaman blog.
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            {error ? (
              <div className="mb-5 rounded-md border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
                {error}
              </div>
            ) : null}

            <label className="block text-left text-sm font-semibold text-slate-700">
              Email
              <input
                className="mt-2 w-full rounded-md border border-slate-300 px-4 py-2.5 text-slate-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                placeholder="nama@email.com"
                required
              />
            </label>

            <label className="mt-4 block text-left text-sm font-semibold text-slate-700">
              Password
              <input
                className="mt-2 w-full rounded-md border border-slate-300 px-4 py-2.5 text-slate-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                name="password"
                type="password"
                value={form.password}
                onChange={handleChange}
                placeholder="Minimal 6 karakter"
                required
              />
            </label>

            <button
              className="mt-6 w-full rounded-md bg-blue-600 px-4 py-2.5 font-bold text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:bg-blue-300"
              type="submit"
              disabled={loading}
            >
              {loading ? 'Loading...' : 'Login'}
            </button>
          </form>
        </div>
      </section>
    </main>
  )
}

export default Login
