import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/useAuth'
import { postsAPI } from '../services/api'

// Data contoh ditampilkan jika database/API belum memiliki post.
const samplePosts = [
  {
    id: 'sample-1',
    title: 'Pengenalan React JS',
    author: 'Admin',
    article:
      'React adalah library JavaScript untuk membangun user interface. React dikembangkan oleh Facebook dan telah menjadi salah satu library frontend paling populer.',
  },
  {
    id: 'sample-2',
    title: 'Memahami State dan Props di React',
    author: 'Admin',
    article:
      'State dan Props adalah dua konsep fundamental dalam React yang perlu dipahami dengan baik. Props adalah data yang dikirim dari parent component.',
  },
  {
    id: 'sample-3',
    title: 'React Hooks: useState dan useEffect',
    author: 'Admin',
    article:
      'Hooks adalah fitur baru di React 16.8 yang memungkinkan kita menggunakan state dan fitur React lainnya tanpa menulis class component.',
  },
  {
    id: 'sample-4',
    title: 'Routing di React dengan React Router',
    author: 'Admin',
    article:
      'React Router adalah library standar untuk routing di aplikasi React. Dengan React Router, kita bisa membuat Single Page Application dengan mudah.',
  },
]

// Memotong isi artikel agar kartu tidak terlalu tinggi.
function truncateText(text = '', maxLength = 150) {
  if (text.length <= maxLength) return text
  return `${text.slice(0, maxLength).trim()}...`
}

function PostList() {
  const { user, logout } = useAuth()
  const [posts, setPosts] = useState([])
  const [pagination, setPagination] = useState(null)
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // Ambil posts dari backend setiap kali halaman pagination berubah.
  useEffect(() => {
    let ignore = false

    async function fetchPosts() {
      setLoading(true)
      setError('')

      try {
        const response = await postsAPI.getAll({ page, per_page: 9 })
        if (ignore) return

        // Format response backend: { data: [...], pagination: {...} }.
        setPosts(response.data.data || [])
        setPagination(response.data.pagination || null)
      } catch {
        if (!ignore) {
          setError('Gagal memuat posts. Silakan coba lagi.')
        }
      } finally {
        if (!ignore) {
          setLoading(false)
        }
      }
    }

    fetchPosts()

    return () => {
      // Mencegah setState setelah komponen sudah tidak aktif.
      ignore = true
    }
  }, [page])

  // Kalau backend kosong, pakai data contoh agar layout tetap terlihat.
  const visiblePosts = posts.length > 0 ? posts : samplePosts

  return (
    <main className="min-h-screen bg-slate-100 text-slate-900">
      <header className="border-b border-slate-200 bg-white shadow-sm">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-6">
          <div className="flex items-center gap-2">
            <span className="grid h-5 w-5 grid-cols-2 gap-0.5">
              <span className="rounded-sm bg-blue-600" />
              <span className="rounded-sm bg-blue-600" />
              <span className="rounded-sm bg-blue-600" />
              <span className="rounded-sm bg-blue-600" />
            </span>
            <span className="text-base font-bold text-slate-800">Blog Posts</span>
          </div>

          <nav className="hidden items-center gap-10 text-sm font-medium md:flex">
            <a className="text-blue-600" href="#home">
              Home
            </a>
            <a className="text-slate-600 hover:text-blue-600" href="#about">
              About
            </a>
            <a className="text-slate-600 hover:text-blue-600" href="#contact">
              Contact
            </a>
          </nav>

          <div className="flex items-center gap-3">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-200 text-xs font-bold text-slate-500">
              {String(user?.name || user?.email || 'A').slice(0, 1).toUpperCase()}
            </span>
            <span className="hidden text-sm font-semibold text-slate-700 sm:inline">
              Admin
            </span>
            <button
              className="rounded-md bg-rose-500 px-4 py-2 text-xs font-bold text-white shadow-sm transition hover:bg-rose-600"
              type="button"
              onClick={logout}
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-6 py-14" id="home">
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900">
            Our Blog
          </h1>
          <p className="mt-4 text-sm text-slate-400">
            Explore our collection of articles about React, web development, and
            more.
          </p>
        </div>

        {error ? (
          <div className="mb-6 rounded-md border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
            {error}
          </div>
        ) : null}

        {loading ? (
          <div className="grid gap-8 md:grid-cols-2">
            {Array.from({ length: 4 }).map((_, index) => (
              <div
                className="h-48 animate-pulse rounded-md bg-white shadow-sm"
                key={index}
              />
            ))}
          </div>
        ) : (
          <div className="grid gap-8 md:grid-cols-2">
            {visiblePosts.map((post) => (
              <article
                className="rounded-md bg-white p-6 text-left shadow-md shadow-slate-200 ring-1 ring-slate-200 transition hover:-translate-y-0.5 hover:shadow-lg"
                key={post.id}
              >
                <div className="mb-4 flex items-center justify-between">
                  <span className="rounded bg-blue-50 px-2 py-1 text-xs font-bold text-blue-600">
                    Article
                  </span>
                  <span className="text-xs font-semibold text-slate-500">
                    Today
                  </span>
                </div>

                <h2 className="text-xl font-extrabold leading-snug text-slate-800">
                  {post.title}
                </h2>
                <p className="mt-3 min-h-12 text-sm leading-6 text-slate-400">
                  {truncateText(post.article || post.description || '', 135)}
                </p>

                <div className="mt-6 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-200 text-xs font-bold text-slate-500">
                      A
                    </span>
                    <span className="text-sm font-bold text-slate-700">
                      {post.author || 'Admin'}
                    </span>
                  </div>
                  <Link
                    className="text-sm font-bold text-blue-600 transition hover:text-blue-800"
                    to={
                      // Data contoh tidak punya detail API, jadi tetap di halaman posts.
                      String(post.id).startsWith('sample-')
                        ? '/posts'
                        : `/posts/${post.id}`
                    }
                  >
                    Read more
                  </Link>
                </div>
              </article>
            ))}
          </div>
        )}

        {posts.length > 0 && pagination && pagination.last_page > 1 ? (
          <div className="mt-8 flex items-center justify-center gap-3">
            <button
              className="rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 disabled:cursor-not-allowed disabled:opacity-50"
              type="button"
              disabled={page <= 1 || loading}
              // Tombol untuk kembali ke halaman sebelumnya.
              onClick={() => setPage((current) => Math.max(1, current - 1))}
            >
              Sebelumnya
            </button>
            <button
              className="rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 disabled:cursor-not-allowed disabled:opacity-50"
              type="button"
              disabled={page >= pagination.last_page || loading}
              // Tombol untuk menuju halaman berikutnya.
              onClick={() =>
                setPage((current) => Math.min(pagination.last_page, current + 1))
              }
            >
              Berikutnya
            </button>
          </div>
        ) : null}
      </section>
    </main>
  )
}

export default PostList
