import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      // Proxy ini membuat request /ci3_project dari React diteruskan ke Apache XAMPP.
      '/ci3_project': {
        target: 'http://localhost',
        changeOrigin: true,
      },
    },
  },
})
