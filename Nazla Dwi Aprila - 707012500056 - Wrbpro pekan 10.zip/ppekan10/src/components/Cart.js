export function Cart(cart, onCheckout) {//memapilkan isi cart dan total harga
const container = document.getElementById("cart");//mengambil elemen cart dari DOM
container.innerHTML = "<h2>Your Cart</h2>";//judul cart

if (cart.length === 0) {//jika cart kosong, tampilkan pesan
container.innerHTML += "<p class='empty-msg'>Cart is empty.</p>";//pesan cart kosong
return;
}

const list = document.createElement("div");//membuat elemen div untuk daftar item cart
list.className = "cart-list";//kelas untuk styling

cart.map((item) => {//iterasi setiap item dalam cart
const div = document.createElement("div");//membuat elemen div untuk setiap item
div.className = "cart-item";//kelas untuk styling item cart
div.innerHTML = `
<img src="${item.image}" alt="${item.title}" />
<div class="cart-details">
<h4>${item.title}</h4>
<span>$${item.price}</span>
</div>
`;
list.appendChild(div);//menambahkan item ke dalam daftar cart
});

container.appendChild(list);//menambahkan daftar item ke dalam elemen cart

const total = cart.reduce((acc, item) => acc + (item.price || 0), 0);

const footer = document.createElement("div");
footer.className = "cart-footer-summary";
footer.innerHTML = `
<div class="total-row">
<span>Total:</span>
<span class="total-price">$${total.toFixed(2)}</span>
</div>
<button class="btn-primary" id="checkout-btn">Buy Now</button>
`;

footer.querySelector("#checkout-btn").addEventListener("click", onCheckout);
container.appendChild(footer);
}