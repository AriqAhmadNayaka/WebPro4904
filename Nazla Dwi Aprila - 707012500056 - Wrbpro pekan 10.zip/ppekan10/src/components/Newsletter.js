export function Newsletter() {//memapilkan form newsletter dan pesan sukses
const $container = $('<div class="newsletter-section"></div>');//membuat elemen div untuk newsletter 
const $content = $(`//isi newsletter dengan form dan pesan sukses
<div class="newsletter-content">
<h3>Subscribe to our updates</h3>
<p>Get the latest tech news and offers.</p>
<form id="newsletter-form">
<input type="email" placeholder="Enter your email" required />
<button type="submit" class="btn-primary">Subscribe</button>
</form>
<div class="success-message" style="display:none; margin-top: 10px; color: green;">
Thanks for subscribing!
</div>
</div>
`);

$container.append($content);//menambahkan isi newsletter ke dalam container
$("#app").append($container);//menambahkan newsletter ke dalam elemen dengan id "app"

$content.find("form").on("submit", function (e) {//menangani submit form newsletter
e.preventDefault();
const $form = $(this);

$form.slideUp(400, function() {//sembunyikan form dengan animasi slide up
// Show success message with fade in
$content.find(".success-message").fadeIn();//tampilkan pesan sukses dengan animasi fade in
});
});
}
