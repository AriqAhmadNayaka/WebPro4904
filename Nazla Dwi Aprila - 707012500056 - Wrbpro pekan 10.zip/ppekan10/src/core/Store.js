import { deepClone } from "./utils.js";//fungsi untuk membuat salinan mendalam dari objek state

let state = {
products: [],
cart: [],
};

export const getState = () => deepClone(state);//fungsi untuk mendapatkan salinan state saat ini

export const setState = (newState) => {
    const nextState = { ...state, ...newState };

state = nextState;

console.log("[Store] State updated:", state);
};

