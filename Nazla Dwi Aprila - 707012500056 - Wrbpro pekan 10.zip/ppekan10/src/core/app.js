import { fetchProducts } from "../api/productApi.js";//fungsi untuk mengambil data produk dari API
import { getState, setState } from "./Store.js";//fungsi untuk mengelola state aplikasi
import { ProductList } from "../components/ProductList.js";//komponen untuk menampilkan daftar produk
import { Cart } from "../components/Cart.js";//komponen untuk menampilkan isi cart
import { Newsletter } from "../components/Newsletter.js";//komponen untuk menampilkan form newsletter

function addToCart(product) {//fungsi untuk menambahkan produk ke dalam cart
const state = getState();

setState({//update state dengan menambahkan produk ke dalam cart
cart: [...state.cart, product],
});

render();
}

function checkout() {//fungsi untuk melakukan checkout dan mengosongkan cart
setState({ cart: [] });
alert("Thank you for your purchase!");
render();
}

function render() {//fungsi untuk merender tampilan aplikasi
const state = getState();
ProductList(state.products, addToCart);
Cart(state.cart, checkout);
}

async function init() {//fungsi untuk inisialisasi aplikasi, mengambil data produk, dan merender tampilan awal
try {
const data = await fetchProducts();
setState({ products: data });
render();
Newsletter();
} catch (error) {
console.error("Failed to load products:", error);
}
}

init();
