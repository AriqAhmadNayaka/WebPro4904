export function deepClone(obj) {//fungsi untuk membuat salinan mendalam dari objek, menangani array dan objek biasa
if (obj === null || typeof obj !== "object") {
return obj;
}
if (obj instanceof Date) {//menangani objek Date
return new Date(obj.getTime());
}

if (Array.isArray(obj)) {//menangani array
return obj.map((item) => deepClone(item));
}

const clonedObj = {};//menangani objek biasa
for (const key in obj) {
if (Object.prototype.hasOwnProperty.call(obj, key)) {
clonedObj[key] = deepClone(obj[key]);
}
}
return clonedObj;
}
