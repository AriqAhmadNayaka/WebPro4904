<?php
 echo $data;
?>