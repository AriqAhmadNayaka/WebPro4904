import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({ command }) => ({
  base: command === 'build' ? '/Pemrograman Web/WebPro4904/Pekan12/dist/' : '/',
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost/ci3_project',
        changeOrigin: true,
      },
    },
  },
}))
