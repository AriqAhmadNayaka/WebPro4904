<?php
header('Location: ci3_project/', true, 302);
exit;
