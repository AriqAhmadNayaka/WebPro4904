# PANDUAN TESTING API DENGAN POSTMAN

## Setup awal

1. Jalankan Apache dan MySQL di XAMPP.
2. Import database dan pastikan tabel `users` serta kolom `posts.user_id` dan `posts.image` sudah ada.
3. Import file `CI3_API_Postman_Collection.json` ke Postman.
4. Set variable `base_url` menjadi `http://localhost/ci3_project`.

## Endpoint utama yang dipakai

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `POST /api/auth/logout`
- `GET /api/post`
- `GET /api/post/{id}`
- `GET /api/post/my`
- `POST /api/post`
- `PUT /api/post/{id}`
- `DELETE /api/post/{id}`

## Urutan testing yang disarankan

1. Buka `http://localhost/ci3_project/test` untuk cek setup.
2. Jalankan `Register User`.
3. Jalankan `Login User`.
4. Jalankan `Get All Posts`.
5. Jalankan `Create Post`.
6. Jalankan `Get My Posts`.
7. Jalankan `Update Post`.
8. Jalankan `Delete Post`.
9. Jalankan `Logout User`.

## Detail request

### 1. Register User

- Method: `POST`
- URL: `{{base_url}}/api/auth/register`
- Body: `x-www-form-urlencoded`

```text
username=postmanuser
email=postmanuser@example.com
password=123456
password_confirm=123456
```

Expected response:

```json
{
  "status": "success",
  "message": "Registration successful",
  "data": {
    "user_id": 1
  }
}
```

### 2. Login User

- Method: `POST`
- URL: `{{base_url}}/api/auth/login`
- Body: `x-www-form-urlencoded`

```text
username=postmanuser
password=123456
```

Expected response:

```json
{
  "status": "success",
  "message": "Login successful",
  "data": {
    "user_id": 1,
    "username": "postmanuser"
  }
}
```

Catatan: setelah login, Postman biasanya otomatis menyimpan cookie session untuk domain yang sama.

### 3. Get Current User

- Method: `GET`
- URL: `{{base_url}}/api/auth/me`
- Butuh session cookie dari login

### 4. Get All Posts

- Method: `GET`
- URL: `{{base_url}}/api/post`

### 5. Get Single Post

- Method: `GET`
- URL: `{{base_url}}/api/post/1`

### 6. Get My Posts

- Method: `GET`
- URL: `{{base_url}}/api/post/my`
- Butuh session cookie dari login

### 7. Create Post

- Method: `POST`
- URL: `{{base_url}}/api/post`
- Body: `form-data`
- Butuh session cookie dari login

```text
title   = Post dari Postman
author  = Postman User
article = Ini adalah artikel yang dibuat dari Postman
image   = optional file jpg/jpeg/png
```

### 8. Update Post

- Method: `PUT`
- URL: `{{base_url}}/api/post/1`
- Header: `Content-Type: application/json`
- Butuh session cookie dari login

```json
{
  "title": "Post dari Postman Updated",
  "author": "Postman User",
  "article": "Artikel yang sudah diupdate dari Postman"
}
```

### 9. Delete Post

- Method: `DELETE`
- URL: `{{base_url}}/api/post/1`
- Butuh session cookie dari login

Success response:

- `204 No Content`

## Troubleshooting

- `Authentication required`
  Pastikan request login berhasil dan cookie session masih ada.

- `Access denied`
  Post yang diupdate atau dihapus bukan milik user yang login.

- `Endpoint not found for HTTP method ...`
  Cek method request dan URL endpoint, lalu pastikan memakai `/api/post` atau `/api/auth/...`.

- `Registration failed`
  Cek tabel `users` dan constraint unik pada `username` atau `email`.
