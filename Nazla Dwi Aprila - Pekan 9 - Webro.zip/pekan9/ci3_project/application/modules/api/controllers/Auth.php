<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends MX_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('auth_model');
        $this->load->library('form_validation');
        $this->load->helper(array('url', 'form'));
        $this->load->library('session');
    }

    // POST /api/auth/login - User login
    public function login_post()
    {
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->output
                ->set_status_header(400)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => validation_errors()
                )));
        } else {
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            $user = $this->auth_model->login($username, $password);

            if ($user) {
                // Set session
                $this->session->set_userdata('user_id', $user['id']);
                $this->session->set_userdata('username', $user['username']);
                $this->session->set_userdata('logged_in', TRUE);

                $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode(array(
                        'status' => 'success',
                        'message' => 'Login successful',
                        'data' => array(
                            'user_id' => $user['id'],
                            'username' => $user['username']
                        )
                    )));
            } else {
                $this->output
                    ->set_status_header(401)
                    ->set_content_type('application/json')
                    ->set_output(json_encode(array(
                        'status' => 'error',
                        'message' => 'Invalid username or password'
                    )));
            }
        }
    }

    // POST /api/auth/register - User registration
    public function register_post()
    {
        $this->form_validation->set_rules('username', 'Username', 'required|is_unique[users.username]');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('password_confirm', 'Password Confirmation', 'required|matches[password]');

        if ($this->form_validation->run() === FALSE) {
            $this->output
                ->set_status_header(400)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => validation_errors()
                )));
        } else {
            $data = array(
                'username' => $this->input->post('username'),
                'email' => $this->input->post('email'),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'created_at' => date('Y-m-d H:i:s')
            );

            $user_id = $this->auth_model->register($data);

            if ($user_id) {
                $this->output
                    ->set_status_header(201)
                    ->set_content_type('application/json')
                    ->set_output(json_encode(array(
                        'status' => 'success',
                        'message' => 'Registration successful',
                        'data' => array('user_id' => $user_id)
                    )));
            } else {
                $this->output
                    ->set_status_header(500)
                    ->set_content_type('application/json')
                    ->set_output(json_encode(array(
                        'status' => 'error',
                        'message' => 'Registration failed'
                    )));
            }
        }
    }

    // POST /api/auth/logout - User logout
    public function logout_post()
    {
        $this->session->sess_destroy();

        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode(array(
                'status' => 'success',
                'message' => 'Logout successful'
            )));
    }

    // GET /api/auth/me - Get current user info
    public function me_get()
    {
        if (!$this->session->userdata('logged_in')) {
            $this->output
                ->set_status_header(401)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'Not authenticated'
                )));
            return;
        }

        $user = $this->auth_model->get_user_by_id($this->session->userdata('user_id'));

        if ($user) {
            unset($user['password']); // Remove password from response
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'success',
                    'data' => $user
                )));
        } else {
            $this->output
                ->set_status_header(404)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'User not found'
                )));
        }
    }

    // Handle OPTIONS requests for CORS
    public function _remap($method, $params = array())
    {
        if ($this->input->method() === 'options') {
            $this->output
                ->set_status_header(200)
                ->set_header('Access-Control-Allow-Origin: *')
                ->set_header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS')
                ->set_header('Access-Control-Allow-Headers: Content-Type, Authorization');
            return;
        }

        // Set CORS headers for all responses
        $this->output->set_header('Access-Control-Allow-Origin: *');
        $this->output->set_header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        $this->output->set_header('Access-Control-Allow-Headers: Content-Type, Authorization');

        $http_method = strtolower($this->input->method(TRUE));
        $rest_method = $method . '_' . $http_method;

        if (method_exists($this, $rest_method)) {
            call_user_func_array(array($this, $rest_method), $params);
        } elseif (method_exists($this, $method)) {
            call_user_func_array(array($this, $method), $params);
        } else {
            $this->output
                ->set_status_header(404)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'Endpoint not found for HTTP method ' . strtoupper($http_method)
                )));
        }
    }
}
