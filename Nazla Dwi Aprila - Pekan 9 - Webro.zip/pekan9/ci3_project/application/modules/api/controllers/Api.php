<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends MX_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('api_model');
        $this->load->library('form_validation');
        $this->load->helper(array('url', 'form'));
    }

    // GET /api/posts - Get all posts
    public function posts_get()
    {
        $posts = $this->api_model->get_all_posts();
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($posts));
    }

    // GET /api/posts/{id} - Get single post
    public function posts_get_by_id($id)
    {
        $post = $this->api_model->get_post_by_id($id);
        if ($post) {
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($post));
        } else {
            $this->output
                ->set_status_header(404)
                ->set_content_type('application/json')
                ->set_output(json_encode(array('error' => 'Post not found')));
        }
    }

    // POST /api/posts - Create new post
    public function posts_post()
    {
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('author', 'Author', 'required');
        $this->form_validation->set_rules('article', 'Article', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->output
                ->set_status_header(400)
                ->set_content_type('application/json')
                ->set_output(json_encode(array('error' => validation_errors())));
        } else {
            $data = array(
                'title' => $this->input->post('title'),
                'author' => $this->input->post('author'),
                'article' => $this->input->post('article'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            );

            $id = $this->api_model->insert_post($data);
            if ($id) {
                $post = $this->api_model->get_post_by_id($id);
                $this->output
                    ->set_status_header(201)
                    ->set_content_type('application/json')
                    ->set_output(json_encode($post));
            } else {
                $this->output
                    ->set_status_header(500)
                    ->set_content_type('application/json')
                    ->set_output(json_encode(array('error' => 'Failed to create post')));
            }
        }
    }

    // PUT /api/posts/{id} - Update post
    public function posts_put($id)
    {
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data) {
            $this->output
                ->set_status_header(400)
                ->set_content_type('application/json')
                ->set_output(json_encode(array('error' => 'Invalid JSON data')));
            return;
        }

        $update_data = array('updated_at' => date('Y-m-d H:i:s'));
        if (isset($data['title'])) $update_data['title'] = $data['title'];
        if (isset($data['author'])) $update_data['author'] = $data['author'];
        if (isset($data['article'])) $update_data['article'] = $data['article'];

        $result = $this->api_model->update_post($id, $update_data);
        if ($result) {
            $post = $this->api_model->get_post_by_id($id);
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($post));
        } else {
            $this->output
                ->set_status_header(500)
                ->set_content_type('application/json')
                ->set_output(json_encode(array('error' => 'Failed to update post')));
        }
    }

    // DELETE /api/posts/{id} - Delete post
    public function posts_delete($id)
    {
        $result = $this->api_model->delete_post($id);
        if ($result) {
            $this->output
                ->set_status_header(204);
        } else {
            $this->output
                ->set_status_header(500)
                ->set_content_type('application/json')
                ->set_output(json_encode(array('error' => 'Failed to delete post')));
        }
    }

    // Handle OPTIONS requests for CORS
    public function _remap($method, $params = array())
    {
        if ($this->input->method() === 'options') {
            $this->output
                ->set_status_header(200)
                ->set_header('Access-Control-Allow-Origin: *')
                ->set_header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS')
                ->set_header('Access-Control-Allow-Headers: Content-Type, Authorization');
            return;
        }

        // Set CORS headers for all responses
        $this->output->set_header('Access-Control-Allow-Origin: *');
        $this->output->set_header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        $this->output->set_header('Access-Control-Allow-Headers: Content-Type, Authorization');

        $http_method = strtolower($this->input->method(TRUE));
        $rest_method = $method . '_' . $http_method;

        if (method_exists($this, $rest_method)) {
            call_user_func_array(array($this, $rest_method), $params);
        } elseif (method_exists($this, $method)) {
            call_user_func_array(array($this, $method), $params);
        } else {
            $this->output
                ->set_status_header(404)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'Endpoint not found for HTTP method ' . strtoupper($http_method)
                )));
        }
    }
}
