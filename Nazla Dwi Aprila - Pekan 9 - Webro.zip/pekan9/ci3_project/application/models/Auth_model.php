<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model {

    private $table = 'users';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function login($username, $password)
    {
        $this->db->where('username', $username);
        $query = $this->db->get($this->table);
        $user = $query->row_array();

        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }

        return FALSE;
    }

    public function register($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function get_user_by_id($id)
    {
        $query = $this->db->get_where($this->table, array('id' => $id));
        return $query->row_array();
    }

    public function get_user_by_username($username)
    {
        $query = $this->db->get_where($this->table, array('username' => $username));
        return $query->row_array();
    }

    public function get_user_by_email($email)
    {
        $query = $this->db->get_where($this->table, array('email' => $email));
        return $query->row_array();
    }
}