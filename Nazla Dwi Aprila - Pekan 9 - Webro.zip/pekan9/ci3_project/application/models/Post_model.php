<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post_model extends CI_Model {
    private $table = 'posts';

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_all() {
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function get_by_id($id) {
        $query = $this->db->get_where($this->table, array('id' => $id));
        return $query->row();
    }

    public function insert($data) {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update($this->table, $data);
    }

    public function delete($id) {
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
    }

    // API specific methods
    public function get_all_posts()
    {
        $this->db->select('posts.*, users.username as author_name');
        $this->db->join('users', 'users.id = posts.user_id', 'left');
        $query = $this->db->get($this->table);
        $posts = $query->result_array();

        foreach ($posts as &$post) {
            if ($post['image']) {
                $imagePath = str_replace('posts/', '', $post['image']);
                $post['image_url'] = base_url('uploads/posts/' . $imagePath);
            } else {
                $post['image_url'] = null;
            }
        }

        return $posts;
    }

    public function get_post_by_id($id)
    {
        $this->db->select('posts.*, users.username as author_name');
        $this->db->join('users', 'users.id = posts.user_id', 'left');
        $query = $this->db->get_where($this->table, array('posts.id' => $id));
        $post = $query->row_array();

        if ($post && $post['image']) {
            $imagePath = str_replace('posts/', '', $post['image']);
            $post['image_url'] = base_url('uploads/posts/' . $imagePath);
        }

        return $post;
    }

    public function get_posts_by_user($user_id)
    {
        $this->db->select('posts.*, users.username as author_name');
        $this->db->join('users', 'users.id = posts.user_id', 'left');
        $this->db->where('posts.user_id', $user_id);
        $query = $this->db->get($this->table);
        $posts = $query->result_array();

        foreach ($posts as &$post) {
            if ($post['image']) {
                $imagePath = str_replace('posts/', '', $post['image']);
                $post['image_url'] = base_url('uploads/posts/' . $imagePath);
            } else {
                $post['image_url'] = null;
            }
        }

        return $posts;
    }

    public function insert_post($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function update_post($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update($this->table, $data);
    }

    public function delete_post($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
    }
}
