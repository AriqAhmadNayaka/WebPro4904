<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Posts extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library('form_validation');
        $this->load->helper(array('url', 'form'));
        $this->load->library('session');
    }

    public function _remap($method, $params = array())
    {
        // Handle OPTIONS request for CORS
        if ($this->input->method() === 'options') {
            $this->output
                ->set_status_header(200)
                ->set_header('Access-Control-Allow-Origin: *')
                ->set_header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS')
                ->set_header('Access-Control-Allow-Headers: Content-Type, Authorization')
                ->set_content_type('application/json')
                ->set_output(json_encode(array('status' => 'ok')));
            return;
        }

        // Set CORS headers for all requests
        $this->output->set_header('Access-Control-Allow-Origin: *');
        $this->output->set_header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        $this->output->set_header('Access-Control-Allow-Headers: Content-Type, Authorization');

        if (method_exists($this, $method)) {
            call_user_func_array(array($this, $method), $params);
        } else {
            $this->output
                ->set_status_header(404)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'Method not found'
                )));
        }
    }

    // TEST - GET /api/test
    public function test()
    {
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode(['status' => 'success', 'message' => 'Test method works']));
    }

    // GET ALL POSTS - GET /api/posts
    // CREATE POST - POST /api/posts
    // GET SINGLE POST - GET /api/posts/{id}
    // UPDATE POST - PUT /api/posts/{id}
    // DELETE POST - DELETE /api/posts/{id}
    public function posts($id = null)
    {
        $this->load->model('Post_model');

        // Jika ada $id, berarti operasi pada single post
        if ($id) {
            $post = $this->Post_model->get_post_by_id($id);
            if (!$post) {
                $this->output
                    ->set_status_header(404)
                    ->set_content_type('application/json')
                    ->set_output(json_encode([
                        'status' => 'error',
                        'message' => 'Post not found'
                    ]));
                return;
            }

            // GET single post
            if ($this->input->method() === 'get') {
                $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode([
                        'status' => 'success',
                        'data' => $post
                    ]));
                return;
            }

            // PUT update post
            if ($this->input->method() === 'put') {
                if (!$this->session->userdata('logged_in')) {
                    $this->output
                        ->set_status_header(401)
                        ->set_content_type('application/json')
                        ->set_output(json_encode([
                            'status' => 'error',
                            'message' => 'Authentication required'
                        ]));
                    return;
                }

                if ($post['user_id'] != $this->session->userdata('user_id')) {
                    $this->output
                        ->set_status_header(403)
                        ->set_content_type('application/json')
                        ->set_output(json_encode([
                            'status' => 'error',
                            'message' => 'Access denied'
                        ]));
                    return;
                }

                $raw_data = file_get_contents('php://input');
                $data = json_decode($raw_data, true);

                if (!$data) {
                    $this->output
                        ->set_status_header(400)
                        ->set_content_type('application/json')
                        ->set_output(json_encode([
                            'status' => 'error',
                            'message' => 'Invalid JSON data'
                        ]));
                    return;
                }

                $update_data = ['updated_at' => date('Y-m-d H:i:s')];
                if (isset($data['title'])) $update_data['title'] = $data['title'];
                if (isset($data['author'])) $update_data['author'] = $data['author'];
                if (isset($data['article'])) $update_data['article'] = $data['article'];

                $result = $this->Post_model->update_post($id, $update_data);

                if ($result) {
                    $updated_post = $this->Post_model->get_post_by_id($id);
                    $this->output
                        ->set_content_type('application/json')
                        ->set_output(json_encode([
                            'status' => 'success',
                            'message' => 'Post updated successfully',
                            'data' => $updated_post
                        ]));
                } else {
                    $this->output
                        ->set_status_header(500)
                        ->set_content_type('application/json')
                        ->set_output(json_encode([
                            'status' => 'error',
                            'message' => 'Failed to update post'
                        ]));
                }
                return;
            }

            // DELETE post
            if ($this->input->method() === 'delete') {
                if (!$this->session->userdata('logged_in')) {
                    $this->output
                        ->set_status_header(401)
                        ->set_content_type('application/json')
                        ->set_output(json_encode([
                            'status' => 'error',
                            'message' => 'Authentication required'
                        ]));
                    return;
                }

                if ($post['user_id'] != $this->session->userdata('user_id')) {
                    $this->output
                        ->set_status_header(403)
                        ->set_content_type('application/json')
                        ->set_output(json_encode([
                            'status' => 'error',
                            'message' => 'Access denied'
                        ]));
                    return;
                }

                if ($post['image']) {
                    $image_path = './uploads/' . $post['image'];
                    if (file_exists($image_path)) {
                        unlink($image_path);
                    }
                }

                $result = $this->Post_model->delete_post($id);

                if ($result) {
                    $this->output
                        ->set_status_header(204)
                        ->set_content_type('application/json')
                        ->set_output(json_encode([
                            'status' => 'success',
                            'message' => 'Post deleted successfully'
                        ]));
                } else {
                    $this->output
                        ->set_status_header(500)
                        ->set_content_type('application/json')
                        ->set_output(json_encode([
                            'status' => 'error',
                            'message' => 'Failed to delete post'
                        ]));
                }
                return;
            }

            // Other methods
            $this->output
                ->set_status_header(405)
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'status' => 'error',
                    'message' => 'Method not supported'
                ]));
            return;
        }

        // Jika tidak ada $id, berarti operasi pada all posts

        // GET all posts
        if ($this->input->method() === 'get') {
            $posts = $this->Post_model->get_all_posts();
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode([
                    'status' => 'success',
                    'data' => $posts
                ]));
            return;
        }

        // POST create post
        if ($this->input->method() === 'post') {
            if (!$this->session->userdata('logged_in')) {
                $this->output
                    ->set_status_header(401)
                    ->set_content_type('application/json')
                    ->set_output(json_encode([
                        'status' => 'error',
                        'message' => 'Authentication required'
                    ]));
                return;
            }

            $title = $this->input->post('title');
            $author = $this->input->post('author');
            $article = $this->input->post('article');

            if (!$title || !$author || !$article) {
                $this->output
                    ->set_status_header(400)
                    ->set_content_type('application/json')
                    ->set_output(json_encode([
                        'status' => 'error',
                        'message' => 'Title, author, and article required'
                    ]));
                return;
            }

            $data = [
                'title' => $title,
                'author' => $author,
                'article' => $article,
                'user_id' => $this->session->userdata('user_id'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];

            if (!empty($_FILES['image']['name'])) {
                $upload_result = $this->_upload_image();
                if ($upload_result['status']) {
                    $data['image'] = 'posts/' . $upload_result['file_name'];
                } else {
                    $this->output
                        ->set_status_header(400)
                        ->set_content_type('application/json')
                        ->set_output(json_encode([
                            'status' => 'error',
                            'message' => $upload_result['error']
                        ]));
                    return;
                }
            }

            $post_id = $this->Post_model->insert_post($data);

            if ($post_id) {
                $post = $this->Post_model->get_post_by_id($post_id);
                $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode([
                        'status' => 'success',
                        'message' => 'Post created successfully',
                        'data' => $post
                    ]));
            } else {
                $this->output
                    ->set_status_header(500)
                    ->set_content_type('application/json')
                    ->set_output(json_encode([
                        'status' => 'error',
                        'message' => 'Failed to create post'
                    ]));
            }
            return;
        }

        // Other methods
        $this->output
            ->set_status_header(405)
            ->set_content_type('application/json')
            ->set_output(json_encode([
                'status' => 'error',
                'message' => 'Method not supported'
            ]));
    }

    private function _upload_image()
    {
        $upload_path = './uploads/posts/';

        if (!is_dir($upload_path)) {
            mkdir($upload_path, 0777, true);
        }

        $original_name = $_FILES['image']['name'];
        $sanitized_name = preg_replace('/[^A-Za-z0-9._-]/', '_', $original_name);
        $file_name = time() . '_' . $sanitized_name;

        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size'] = 2048;
        $config['file_name'] = $file_name;
        $config['overwrite'] = FALSE;

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('image')) {
            $upload_data = $this->upload->data();
            return array(
                'status' => TRUE,
                'file_name' => $upload_data['file_name']
            );
        }

        return array(
            'status' => FALSE,
            'error' => $this->upload->display_errors('', '')
        );
    }
}