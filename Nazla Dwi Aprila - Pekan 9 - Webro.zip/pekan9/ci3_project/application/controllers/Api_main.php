<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_main extends MX_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('api/api_model');
        $this->load->model('api/auth_model');
        $this->load->model('api/post_model');
        $this->load->library('form_validation');
        $this->load->helper(array('url', 'form'));
        $this->load->library('session');
    }

    // Auth endpoints
    public function auth($method)
    {
        $this->load->module('api/auth');
        $this->auth->$method();
    }

    // Post endpoints
    public function post($method)
    {
        $this->load->module('api/post');
        $this->post->$method();
    }

    // Legacy posts endpoints
    public function posts($method = 'get')
    {
        $this->load->module('api/api');
        $this->api->$method();
    }

    // Catch all for API
    public function _remap($method, $params = array())
    {
        // Handle auth routes
        if ($method == 'auth' && !empty($params)) {
            $this->auth($params[0]);
            return;
        }

        // Handle post routes
        if ($method == 'post' && !empty($params)) {
            $this->post($params[0]);
            return;
        }

        // Handle legacy posts routes
        if ($method == 'posts') {
            $this->posts(isset($params[0]) ? $params[0] : 'get');
            return;
        }

        // Default response
        $this->output
            ->set_status_header(404)
            ->set_content_type('application/json')
            ->set_output(json_encode(array('error' => 'Endpoint not found')));
    }
}