<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function index()
    {
        $module_api_path = APPPATH . 'modules/api/';

        echo "<h2>CodeIgniter Test</h2>";
        echo "Database connected: " . ($this->db->conn_id ? "<span style='color:green'>&#10003; Yes</span>" : "<span style='color:red'>&#10007; No</span>") . "<br>";
        echo "Database name: " . $this->db->database . "<br>";

        echo "Posts table exists: " . ($this->db->table_exists('posts') ? "<span style='color:green'>&#10003; Yes</span>" : "<span style='color:red'>&#10007; No</span>") . "<br>";
        echo "Users table exists: " . ($this->db->table_exists('users') ? "<span style='color:green'>&#10003; Yes</span>" : "<span style='color:red'>&#10007; No</span>") . "<br>";

        echo "<br><h3>HMVC Setup</h3>";
        echo "MX Loader loaded: " . (class_exists('MX_Loader') ? "<span style='color:green'>&#10003; Yes</span>" : "<span style='color:red'>&#10007; No</span>") . "<br>";
        echo "MX Router loaded: " . (class_exists('MX_Router') ? "<span style='color:green'>&#10003; Yes</span>" : "<span style='color:red'>&#10007; No</span>") . "<br>";
        echo "API module exists: " . (is_dir($module_api_path) ? "<span style='color:green'>&#10003; Yes</span>" : "<span style='color:red'>&#10007; No</span>") . "<br>";

        echo "<br><h3>API Setup</h3>";
        echo "HMVC Auth controller exists: " . (file_exists($module_api_path . 'controllers/Auth.php') ? "<span style='color:green'>&#10003; Yes</span>" : "<span style='color:red'>&#10007; No</span>") . "<br>";
        echo "HMVC Post controller exists: " . (file_exists($module_api_path . 'controllers/Post.php') ? "<span style='color:green'>&#10003; Yes</span>" : "<span style='color:red'>&#10007; No</span>") . "<br>";
        echo "HMVC Auth model exists: " . (file_exists($module_api_path . 'models/Auth_model.php') ? "<span style='color:green'>&#10003; Yes</span>" : "<span style='color:red'>&#10007; No</span>") . "<br>";
        echo "HMVC Post model exists: " . (file_exists($module_api_path . 'models/Post_model.php') ? "<span style='color:green'>&#10003; Yes</span>" : "<span style='color:red'>&#10007; No</span>") . "<br>";

        echo "<br><h3>API Test Endpoints</h3>";
        echo "<a href='" . base_url('api/post') . "' target='_blank'>GET /api/post</a> - Get all posts<br>";
        echo "<a href='" . base_url('api/post/my') . "' target='_blank'>GET /api/post/my</a> - Get posts by logged in user<br>";
        echo "<a href='" . base_url('test/api') . "' target='_blank'>GET /test/api</a> - Simple API test<br>";

        echo "<br><h3>Next Steps:</h3>";
        echo "<ol>";
        echo "<li>If all checks show check marks, test GET /api/post terlebih dahulu</li>";
        echo "<li>Use Postman to test: POST /api/auth/register</li>";
        echo "<li>Lanjutkan dengan POST /api/auth/login lalu GET /api/post/my</li>";
        echo "<li>See POSTMAN_TESTING_GUIDE.md for detailed instructions</li>";
        echo "</ol>";
    }

    public function api_test()
    {
        header('Content-Type: application/json');
        echo json_encode(array(
            'status' => 'success',
            'message' => 'API is working correctly',
            'timestamp' => date('Y-m-d H:i:s'),
            'base_url' => base_url()
        ));
    }

    public function register_test()
    {
        echo "Register Test<br>";
        echo "URL: " . base_url('api/auth/register') . "<br>";
        echo "Method: POST<br>";
        echo "Body: username, email, password, password_confirm<br>";
    }

    public function login_test()
    {
        echo "Login Test<br>";
        echo "URL: " . base_url('api/auth/login') . "<br>";
        echo "Method: POST<br>";
        echo "Body: username, password<br>";
    }
}
