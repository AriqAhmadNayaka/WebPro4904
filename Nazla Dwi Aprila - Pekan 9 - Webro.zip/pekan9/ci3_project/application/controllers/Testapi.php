<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Testapi extends CI_Controller {

    public function index()
    {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'success', 'message' => 'Testapi works']);
    }
}