<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library('form_validation');
        $this->load->helper(array('url', 'form'));
        $this->load->library('session');
        header('Content-Type: application/json; charset=utf-8');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
    }

    // TEST - GET /api/test
    public function test()
    {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'success', 'message' => 'Test method works']);
    }

    // REGISTER - POST /api/register
    public function register()
    {
        $this->load->model('Auth_model');

        $input = $this->_get_request_data();
        $username = isset($input['username']) ? $input['username'] : $this->input->post('username', TRUE);
        $email = isset($input['email']) ? $input['email'] : $this->input->post('email', TRUE);
        $password = isset($input['password']) ? $input['password'] : $this->input->post('password');
        $password_confirm = isset($input['password_confirm']) ? $input['password_confirm'] : $this->input->post('password_confirm');

        // Validasi
        if (!$username || !$email || !$password || !$password_confirm) {
            echo json_encode([
                'status' => 'error',
                'message' => 'All fields required'
            ]);
            return;
        }

        if ($password !== $password_confirm) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Passwords do not match'
            ]);
            return;
        }

        if (strlen($password) < 6) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Password must be at least 6 characters'
            ]);
            return;
        }

        // Cek username sudah ada
        if ($this->Auth_model->get_user_by_username($username)) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Username already exists'
            ]);
            return;
        }

        // Cek email sudah ada
        if ($this->Auth_model->get_user_by_email($email)) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Email already exists'
            ]);
            return;
        }

        // Insert user
        $data = [
            'username' => $username,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'created_at' => date('Y-m-d H:i:s')
        ];

        $user_id = $this->Auth_model->register($data);

        if ($user_id) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Registration successful',
                'user_id' => $user_id
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Registration failed'
            ]);
        }
    }

    // LOGIN - POST /api/login
    public function login()
    {
        $this->load->model('Auth_model');

        $input = $this->_get_request_data();
        $username = isset($input['username']) ? $input['username'] : $this->input->post('username', TRUE);
        $password = isset($input['password']) ? $input['password'] : $this->input->post('password');

        if (!$username || !$password) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Username and password required'
            ]);
            return;
        }

        $user = $this->Auth_model->login($username, $password);

        if ($user) {
            $this->session->set_userdata([
                'user_id' => $user['id'],
                'username' => $user['username'],
                'logged_in' => TRUE
            ]);

            echo json_encode([
                'status' => 'success',
                'message' => 'Login successful',
                'user_id' => $user['id'],
                'username' => $user['username']
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Invalid username or password'
            ]);
        }
    }

    // LOGOUT - POST /api/logout
    public function logout()
    {
        $this->session->sess_destroy();
        echo json_encode([
            'status' => 'success',
            'message' => 'Logout successful'
        ]);
    }

    // GET CURRENT USER - GET /api/me
    public function me()
    {
        $this->load->model('Auth_model');

        if (!$this->session->userdata('logged_in')) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Not authenticated'
            ]);
            return;
        }

        $user = $this->Auth_model->get_user_by_id($this->session->userdata('user_id'));

        if ($user) {
            unset($user['password']);
            echo json_encode([
                'status' => 'success',
                'data' => $user
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'User not found'
            ]);
        }
    }

    // GET ALL POSTS - GET /api/posts
    // CREATE POST - POST /api/posts
    // GET SINGLE POST - GET /api/posts/{id}
    // UPDATE POST - PUT /api/posts/{id}
    // DELETE POST - DELETE /api/posts/{id}
    public function posts($id = null)
    {
        $this->load->model('Post_model');
        if ($id === null) {
            $id = $this->input->get('id');
        }

        // Jika ada $id, berarti operasi pada single post
        if ($id) {
            $post = $this->Post_model->get_post_by_id($id);
            if (!$post) {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Post not found'
                ]);
                return;
            }

            // GET single post
            if ($this->input->method() === 'get') {
                echo json_encode([
                    'status' => 'success',
                    'data' => $post
                ]);
                return;
            }

            // PUT update post
            if ($this->input->method() === 'put') {
                if (!$this->session->userdata('logged_in')) {
                    echo json_encode([
                        'status' => 'error',
                        'message' => 'Authentication required'
                    ]);
                    return;
                }

                if ($post['user_id'] != $this->session->userdata('user_id')) {
                    echo json_encode([
                        'status' => 'error',
                        'message' => 'Access denied'
                    ]);
                    return;
                }

                $raw_data = file_get_contents('php://input');
                $data = json_decode($raw_data, true);

                if (!$data) {
                    echo json_encode([
                        'status' => 'error',
                        'message' => 'Invalid JSON data'
                    ]);
                    return;
                }

                $update_data = ['updated_at' => date('Y-m-d H:i:s')];
                if (isset($data['title'])) $update_data['title'] = $data['title'];
                if (isset($data['author'])) $update_data['author'] = $data['author'];
                if (isset($data['article'])) $update_data['article'] = $data['article'];

                $result = $this->Post_model->update_post($id, $update_data);

                if ($result) {
                    $updated_post = $this->Post_model->get_post_by_id($id);
                    echo json_encode([
                        'status' => 'success',
                        'message' => 'Post updated successfully',
                        'data' => $updated_post
                    ]);
                } else {
                    echo json_encode([
                        'status' => 'error',
                        'message' => 'Failed to update post'
                    ]);
                }
                return;
            }

            // DELETE post
            if ($this->input->method() === 'delete') {
                if (!$this->session->userdata('logged_in')) {
                    echo json_encode([
                        'status' => 'error',
                        'message' => 'Authentication required'
                    ]);
                    return;
                }

                if ($post['user_id'] != $this->session->userdata('user_id')) {
                    echo json_encode([
                        'status' => 'error',
                        'message' => 'Access denied'
                    ]);
                    return;
                }

                if ($post['image']) {
                    $image_path = './uploads/' . $post['image'];
                    if (file_exists($image_path)) {
                        unlink($image_path);
                    }
                }

                $result = $this->Post_model->delete_post($id);

                if ($result) {
                    echo json_encode([
                        'status' => 'success',
                        'message' => 'Post deleted successfully'
                    ]);
                } else {
                    echo json_encode([
                        'status' => 'error',
                        'message' => 'Failed to delete post'
                    ]);
                }
                return;
            }

            // Other methods
            echo json_encode([
                'status' => 'error',
                'message' => 'Method not supported'
            ]);
            return;
        }

        // Jika tidak ada $id, berarti operasi pada all posts

        // GET all posts
        if ($this->input->method() === 'get') {
            $posts = $this->Post_model->get_all_posts();
            echo json_encode([
                'status' => 'success',
                'data' => $posts
            ]);
            return;
        }

        // POST create post
        if ($this->input->method() === 'post') {
            if (!$this->session->userdata('logged_in')) {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Authentication required'
                ]);
                return;
            }

            $input = $this->_get_request_data();
            $title = isset($input['title']) ? $input['title'] : $this->input->post('title', TRUE);
            $author = isset($input['author']) ? $input['author'] : $this->input->post('author', TRUE);
            $article = isset($input['article']) ? $input['article'] : $this->input->post('article', TRUE);

            if (!$title || !$author || !$article) {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Title, author, and article required'
                ]);
                return;
            }

            $data = [
                'title' => $title,
                'author' => $author,
                'article' => $article,
                'user_id' => $this->session->userdata('user_id'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];

            if (!empty($_FILES['image']['name'])) {
                $upload_result = $this->_upload_image();
                if ($upload_result['status']) {
                    $data['image'] = 'posts/' . $upload_result['file_name'];
                } else {
                    echo json_encode([
                        'status' => 'error',
                        'message' => $upload_result['error']
                    ]);
                    return;
                }
            }

            $post_id = $this->Post_model->insert_post($data);

            if ($post_id) {
                $post = $this->Post_model->get_post_by_id($post_id);
                echo json_encode([
                    'status' => 'success',
                    'message' => 'Post created successfully',
                    'data' => $post
                ]);
            } else {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Failed to create post'
                ]);
            }
            return;
        }

        // Other methods
        echo json_encode([
            'status' => 'error',
            'message' => 'Method not supported'
        ]);
    }

    // GET USER POSTS - GET /api/my-posts
    public function my_posts()
    {
        $this->load->model('Post_model');

        if (!$this->session->userdata('logged_in')) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Authentication required'
            ]);
            return;
        }

        $posts = $this->Post_model->get_posts_by_user($this->session->userdata('user_id'));

        echo json_encode([
            'status' => 'success',
            'data' => $posts
        ]);
    }

    private function _upload_image()
    {
        $upload_path = './uploads/posts/';

        if (!is_dir($upload_path)) {
            mkdir($upload_path, 0777, true);
        }

        $original_name = $_FILES['image']['name'];
        $sanitized_name = preg_replace('/[^A-Za-z0-9._-]/', '_', $original_name);
        $file_name = time() . '_' . $sanitized_name;

        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size'] = 2048;
        $config['file_name'] = $file_name;
        $config['overwrite'] = FALSE;

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('image')) {
            $upload_data = $this->upload->data();
            return array(
                'status' => TRUE,
                'file_name' => $upload_data['file_name']
            );
        }

        return array(
            'status' => FALSE,
            'error' => $this->upload->display_errors('', '')
        );
    }

    private function _get_request_data()
    {
        $content_type = $this->input->server('CONTENT_TYPE');
        if ($content_type && stripos($content_type, 'application/json') !== FALSE) {
            $raw = trim(file_get_contents('php://input'));
            if ($raw === '') {
                return array();
            }

            $decoded = json_decode($raw, TRUE);
            return is_array($decoded) ? $decoded : array();
        }

        return $this->input->post(NULL, TRUE) ?: array();
    }
}
