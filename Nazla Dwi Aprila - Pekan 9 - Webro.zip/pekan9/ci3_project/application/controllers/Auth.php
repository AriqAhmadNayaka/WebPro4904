<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('Auth_model');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->helper(array('url', 'form'));
    }

    public function register()
    {
        // Handle OPTIONS request for CORS
        if ($this->input->method() === 'options') {
            $this->output
                ->set_status_header(200)
                ->set_content_type('application/json')
                ->set_output(json_encode(array('status' => 'ok')));
            return;
        }

        if ($this->input->method() !== 'post') {
            $this->output
                ->set_status_header(405)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'Method not allowed. Use POST.'
                )));
            return;
        }

        $input = $this->_get_request_data();
        if (!empty($input)) {
            $_POST = array_merge($_POST, $input);
        }

        $this->form_validation->set_rules('username', 'Username', 'required|is_unique[users.username]');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('password_confirm', 'Password Confirmation', 'required|matches[password]');

        if ($this->form_validation->run() === FALSE) {
            $this->output
                ->set_status_header(400)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => strip_tags(validation_errors())
                )));
            return;
        }

        $data = array(
            'username' => $this->input->post('username', TRUE),
            'email' => $this->input->post('email', TRUE),
            'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
            'created_at' => date('Y-m-d H:i:s')
        );

        $user_id = $this->Auth_model->register($data);

        if ($user_id) {
            $this->output
                ->set_status_header(201)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'success',
                    'message' => 'Registration successful',
                    'data' => array('user_id' => $user_id)
                )));
        } else {
            $this->output
                ->set_status_header(500)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'Registration failed'
                )));
        }
    }

    public function login()
    {
        // Handle OPTIONS request for CORS
        if ($this->input->method() === 'options') {
            $this->output
                ->set_status_header(200)
                ->set_content_type('application/json')
                ->set_output(json_encode(array('status' => 'ok')));
            return;
        }

        if ($this->input->method() !== 'post') {
            $this->output
                ->set_status_header(405)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'Method not allowed. Use POST.'
                )));
            return;
        }

        $input = $this->_get_request_data();
        if (!empty($input)) {
            $_POST = array_merge($_POST, $input);
        }

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->output
                ->set_status_header(400)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => strip_tags(validation_errors())
                )));
            return;
        }

        $username = $this->input->post('username', TRUE);
        $password = $this->input->post('password');

        $user = $this->Auth_model->login($username, $password);

        if ($user) {
            $this->session->set_userdata(array(
                'user_id' => $user['id'],
                'username' => $user['username'],
                'logged_in' => TRUE
            ));

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'success',
                    'message' => 'Login successful',
                    'data' => array(
                        'user_id' => $user['id'],
                        'username' => $user['username']
                    )
                )));
        } else {
            $this->output
                ->set_status_header(401)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'Invalid username or password'
                )));
        }
    }

    public function logout()
    {
        // Handle OPTIONS request for CORS
        if ($this->input->method() === 'options') {
            $this->output
                ->set_status_header(200)
                ->set_content_type('application/json')
                ->set_output(json_encode(array('status' => 'ok')));
            return;
        }

        if ($this->input->method() !== 'post') {
            $this->output
                ->set_status_header(405)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'Method not allowed. Use POST.'
                )));
            return;
        }

        $this->session->sess_destroy();
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode(array(
                'status' => 'success',
                'message' => 'Logout successful'
            )));
    }

    public function me()
    {
        // Handle OPTIONS request for CORS
        if ($this->input->method() === 'options') {
            $this->output
                ->set_status_header(200)
                ->set_content_type('application/json')
                ->set_output(json_encode(array('status' => 'ok')));
            return;
        }

        if ($this->input->method() !== 'get') {
            $this->output
                ->set_status_header(405)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'Method not allowed. Use GET.'
                )));
            return;
        }

        if (!$this->session->userdata('logged_in')) {
            $this->output
                ->set_status_header(401)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'Not authenticated'
                )));
            return;
        }

        $user = $this->Auth_model->get_user_by_id($this->session->userdata('user_id'));
        if ($user) {
            unset($user['password']);
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'success',
                    'data' => $user
                )));
        } else {
            $this->output
                ->set_status_header(404)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'status' => 'error',
                    'message' => 'User not found'
                )));
        }
    }

    public function _remap($method, $params = array())
    {
        if ($this->input->method() === 'options') {
            $this->output
                ->set_status_header(200)
                ->set_header('Access-Control-Allow-Origin: *')
                ->set_header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS')
                ->set_header('Access-Control-Allow-Headers: Content-Type, Authorization');
            return;
        }

        $this->output->set_header('Access-Control-Allow-Origin: *');
        $this->output->set_header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        $this->output->set_header('Access-Control-Allow-Headers: Content-Type, Authorization');

        if (method_exists($this, $method)) {
            call_user_func_array(array($this, $method), $params);
        } else {
            $this->output
                ->set_status_header(404)
                ->set_content_type('application/json')
                ->set_output(json_encode(array(
                    'error' => 'Method not found'
                )));
        }
    }

    private function _get_request_data()
    {
        $content_type = $this->input->server('CONTENT_TYPE');
        if ($content_type && stripos($content_type, 'application/json') !== FALSE) {
            $raw = trim(file_get_contents('php://input'));
            if ($raw === '') {
                return array();
            }

            $decoded = json_decode($raw, TRUE);
            return is_array($decoded) ? $decoded : array();
        }

        return $this->input->post(NULL, TRUE) ?: array();
    }
}
