<?php $this->load->view('posts/header'); ?>

<div class="mb-20" style="display: flex; justify-content: space-between; align-items: center;">
    <h2>All Posts</h2>
    <a href="<?php echo base_url('posts/create'); ?>" class="btn btn-primary">Create New Post</a>
</div>

<div class="card" style="padding: 0;">
    <table>
        <thead>
            <tr>
                <th style="width: 80px;">ID</th>
                <th>Title</th>
                <th>Author</th>
                <th>Article</th>
                <th style="width: 180px;">Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($posts)): ?>
                <?php foreach ($posts as $post): ?>
                    <tr>
                        <td><?php echo (int) $post->id; ?></td>
                        <td><?php echo htmlspecialchars($post->title); ?></td>
                        <td><?php echo htmlspecialchars($post->author); ?></td>
                        <td class="article-preview"><?php echo htmlspecialchars($post->article); ?></td>
                        <td><?php echo htmlspecialchars($post->created_at); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="text-center">Belum ada data post di database.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $this->load->view('posts/footer'); ?>
