    </div>

    <footer>
        <div class="container">
            <p>Posts Management</p>
        </div>
    </footer>
</body>
</html>
