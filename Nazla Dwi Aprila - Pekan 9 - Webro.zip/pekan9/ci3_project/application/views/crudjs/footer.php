    </div>

    <footer>
        <div class="container">
            <p>CRUD with AJAX - CodeIgniter</p>
        </div>
    </footer>
</body>
</html>