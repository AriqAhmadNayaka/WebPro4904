<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .table-responsive {
            max-height: 400px;
            overflow-y: auto;
        }
        .image-preview {
            max-width: 100px;
            max-height: 100px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <?php
        $crud_index_url = base_url('index.php?c=crudjs&m=index');
        $crud_get_all_url = base_url('index.php?c=crudjs&m=get_all');
        $crud_get_record_url = base_url('index.php?c=crudjs&m=get_record&id=');
        $crud_store_url = base_url('index.php?c=crudjs&m=store');
        $crud_update_url = base_url('index.php?c=crudjs&m=update&id=');
        $crud_delete_url = base_url('index.php?c=crudjs&m=delete&id=');
    ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-12">
                <h1 class="mb-4"><?php echo $title; ?></h1>

                <!-- Add New Record Button -->
                <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#recordModal" onclick="openModal()">
                    <i class="fas fa-plus"></i> Add New Record
                </button>

                <!-- Records Table -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Records</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="recordsTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>Article</th>
                                        <th>Image</th>
                                        <th>Created At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="recordsBody">
                                    <!-- Records will be loaded here via AJAX -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Add/Edit Record -->
    <div class="modal fade" id="recordModal" tabindex="-1" aria-labelledby="recordModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="recordModalLabel">Add New Record</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="recordForm" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" id="recordId" name="record_id">

                        <div class="mb-3">
                            <label for="title" class="form-label">Title *</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                        </div>

                        <div class="mb-3">
                            <label for="author" class="form-label">Author *</label>
                            <input type="text" class="form-control" id="author" name="author" required>
                        </div>

                        <div class="mb-3">
                            <label for="article" class="form-label">Article *</label>
                            <textarea class="form-control" id="article" name="article" rows="4" required></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="image" class="form-label">Image</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*">
                            <div id="currentImage" class="mt-2"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="submitBtn">
                            <i class="fas fa-save"></i> Save
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        let recordModalInstance = null;

        // Load records on page load
        $(document).ready(function() {
            const modalElement = document.getElementById('recordModal');
            recordModalInstance = bootstrap.Modal.getOrCreateInstance(modalElement);
            loadRecords();
        });

        // Load all records
        function loadRecords() {
            $.ajax({
                url: '<?php echo $crud_get_all_url; ?>',
                type: 'GET',
                cache: false,
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        displayRecords(response.data);
                    } else {
                        alert('Error loading records: ' + response.message);
                    }
                },
                error: function() {
                    alert('Error loading records');
                }
            });
        }

        // Display records in table
        function displayRecords(records) {
            let html = '';
            records.forEach(function(record) {
                html += `
                    <tr>
                        <td>${record.id}</td>
                        <td>${record.title}</td>
                        <td>${record.author}</td>
                        <td>${record.article.substring(0, 50)}...</td>
                        <td>
                            ${record.image_url ? `<img src="${record.image_url}" class="image-preview" alt="Image">` : 'No image'}
                        </td>
                        <td>${record.created_at}</td>
                        <td>
                            <button class="btn btn-sm btn-warning" onclick="editRecord(${record.id})">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="deleteRecord(${record.id})">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </td>
                    </tr>
                `;
            });
            $('#recordsBody').html(html);
        }

        // Open modal for adding new record
        function openModal(recordId = null) {
            $('#recordForm')[0].reset();
            $('#recordId').val('');
            $('#currentImage').html('');
            $('#recordModalLabel').text(recordId ? 'Edit Record' : 'Add New Record');
            $('#submitBtn').html(recordId ? '<i class="fas fa-save"></i> Update' : '<i class="fas fa-save"></i> Save');

            if (recordId) {
                // Load record data for editing
                $.ajax({
                    url: '<?php echo $crud_get_record_url; ?>' + recordId,
                    type: 'GET',
                    cache: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            const record = response.data;
                            $('#recordId').val(record.id);
                            $('#title').val(record.title);
                            $('#author').val(record.author);
                            $('#article').val(record.article);
                            if (record.image_url) {
                                $('#currentImage').html(`<img src="${record.image_url}" class="image-preview" alt="Current Image"><br><small>Current image will be replaced if you upload a new one.</small>`);
                            }
                        } else {
                            alert('Error loading record: ' + response.message);
                        }
                    },
                    error: function() {
                        alert('Error loading record');
                    }
                });
            }
        }

        // Handle form submission
        $('#recordForm').on('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(this);
            const recordId = $('#recordId').val();
            const url = recordId ? '<?php echo $crud_update_url; ?>' + recordId : '<?php echo $crud_store_url; ?>';
            const method = recordId ? 'POST' : 'POST';

            $.ajax({
                url: url,
                type: method,
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        recordModalInstance.hide();
                        loadRecords();
                        alert(response.message);
                    } else {
                        alert('Error: ' + response.message);
                    }
                },
                error: function() {
                    alert('Error saving record');
                }
            });
        });

        // Edit record
        function editRecord(id) {
            openModal(id);
            recordModalInstance.show();
        }

        // Delete record
        function deleteRecord(id) {
            if (confirm('Are you sure you want to delete this record?')) {
                $.ajax({
                    url: '<?php echo $crud_delete_url; ?>' + id,
                    type: 'POST',
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            loadRecords();
                            alert(response.message);
                        } else {
                            alert('Error: ' + response.message);
                        }
                    },
                    error: function() {
                        alert('Error deleting record');
                    }
                });
            }
        }
    </script>
</body>
</html>
