<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Posts extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Post_model');
        $this->load->helper(array('url', 'form'));
        $this->load->library(array('form_validation', 'upload', 'session'));
    }

    public function index() {
        $data['posts'] = $this->Post_model->get_all();
        $data['title'] = 'All Posts';
        $this->load->view('posts/index', $data);
    }

    public function create() {
        $data['title'] = 'Create New Post';
        $this->load->view('posts/create', $data);
    }

    public function store() {
        $this->form_validation->set_rules('title', 'Title', 'required|max_length[255]');
        $this->form_validation->set_rules('author', 'Author', 'required|max_length[255]');
        $this->form_validation->set_rules('article', 'Article', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('posts/create');
            return;
        }

        $data = array(
            'title' => $this->input->post('title'),
            'author' => $this->input->post('author'),
            'article' => $this->input->post('article'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );

        if (!empty($_FILES['image']['name'])) {
            $upload_result = $this->_upload_image();
            if ($upload_result['status']) {
                $data['image'] = 'posts/' . $upload_result['file_name'];
            } else {
                $this->session->set_flashdata('error', $upload_result['error']);
                redirect('posts/create');
                return;
            }
        }

        $post_id = $this->Post_model->insert($data);
        if ($post_id) {
            $this->session->set_flashdata('success', 'Post created successfully!');
            redirect('posts');
        } else {
            $this->session->set_flashdata('error', 'Failed to create post');
            redirect('posts/create');
        }
    }
    // ... (fungsi show, edit, update, delete menyusul di file)
}