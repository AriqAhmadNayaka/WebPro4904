-- Create users table for authentication
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Modify posts table to support API auth and image upload
ALTER TABLE `posts` ADD COLUMN `user_id` int(11) DEFAULT NULL AFTER `id`;
ALTER TABLE `posts` ADD COLUMN `image` varchar(255) DEFAULT NULL AFTER `article`;

-- Run this constraint statement once. Skip it if the foreign key already exists.
ALTER TABLE `posts`
ADD CONSTRAINT `fk_posts_user_id`
FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL;
