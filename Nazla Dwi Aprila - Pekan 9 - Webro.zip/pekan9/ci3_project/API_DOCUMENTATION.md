# RESTful API Documentation

## Authentication Endpoints

### POST /api/auth/login
Login user
**Body:** `username`, `password`

### POST /api/auth/register
Register new user
**Body:** `username`, `email`, `password`, `password_confirm`

### POST /api/auth/logout
Logout user (requires authentication)

### GET /api/auth/me
Get current user info (requires authentication)

## Post Endpoints

### GET /api/post
Get all posts (public)

### GET /api/post/{id}
Get single post by ID (public)

### POST /api/post
Create new post (requires authentication)
**Body:** `title`, `author`, `article`, `image` (optional)

### PUT /api/post/{id}
Update post (requires authentication, owner only)
**Body:** JSON with fields to update

### DELETE /api/post/{id}
Delete post (requires authentication, owner only)

### GET /api/post/my
Get user's own posts (requires authentication)

## Legacy API (for backward compatibility)

### GET /api/posts
Get all posts

### GET /api/posts/{id}
Get single post

### POST /api/posts
Create post

### PUT /api/posts/{id}
Update post

### DELETE /api/posts/{id}
Delete post

## Usage Notes
- All endpoints return JSON responses
- Authentication uses session-based approach
- CORS headers are set for cross-origin requests
- File uploads are supported for post images (jpg, jpeg, png, max 2MB)