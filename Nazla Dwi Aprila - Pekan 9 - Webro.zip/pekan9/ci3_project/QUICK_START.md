# QUICK START - API Testing

## STEP 1: Persiapan Database
1. Buka phpMyAdmin
2. Pilih database CI3
3. Jalankan query ini:

```sql
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL UNIQUE,
  `email` varchar(255) NOT NULL UNIQUE,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `posts` ADD COLUMN IF NOT EXISTS `user_id` int(11) DEFAULT NULL;
ALTER TABLE `posts` ADD COLUMN IF NOT EXISTS `image` varchar(255) DEFAULT NULL;
```

---

## STEP 2: Cek Setup
Buka browser: `http://localhost/Pemograman%20Web/pekan9/ci3_project/`

Seharusnya muncul:
- ✓ Database connected: Yes
- ✓ Posts table exists: Yes  
- ✓ Users table exists: Yes

Jika tidak, stop dan fix dulu sebelum lanjut.

---

## STEP 3: Buka Postman
1. Download & Install Postman
2. Buat New Request

---

## STEP 4: Register User
**Request 1: Create User**
```
Method  : POST
URL     : http://localhost/Pemograman%20Web/pekan9/ci3_project/api/auth/register
Headers : Content-Type: application/x-www-form-urlencoded

Body:
username=admin
email=admin@test.com
password=admin123
password_confirm=admin123
```

**Expected Result:**
```json
{
  "status": "success",
  "message": "Registration successful",
  "user_id": 1
}
```

---

## STEP 5: Login
**Request 2: Login**
```
Method  : POST
URL     : http://localhost/Pemograman%20Web/pekan9/ci3_project/api/auth/login
Headers : Content-Type: application/x-www-form-urlencoded

Body:
username=admin
password=admin123
```

**Expected Result:**
```json
{
  "status": "success",
  "message": "Login successful",
  "user_id": 1,
  "username": "admin"
}
```

**PENTING:** Copy session cookie dari Postman (cek tab "Cookies")

---

## STEP 6: Test Endpoints (Authenticated)

### Get Current User
```
Method  : GET
URL     : http://localhost/Pemograman%20Web/pekan9/ci3_project/api/auth/me
```

### Get All Posts
```
Method  : GET
URL     : http://localhost/Pemograman%20Web/pekan9/ci3_project/api/post
```

### Create Post
```
Method  : POST
URL     : http://localhost/Pemograman%20Web/pekan9/ci3_project/api/post
Headers : Content-Type: form-data

Body (form-data):
title   : My First Post
author  : Admin
article : This is my first post
```

---

## TROUBLESHOOTING

### Error: {"error":"Method not found"}
- ✓ Cek URL sudah benar
- ✓ Cek Method (POST/GET)  
- ✓ Cek routes.php sudah di-update

### Error: {"status":"error","message":"Registration failed"}
- ✓ Users table mungkin belum di-buat
- ✓ Jalankan SQL query di Step 1 lagi

### Error: {"status":"error","message":"Invalid username or password"}
- ✓ Username atau password salah
- ✓ Pastikan sudah register dulu

### Error: {"status":"error","message":"Authentication required"}
- ✓ Belum login
- ✓ Session cookie tidak dikirim

---

## Files Penting

- `POSTMAN_TESTING_GUIDE.md` - Dokumentasi lengkap semua endpoint
- `application/modules/api/controllers/Auth.php` - Auth controller HMVC
- `application/modules/api/controllers/Post.php` - Post controller HMVC
- `application/modules/api/models/Auth_model.php` - Model auth HMVC
- `application/modules/api/models/Post_model.php` - Model posts HMVC
- `application/config/routes.php` - Routing API

---

**Hubungi jika ada masalah!**
