<?php
// Test register API
$url = 'http://localhost/ci3_project/api/register';
$data = array(
    'username' => 'testuser',
    'email' => 'test@example.com',
    'password' => 'password123',
    'password_confirm' => 'password123'
);

$options = array(
    'http' => array(
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query($data),
    ),
);

$context  = stream_context_create($options);
$result = file_get_contents($url, false, $context);

if ($result === FALSE) {
    echo "Error: Unable to connect\n";
} else {
    echo "Response:\n";
    echo $result;
}
?>