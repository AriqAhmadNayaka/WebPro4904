<?php
// Test GET register API
$url = 'http://localhost/ci3_project/api/register';

$result = file_get_contents($url);

if ($result === FALSE) {
    echo "Error: Unable to connect\n";
} else {
    echo "Response:\n";
    echo $result;
}
?>