# SETUP POSTMAN UNTUK CI3 HMVC REST API

## 1. Import collection

Import file `CI3_API_Postman_Collection.json` dari folder project.

## 2. Set environment variable

Set variable berikut di Postman:

```text
base_url = http://localhost/ci3_project
```

## 3. Jalankan request secara berurutan

1. `Auth > Register User`
2. `Auth > Login User`
3. `Posts > Get All Posts`
4. `Posts > Create Post`
5. `Posts > Get My Posts`
6. `Posts > Update Post`
7. `Posts > Delete Post`
8. `Auth > Logout User`

## 4. Catatan penting

- Endpoint utama sekarang memakai `/api/post`, bukan `/api/posts`.
- Alias `/api/posts` masih ada untuk kompatibilitas, tetapi untuk praktikum sebaiknya pakai endpoint utama.
- Untuk `Create Post`, gunakan body `form-data` agar upload file gambar bisa jalan.
- Untuk `Update Post`, gunakan body `raw JSON`.
- Untuk endpoint yang butuh login, pastikan cookie session dari request login ikut terkirim.

## 5. Contoh data

### Register

```text
username=postmanuser
email=postmanuser@example.com
password=123456
password_confirm=123456
```

### Login

```text
username=postmanuser
password=123456
```

### Create Post

```text
title=Post dari Postman
author=Postman User
article=Ini adalah artikel yang dibuat dari Postman
image=(optional)
```

### Update Post

```json
{
  "title": "Post dari Postman Updated",
  "author": "Postman User",
  "article": "Artikel yang sudah diupdate dari Postman"
}
```
