# TESTING API - SIMPLE GUIDE

## Urutan cepat di Postman

### 1. Register

```text
URL: http://localhost/ci3_project/api/auth/register
Method: POST
Body: x-www-form-urlencoded

username=admin
email=admin@test.com
password=admin123
password_confirm=admin123
```

### 2. Login

```text
URL: http://localhost/ci3_project/api/auth/login
Method: POST
Body: x-www-form-urlencoded

username=admin
password=admin123
```

### 3. Get all posts

```text
URL: http://localhost/ci3_project/api/post
Method: GET
```

### 4. Create post

```text
URL: http://localhost/ci3_project/api/post
Method: POST
Body: form-data

title=My First Post
author=Admin User
article=This is my first post content
image=(optional)
```

### 5. Get my posts

```text
URL: http://localhost/ci3_project/api/post/my
Method: GET
```

### 6. Update post

```text
URL: http://localhost/ci3_project/api/post/1
Method: PUT
Body: raw JSON
```

```json
{
  "title": "Updated Title",
  "author": "Updated Author",
  "article": "Updated content"
}
```

### 7. Delete post

```text
URL: http://localhost/ci3_project/api/post/1
Method: DELETE
```

### 8. Logout

```text
URL: http://localhost/ci3_project/api/auth/logout
Method: POST
```

## Catatan

- Login dulu sebelum `create`, `my posts`, `update`, dan `delete`.
- Jika muncul `Authentication required`, cek cookie session di Postman.
- Jika muncul `Access denied`, gunakan post milik user yang sedang login.
- Alias `/api/posts` masih ada, tetapi endpoint utama praktikum sebaiknya `/api/post`.
