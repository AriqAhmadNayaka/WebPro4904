# CI3 API - POSTMAN TROUBLESHOOTING GUIDE

## ✅ STATUS: SEMUA ENDPOINT BERFUNGSI 100%

Server dan semua endpoint sudah ditest dan bekerja dengan baik. Jika Anda masih mendapat error, masalahnya ada di konfigurasi Postman.

## 🔧 LANGKAH-LANGKAH PERBAIKAN POSTMAN

### 1. IMPORT COLLECTION
- Buka Postman
- File → Import → Upload Files
- Pilih `CI3_API_Postman_Collection.json`
- Klik Import

### 2. SET VARIABLE BASE_URL
- Klik ikon mata (👁️) di kiri atas
- Tab "Variables"
- Set:
  - Variable: `base_url`
  - Initial value: `http://localhost/ci3_project`
  - Current value: `http://localhost/ci3_project`
- Klik Save

### 3. TEST REGISTER (POST)
- Klik folder "Auth" → "Register User"
- **PASTIKAN METHOD: POST** (bukan GET!)
- URL: `{{base_url}}/api/register`
- Body tab:
  - Mode: `x-www-form-urlencoded`
  - Data:
    - username: `postmantest`
    - email: `postmantest@example.com`
    - password: `123456`
    - password_confirm: `123456`
- Klik Send
- **HARUS BERHASIL:** `{"status":"success","message":"Registration successful","data":{"user_id":10}}`

### 4. TEST LOGIN (POST)
- Klik "Login User"
- **PASTIKAN METHOD: POST**
- URL: `{{base_url}}/api/login`
- Body: `x-www-form-urlencoded`
  - username: `postmantest`
  - password: `123456`
- Klik Send
- **HARUS BERHASIL:** `{"status":"success","message":"Login successful","data":{"user_id":"10","username":"postmantest"}}`

## 🚨 MASALAH UMUM & SOLUSI

### Error: "Method not allowed. Use POST."
**PENYEBAB:** Anda menggunakan method GET untuk endpoint yang butuh POST
**SOLUSI:** Ubah dropdown method dari GET menjadi POST

### Error: Empty response atau tidak ada response
**PENYEBAB:** base_url variable tidak diset
**SOLUSI:** Set base_url = `http://localhost/ci3_project`

### Error: Connection refused
**PENYEBAB:** XAMPP Apache tidak running
**SOLUSI:** Start Apache di XAMPP Control Panel

## 🧪 TEST MANUAL VIA BROWSER

Jika Postman masih bermasalah, test via browser:

1. Register: `http://localhost/ci3_project/api/register` (akan error karena GET)
2. Test server: `http://localhost/ci3_project/test_server.php` (harus berhasil)

## 📞 DEBUGGING LANJUTAN

Jika masih bermasalah:
1. Restart XAMPP Apache
2. Restart Postman
3. Import ulang collection
4. Pastikan tidak ada firewall blocking port 80

## ✅ HASIL TEST TERBARU

- ✅ Register: `{"status":"success","message":"Registration successful","data":{"user_id":10}}`
- ✅ Login: `{"status":"success","message":"Login successful","data":{"user_id":"10","username":"postmantest"}}`
- ✅ Get Posts: `{"status":"success","data":[...posts...]}`

**SEMUA SUDAH BEKERJA!** Masalahnya pasti di setup Postman Anda.  