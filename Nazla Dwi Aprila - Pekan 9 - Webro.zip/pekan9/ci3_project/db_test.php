<?php
// Simple database test
include 'application/config/database.php';

$host = $db['default']['hostname'];
$user = $db['default']['username'];
$pass = $db['default']['password'];
$dbname = $db['default']['database'];

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Database connected successfully<br>";

// Check tables
$result = $conn->query("SHOW TABLES LIKE 'posts'");
echo "Posts table exists: " . ($result->num_rows > 0 ? "Yes" : "No") . "<br>";

$result = $conn->query("SHOW TABLES LIKE 'users'");
echo "Users table exists: " . ($result->num_rows > 0 ? "Yes" : "No") . "<br>";

$conn->close();
?>