<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-04-25 08:07:38 --> Config Class Initialized
INFO - 2026-04-25 08:07:38 --> Hooks Class Initialized
DEBUG - 2026-04-25 08:07:38 --> UTF-8 Support Enabled
INFO - 2026-04-25 08:07:38 --> Utf8 Class Initialized
INFO - 2026-04-25 08:07:38 --> URI Class Initialized
DEBUG - 2026-04-25 08:07:38 --> No URI present. Default controller set.
INFO - 2026-04-25 08:07:38 --> Router Class Initialized
INFO - 2026-04-25 08:07:38 --> Output Class Initialized
INFO - 2026-04-25 08:07:38 --> Security Class Initialized
DEBUG - 2026-04-25 08:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-25 08:07:38 --> Input Class Initialized
INFO - 2026-04-25 08:07:38 --> Language Class Initialized
INFO - 2026-04-25 08:07:38 --> Loader Class Initialized
INFO - 2026-04-25 08:07:38 --> Helper loaded: url_helper
INFO - 2026-04-25 08:07:38 --> Helper loaded: form_helper
INFO - 2026-04-25 08:07:38 --> Database Driver Class Initialized
INFO - 2026-04-25 08:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-25 08:07:38 --> Upload Class Initialized
INFO - 2026-04-25 08:07:38 --> Controller Class Initialized
INFO - 2026-04-25 08:07:38 --> Model "User_model" initialized
INFO - 2026-04-25 08:07:38 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\auth/login.php
INFO - 2026-04-25 08:07:38 --> Final output sent to browser
DEBUG - 2026-04-25 08:07:38 --> Total execution time: 0.1363
INFO - 2026-04-25 08:08:11 --> Config Class Initialized
INFO - 2026-04-25 08:08:11 --> Hooks Class Initialized
DEBUG - 2026-04-25 08:08:11 --> UTF-8 Support Enabled
INFO - 2026-04-25 08:08:11 --> Utf8 Class Initialized
INFO - 2026-04-25 08:08:11 --> URI Class Initialized
INFO - 2026-04-25 08:08:11 --> Router Class Initialized
INFO - 2026-04-25 08:08:11 --> Output Class Initialized
INFO - 2026-04-25 08:08:11 --> Security Class Initialized
DEBUG - 2026-04-25 08:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-25 08:08:11 --> Input Class Initialized
INFO - 2026-04-25 08:08:11 --> Language Class Initialized
INFO - 2026-04-25 08:08:11 --> Loader Class Initialized
INFO - 2026-04-25 08:08:11 --> Helper loaded: url_helper
INFO - 2026-04-25 08:08:11 --> Helper loaded: form_helper
INFO - 2026-04-25 08:08:11 --> Database Driver Class Initialized
INFO - 2026-04-25 08:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-25 08:08:11 --> Upload Class Initialized
INFO - 2026-04-25 08:08:11 --> Controller Class Initialized
INFO - 2026-04-25 08:08:11 --> Model "User_model" initialized
INFO - 2026-04-25 08:08:11 --> Config Class Initialized
INFO - 2026-04-25 08:08:11 --> Hooks Class Initialized
DEBUG - 2026-04-25 08:08:11 --> UTF-8 Support Enabled
INFO - 2026-04-25 08:08:11 --> Utf8 Class Initialized
INFO - 2026-04-25 08:08:11 --> URI Class Initialized
INFO - 2026-04-25 08:08:11 --> Router Class Initialized
INFO - 2026-04-25 08:08:11 --> Output Class Initialized
INFO - 2026-04-25 08:08:11 --> Security Class Initialized
DEBUG - 2026-04-25 08:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-25 08:08:11 --> Input Class Initialized
INFO - 2026-04-25 08:08:11 --> Language Class Initialized
INFO - 2026-04-25 08:08:11 --> Loader Class Initialized
INFO - 2026-04-25 08:08:11 --> Helper loaded: url_helper
INFO - 2026-04-25 08:08:11 --> Helper loaded: form_helper
INFO - 2026-04-25 08:08:11 --> Database Driver Class Initialized
INFO - 2026-04-25 08:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-25 08:08:11 --> Upload Class Initialized
INFO - 2026-04-25 08:08:11 --> Controller Class Initialized
INFO - 2026-04-25 08:08:11 --> Model "Warga_model" initialized
INFO - 2026-04-25 08:08:11 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/header.php
INFO - 2026-04-25 08:08:11 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\dashboard/index.php
INFO - 2026-04-25 08:08:11 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/footer.php
INFO - 2026-04-25 08:08:11 --> Final output sent to browser
DEBUG - 2026-04-25 08:08:11 --> Total execution time: 0.0936
INFO - 2026-04-25 08:10:15 --> Config Class Initialized
INFO - 2026-04-25 08:10:15 --> Hooks Class Initialized
DEBUG - 2026-04-25 08:10:15 --> UTF-8 Support Enabled
INFO - 2026-04-25 08:10:15 --> Utf8 Class Initialized
INFO - 2026-04-25 08:10:15 --> URI Class Initialized
INFO - 2026-04-25 08:10:15 --> Router Class Initialized
INFO - 2026-04-25 08:10:15 --> Output Class Initialized
INFO - 2026-04-25 08:10:15 --> Security Class Initialized
DEBUG - 2026-04-25 08:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-25 08:10:15 --> Input Class Initialized
INFO - 2026-04-25 08:10:15 --> Language Class Initialized
INFO - 2026-04-25 08:10:15 --> Loader Class Initialized
INFO - 2026-04-25 08:10:15 --> Helper loaded: url_helper
INFO - 2026-04-25 08:10:15 --> Helper loaded: form_helper
INFO - 2026-04-25 08:10:15 --> Database Driver Class Initialized
INFO - 2026-04-25 08:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-25 08:10:15 --> Upload Class Initialized
INFO - 2026-04-25 08:10:15 --> Controller Class Initialized
INFO - 2026-04-25 08:10:15 --> Model "Warga_model" initialized
INFO - 2026-04-25 08:10:15 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/header.php
INFO - 2026-04-25 08:10:15 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\warga/index.php
INFO - 2026-04-25 08:10:15 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/footer.php
INFO - 2026-04-25 08:10:15 --> Final output sent to browser
DEBUG - 2026-04-25 08:10:15 --> Total execution time: 0.2171
INFO - 2026-04-25 09:02:31 --> Config Class Initialized
INFO - 2026-04-25 09:02:31 --> Hooks Class Initialized
DEBUG - 2026-04-25 09:02:31 --> UTF-8 Support Enabled
INFO - 2026-04-25 09:02:31 --> Utf8 Class Initialized
INFO - 2026-04-25 09:02:31 --> URI Class Initialized
INFO - 2026-04-25 09:02:31 --> Router Class Initialized
INFO - 2026-04-25 09:02:31 --> Output Class Initialized
INFO - 2026-04-25 09:02:31 --> Security Class Initialized
DEBUG - 2026-04-25 09:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-25 09:02:31 --> Input Class Initialized
INFO - 2026-04-25 09:02:31 --> Language Class Initialized
INFO - 2026-04-25 09:02:31 --> Loader Class Initialized
INFO - 2026-04-25 09:02:31 --> Helper loaded: url_helper
INFO - 2026-04-25 09:02:31 --> Helper loaded: form_helper
INFO - 2026-04-25 09:02:31 --> Database Driver Class Initialized
INFO - 2026-04-25 09:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-25 09:02:31 --> Upload Class Initialized
INFO - 2026-04-25 09:02:31 --> Controller Class Initialized
INFO - 2026-04-25 09:02:31 --> Model "Warga_model" initialized
INFO - 2026-04-25 09:02:31 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/header.php
INFO - 2026-04-25 09:02:31 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\warga/index.php
INFO - 2026-04-25 09:02:31 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/footer.php
INFO - 2026-04-25 09:02:31 --> Final output sent to browser
DEBUG - 2026-04-25 09:02:31 --> Total execution time: 0.1096
INFO - 2026-04-25 09:02:32 --> Config Class Initialized
INFO - 2026-04-25 09:02:32 --> Hooks Class Initialized
DEBUG - 2026-04-25 09:02:32 --> UTF-8 Support Enabled
INFO - 2026-04-25 09:02:32 --> Utf8 Class Initialized
INFO - 2026-04-25 09:02:32 --> URI Class Initialized
INFO - 2026-04-25 09:02:32 --> Router Class Initialized
INFO - 2026-04-25 09:02:32 --> Output Class Initialized
INFO - 2026-04-25 09:02:32 --> Security Class Initialized
DEBUG - 2026-04-25 09:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-25 09:02:33 --> Input Class Initialized
INFO - 2026-04-25 09:02:33 --> Language Class Initialized
INFO - 2026-04-25 09:02:33 --> Loader Class Initialized
INFO - 2026-04-25 09:02:33 --> Helper loaded: url_helper
INFO - 2026-04-25 09:02:33 --> Helper loaded: form_helper
INFO - 2026-04-25 09:02:33 --> Database Driver Class Initialized
INFO - 2026-04-25 09:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-25 09:02:33 --> Upload Class Initialized
INFO - 2026-04-25 09:02:33 --> Controller Class Initialized
INFO - 2026-04-25 09:02:33 --> Model "Warga_model" initialized
INFO - 2026-04-25 09:02:33 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/header.php
INFO - 2026-04-25 09:02:33 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\dashboard/index.php
INFO - 2026-04-25 09:02:33 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/footer.php
INFO - 2026-04-25 09:02:33 --> Final output sent to browser
DEBUG - 2026-04-25 09:02:33 --> Total execution time: 0.3969
INFO - 2026-04-25 09:02:33 --> Config Class Initialized
INFO - 2026-04-25 09:02:33 --> Hooks Class Initialized
DEBUG - 2026-04-25 09:02:33 --> UTF-8 Support Enabled
INFO - 2026-04-25 09:02:33 --> Utf8 Class Initialized
INFO - 2026-04-25 09:02:33 --> URI Class Initialized
DEBUG - 2026-04-25 09:02:33 --> No URI present. Default controller set.
INFO - 2026-04-25 09:02:33 --> Router Class Initialized
INFO - 2026-04-25 09:02:33 --> Output Class Initialized
INFO - 2026-04-25 09:02:33 --> Security Class Initialized
DEBUG - 2026-04-25 09:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-25 09:02:33 --> Input Class Initialized
INFO - 2026-04-25 09:02:33 --> Language Class Initialized
INFO - 2026-04-25 09:02:33 --> Loader Class Initialized
INFO - 2026-04-25 09:02:33 --> Helper loaded: url_helper
INFO - 2026-04-25 09:02:33 --> Helper loaded: form_helper
INFO - 2026-04-25 09:02:33 --> Database Driver Class Initialized
INFO - 2026-04-25 09:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-25 09:02:33 --> Upload Class Initialized
INFO - 2026-04-25 09:02:33 --> Controller Class Initialized
INFO - 2026-04-25 09:02:33 --> Model "User_model" initialized
INFO - 2026-04-25 09:02:33 --> Config Class Initialized
INFO - 2026-04-25 09:02:33 --> Hooks Class Initialized
DEBUG - 2026-04-25 09:02:33 --> UTF-8 Support Enabled
INFO - 2026-04-25 09:02:33 --> Utf8 Class Initialized
INFO - 2026-04-25 09:02:33 --> URI Class Initialized
INFO - 2026-04-25 09:02:33 --> Router Class Initialized
INFO - 2026-04-25 09:02:33 --> Output Class Initialized
INFO - 2026-04-25 09:02:33 --> Security Class Initialized
DEBUG - 2026-04-25 09:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-25 09:02:33 --> Input Class Initialized
INFO - 2026-04-25 09:02:33 --> Language Class Initialized
INFO - 2026-04-25 09:02:33 --> Loader Class Initialized
INFO - 2026-04-25 09:02:33 --> Helper loaded: url_helper
INFO - 2026-04-25 09:02:33 --> Helper loaded: form_helper
INFO - 2026-04-25 09:02:33 --> Database Driver Class Initialized
INFO - 2026-04-25 09:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-25 09:02:33 --> Upload Class Initialized
INFO - 2026-04-25 09:02:33 --> Controller Class Initialized
INFO - 2026-04-25 09:02:33 --> Model "Warga_model" initialized
INFO - 2026-04-25 09:02:33 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/header.php
INFO - 2026-04-25 09:02:33 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\dashboard/index.php
INFO - 2026-04-25 09:02:33 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/footer.php
INFO - 2026-04-25 09:02:33 --> Final output sent to browser
DEBUG - 2026-04-25 09:02:33 --> Total execution time: 0.0871
INFO - 2026-04-25 09:02:38 --> Config Class Initialized
INFO - 2026-04-25 09:02:38 --> Hooks Class Initialized
DEBUG - 2026-04-25 09:02:38 --> UTF-8 Support Enabled
INFO - 2026-04-25 09:02:38 --> Utf8 Class Initialized
INFO - 2026-04-25 09:02:38 --> URI Class Initialized
DEBUG - 2026-04-25 09:02:38 --> No URI present. Default controller set.
INFO - 2026-04-25 09:02:38 --> Router Class Initialized
INFO - 2026-04-25 09:02:38 --> Output Class Initialized
INFO - 2026-04-25 09:02:38 --> Security Class Initialized
DEBUG - 2026-04-25 09:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-25 09:02:38 --> Input Class Initialized
INFO - 2026-04-25 09:02:38 --> Language Class Initialized
INFO - 2026-04-25 09:02:38 --> Loader Class Initialized
INFO - 2026-04-25 09:02:38 --> Helper loaded: url_helper
INFO - 2026-04-25 09:02:38 --> Helper loaded: form_helper
INFO - 2026-04-25 09:02:38 --> Database Driver Class Initialized
INFO - 2026-04-25 09:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-25 09:02:38 --> Upload Class Initialized
INFO - 2026-04-25 09:02:38 --> Controller Class Initialized
INFO - 2026-04-25 09:02:38 --> Model "User_model" initialized
INFO - 2026-04-25 09:02:38 --> Config Class Initialized
INFO - 2026-04-25 09:02:38 --> Hooks Class Initialized
DEBUG - 2026-04-25 09:02:38 --> UTF-8 Support Enabled
INFO - 2026-04-25 09:02:38 --> Utf8 Class Initialized
INFO - 2026-04-25 09:02:38 --> URI Class Initialized
INFO - 2026-04-25 09:02:38 --> Router Class Initialized
INFO - 2026-04-25 09:02:38 --> Output Class Initialized
INFO - 2026-04-25 09:02:38 --> Security Class Initialized
DEBUG - 2026-04-25 09:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-25 09:02:38 --> Input Class Initialized
INFO - 2026-04-25 09:02:38 --> Language Class Initialized
INFO - 2026-04-25 09:02:38 --> Loader Class Initialized
INFO - 2026-04-25 09:02:38 --> Helper loaded: url_helper
INFO - 2026-04-25 09:02:38 --> Helper loaded: form_helper
INFO - 2026-04-25 09:02:38 --> Database Driver Class Initialized
INFO - 2026-04-25 09:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-25 09:02:38 --> Upload Class Initialized
INFO - 2026-04-25 09:02:38 --> Controller Class Initialized
INFO - 2026-04-25 09:02:38 --> Model "Warga_model" initialized
INFO - 2026-04-25 09:02:38 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/header.php
INFO - 2026-04-25 09:02:38 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\dashboard/index.php
INFO - 2026-04-25 09:02:38 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/footer.php
INFO - 2026-04-25 09:02:38 --> Final output sent to browser
DEBUG - 2026-04-25 09:02:38 --> Total execution time: 0.0716
