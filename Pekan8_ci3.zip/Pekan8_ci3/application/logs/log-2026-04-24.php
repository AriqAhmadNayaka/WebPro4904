<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-04-24 11:48:38 --> Config Class Initialized
INFO - 2026-04-24 11:48:38 --> Hooks Class Initialized
DEBUG - 2026-04-24 11:48:38 --> UTF-8 Support Enabled
INFO - 2026-04-24 11:48:38 --> Utf8 Class Initialized
INFO - 2026-04-24 11:48:38 --> URI Class Initialized
DEBUG - 2026-04-24 11:48:38 --> No URI present. Default controller set.
INFO - 2026-04-24 11:48:38 --> Router Class Initialized
INFO - 2026-04-24 11:48:38 --> Output Class Initialized
INFO - 2026-04-24 11:48:38 --> Security Class Initialized
DEBUG - 2026-04-24 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-24 11:48:38 --> Input Class Initialized
INFO - 2026-04-24 11:48:38 --> Language Class Initialized
INFO - 2026-04-24 11:48:38 --> Loader Class Initialized
INFO - 2026-04-24 11:48:38 --> Helper loaded: url_helper
INFO - 2026-04-24 11:48:38 --> Helper loaded: form_helper
INFO - 2026-04-24 11:48:38 --> Database Driver Class Initialized
INFO - 2026-04-24 11:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-24 11:48:38 --> Upload Class Initialized
INFO - 2026-04-24 11:48:38 --> Controller Class Initialized
INFO - 2026-04-24 11:48:38 --> Model "User_model" initialized
INFO - 2026-04-24 11:48:38 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\auth/login.php
INFO - 2026-04-24 11:48:38 --> Final output sent to browser
DEBUG - 2026-04-24 11:48:38 --> Total execution time: 0.1583
INFO - 2026-04-24 11:48:52 --> Config Class Initialized
INFO - 2026-04-24 11:48:52 --> Hooks Class Initialized
DEBUG - 2026-04-24 11:48:52 --> UTF-8 Support Enabled
INFO - 2026-04-24 11:48:52 --> Utf8 Class Initialized
INFO - 2026-04-24 11:48:52 --> URI Class Initialized
INFO - 2026-04-24 11:48:52 --> Router Class Initialized
INFO - 2026-04-24 11:48:52 --> Output Class Initialized
INFO - 2026-04-24 11:48:52 --> Security Class Initialized
DEBUG - 2026-04-24 11:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-24 11:48:52 --> Input Class Initialized
INFO - 2026-04-24 11:48:52 --> Language Class Initialized
INFO - 2026-04-24 11:48:52 --> Loader Class Initialized
INFO - 2026-04-24 11:48:52 --> Helper loaded: url_helper
INFO - 2026-04-24 11:48:52 --> Helper loaded: form_helper
INFO - 2026-04-24 11:48:52 --> Database Driver Class Initialized
INFO - 2026-04-24 11:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-24 11:48:53 --> Upload Class Initialized
INFO - 2026-04-24 11:48:53 --> Controller Class Initialized
INFO - 2026-04-24 11:48:53 --> Model "User_model" initialized
INFO - 2026-04-24 11:48:53 --> Config Class Initialized
INFO - 2026-04-24 11:48:53 --> Hooks Class Initialized
DEBUG - 2026-04-24 11:48:53 --> UTF-8 Support Enabled
INFO - 2026-04-24 11:48:53 --> Utf8 Class Initialized
INFO - 2026-04-24 11:48:53 --> URI Class Initialized
INFO - 2026-04-24 11:48:53 --> Router Class Initialized
INFO - 2026-04-24 11:48:53 --> Output Class Initialized
INFO - 2026-04-24 11:48:53 --> Security Class Initialized
DEBUG - 2026-04-24 11:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-24 11:48:53 --> Input Class Initialized
INFO - 2026-04-24 11:48:53 --> Language Class Initialized
INFO - 2026-04-24 11:48:53 --> Loader Class Initialized
INFO - 2026-04-24 11:48:53 --> Helper loaded: url_helper
INFO - 2026-04-24 11:48:53 --> Helper loaded: form_helper
INFO - 2026-04-24 11:48:53 --> Database Driver Class Initialized
INFO - 2026-04-24 11:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-24 11:48:53 --> Upload Class Initialized
INFO - 2026-04-24 11:48:53 --> Controller Class Initialized
INFO - 2026-04-24 11:48:53 --> Model "Warga_model" initialized
INFO - 2026-04-24 11:48:53 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/header.php
INFO - 2026-04-24 11:48:53 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\dashboard/index.php
INFO - 2026-04-24 11:48:53 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/footer.php
INFO - 2026-04-24 11:48:53 --> Final output sent to browser
DEBUG - 2026-04-24 11:48:53 --> Total execution time: 0.0895
INFO - 2026-04-24 11:49:23 --> Config Class Initialized
INFO - 2026-04-24 11:49:23 --> Hooks Class Initialized
DEBUG - 2026-04-24 11:49:23 --> UTF-8 Support Enabled
INFO - 2026-04-24 11:49:23 --> Utf8 Class Initialized
INFO - 2026-04-24 11:49:23 --> URI Class Initialized
INFO - 2026-04-24 11:49:23 --> Router Class Initialized
INFO - 2026-04-24 11:49:23 --> Output Class Initialized
INFO - 2026-04-24 11:49:23 --> Security Class Initialized
DEBUG - 2026-04-24 11:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-24 11:49:23 --> Input Class Initialized
INFO - 2026-04-24 11:49:23 --> Language Class Initialized
INFO - 2026-04-24 11:49:23 --> Loader Class Initialized
INFO - 2026-04-24 11:49:23 --> Helper loaded: url_helper
INFO - 2026-04-24 11:49:23 --> Helper loaded: form_helper
INFO - 2026-04-24 11:49:23 --> Database Driver Class Initialized
INFO - 2026-04-24 11:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-24 11:49:23 --> Upload Class Initialized
INFO - 2026-04-24 11:49:23 --> Controller Class Initialized
INFO - 2026-04-24 11:49:23 --> Model "Warga_model" initialized
INFO - 2026-04-24 11:49:23 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/header.php
INFO - 2026-04-24 11:49:23 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\warga/index.php
INFO - 2026-04-24 11:49:23 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/footer.php
INFO - 2026-04-24 11:49:23 --> Final output sent to browser
DEBUG - 2026-04-24 11:49:23 --> Total execution time: 0.0871
INFO - 2026-04-24 11:49:35 --> Config Class Initialized
INFO - 2026-04-24 11:49:35 --> Hooks Class Initialized
DEBUG - 2026-04-24 11:49:35 --> UTF-8 Support Enabled
INFO - 2026-04-24 11:49:35 --> Utf8 Class Initialized
INFO - 2026-04-24 11:49:35 --> URI Class Initialized
INFO - 2026-04-24 11:49:35 --> Router Class Initialized
INFO - 2026-04-24 11:49:35 --> Output Class Initialized
INFO - 2026-04-24 11:49:35 --> Security Class Initialized
DEBUG - 2026-04-24 11:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-24 11:49:35 --> Input Class Initialized
INFO - 2026-04-24 11:49:35 --> Language Class Initialized
INFO - 2026-04-24 11:49:35 --> Loader Class Initialized
INFO - 2026-04-24 11:49:35 --> Helper loaded: url_helper
INFO - 2026-04-24 11:49:35 --> Helper loaded: form_helper
INFO - 2026-04-24 11:49:35 --> Database Driver Class Initialized
INFO - 2026-04-24 11:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-24 11:49:35 --> Upload Class Initialized
INFO - 2026-04-24 11:49:35 --> Controller Class Initialized
INFO - 2026-04-24 11:49:35 --> Model "Warga_model" initialized
INFO - 2026-04-24 11:49:35 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/header.php
INFO - 2026-04-24 11:49:35 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\dashboard/index.php
INFO - 2026-04-24 11:49:35 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\layouts/footer.php
INFO - 2026-04-24 11:49:35 --> Final output sent to browser
DEBUG - 2026-04-24 11:49:35 --> Total execution time: 0.1243
INFO - 2026-04-24 11:49:37 --> Config Class Initialized
INFO - 2026-04-24 11:49:37 --> Hooks Class Initialized
DEBUG - 2026-04-24 11:49:37 --> UTF-8 Support Enabled
INFO - 2026-04-24 11:49:37 --> Utf8 Class Initialized
INFO - 2026-04-24 11:49:37 --> URI Class Initialized
INFO - 2026-04-24 11:49:37 --> Router Class Initialized
INFO - 2026-04-24 11:49:37 --> Output Class Initialized
INFO - 2026-04-24 11:49:37 --> Security Class Initialized
DEBUG - 2026-04-24 11:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-24 11:49:37 --> Input Class Initialized
INFO - 2026-04-24 11:49:37 --> Language Class Initialized
INFO - 2026-04-24 11:49:37 --> Loader Class Initialized
INFO - 2026-04-24 11:49:37 --> Helper loaded: url_helper
INFO - 2026-04-24 11:49:37 --> Helper loaded: form_helper
INFO - 2026-04-24 11:49:37 --> Database Driver Class Initialized
INFO - 2026-04-24 11:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-24 11:49:37 --> Upload Class Initialized
INFO - 2026-04-24 11:49:37 --> Controller Class Initialized
INFO - 2026-04-24 11:49:37 --> Model "User_model" initialized
INFO - 2026-04-24 11:49:37 --> Config Class Initialized
INFO - 2026-04-24 11:49:37 --> Hooks Class Initialized
DEBUG - 2026-04-24 11:49:37 --> UTF-8 Support Enabled
INFO - 2026-04-24 11:49:37 --> Utf8 Class Initialized
INFO - 2026-04-24 11:49:37 --> URI Class Initialized
INFO - 2026-04-24 11:49:37 --> Router Class Initialized
INFO - 2026-04-24 11:49:37 --> Output Class Initialized
INFO - 2026-04-24 11:49:37 --> Security Class Initialized
DEBUG - 2026-04-24 11:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-24 11:49:37 --> Input Class Initialized
INFO - 2026-04-24 11:49:37 --> Language Class Initialized
INFO - 2026-04-24 11:49:37 --> Loader Class Initialized
INFO - 2026-04-24 11:49:37 --> Helper loaded: url_helper
INFO - 2026-04-24 11:49:37 --> Helper loaded: form_helper
INFO - 2026-04-24 11:49:37 --> Database Driver Class Initialized
INFO - 2026-04-24 11:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-24 11:49:37 --> Upload Class Initialized
INFO - 2026-04-24 11:49:37 --> Controller Class Initialized
INFO - 2026-04-24 11:49:37 --> Model "User_model" initialized
INFO - 2026-04-24 11:49:37 --> File loaded: C:\xampp\htdocs\Pemograman Web\WebPro4904\Pekan8_ci3\application\views\auth/login.php
INFO - 2026-04-24 11:49:37 --> Final output sent to browser
DEBUG - 2026-04-24 11:49:37 --> Total execution time: 0.0778
