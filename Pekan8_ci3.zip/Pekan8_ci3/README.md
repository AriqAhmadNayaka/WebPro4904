# Aplikasi Sederhana CodeIgniter 3

Project ini berisi:

- login
- dashboard setelah login
- CRUD data warga
- upload file
- satu tombol `Simpan` untuk tambah atau update data

## Cara pakai

1. Import `webdesa_ci3.sql`.
2. Pastikan nama database di `application/config/database.php` adalah `webdesa_ci3` (atau sesuaikan dengan nama database yang kamu pakai).
3. Buka `http://localhost/Pemograman%20Web/WebPro4904/Pekan8_ci3/index.php/auth`

## Login default

- username: `admin`
- password: `admin123`
