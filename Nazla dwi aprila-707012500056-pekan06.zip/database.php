<?php
class Database 
{
    private string $host = 'localhost';// Host database
    private string $user = 'root';// Username database
    private string $pass = '';// Password database
    private string $db = 'pekan6';//  Nama database
    private string $uploadDir;// Direktori untuk menyimpan gambar
    public mysqli $conn;// Koneksi database

    public function __construct()// : void
    {
        $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->db);// Buat koneksi ke database

        if ($this->conn->connect_error) {// Cek koneksi
            die('Koneksi gagal: ' . $this->conn->connect_error);
        }

        $this->uploadDir = __DIR__ . DIRECTORY_SEPARATOR . 'img' . DIRECTORY_SEPARATOR;// Set direktori upload gambar

        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0777, true);
        }
    }

    public function login(string $username, string $password): ?array
    {
        $stmt = $this->conn->prepare('SELECT username, password FROM ecotaste WHERE username = ? LIMIT 1');// Persiapkan statement untuk mencegah SQL injection
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        if (!$user || $password !== $user['password']) {
            return null;
        }

        return $user;
    }

    public function getAllMenus(): mysqli_result
    {
        return $this->conn->query('SELECT * FROM beranda ORDER BY id DESC');// Ambil semua data kuliner dari tabel beranda
    }

    public function getMenuById(int $id): ?array// Ambil data kuliner berdasarkan id
    {
        $stmt = $this->conn->prepare('SELECT * FROM beranda WHERE id = ? LIMIT 1');// Persiapkan statement untuk mencegah SQL injection
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        $stmt->close();

        return $data ?: null;
    }

    public function saveMenu(array $post, array $files): bool// Simpan data kuliner baru atau update data kuliner yang sudah ada
    {
        $id = isset($post['id']) ? (int) $post['id'] : 0;
        $nama = trim($post['nama'] ?? '');
        $deskripsi = trim($post['deskripsi'] ?? '');
        $rating = trim($post['rating'] ?? '');

        if ($nama === '' || $deskripsi === '' || $rating === '' || !is_numeric($rating)) {
            return false;
        }

        $gambarLama = '';// Variabel untuk menyimpan nama file gambar lama jika sedang melakukan update

        if ($id > 0) {
            $menu = $this->getMenuById($id);// Ambil data kuliner berdasarkan id untuk mendapatkan nama file gambar lama

            if (!$menu) {
                return false;
            }

            $gambarLama = $menu['gambar'] ?? '';
        }

        $gambarBaru = $this->uploadImage($files['gambar'] ?? null, $gambarLama, $id === 0);

        if ($gambarBaru === false) {
            return false;
        }

        $ratingValue = (float) $rating;// Pastikan rating disimpan sebagai angka desimal

        if ($id > 0) {
            $stmt = $this->conn->prepare('UPDATE beranda SET nama = ?, deskripsi = ?, rating = ?, gambar = ? WHERE id = ?');// Persiapkan statement untuk mencegah SQL injection
            $stmt->bind_param('ssdsi', $nama, $deskripsi, $ratingValue, $gambarBaru, $id);
        } else {
            $stmt = $this->conn->prepare('INSERT INTO beranda (nama, deskripsi, rating, gambar) VALUES (?, ?, ?, ?)');// Persiapkan statement untuk mencegah SQL injection
            $stmt->bind_param('ssds', $nama, $deskripsi, $ratingValue, $gambarBaru);
        }

        $success = $stmt->execute();// Eksekusi statement dan simpan hasilnya
        $stmt->close();

        return $success;
    }

    public function deleteMenu(int $id): bool// Hapus data kuliner berdasarkan id
    {
        $menu = $this->getMenuById($id);

        if (!$menu) {
            return false;
        }

        $stmt = $this->conn->prepare('DELETE FROM beranda WHERE id = ?');// Persiapkan statement untuk mencegah SQL injection
        $stmt->bind_param('i', $id);
        $success = $stmt->execute();
        $stmt->close();

        if ($success && !empty($menu['gambar'])) {
            $filePath = $this->uploadDir . $menu['gambar'];

            if (is_file($filePath)) {
                unlink($filePath);
            }
        }

        return $success;
    }

    public function getImageWebPath(?string $fileName): string// Dapatkan path web untuk file gambar berdasarkan nama file
    {
        if (empty($fileName)) {
            return '';
        }

        return 'img/' . rawurlencode($fileName);
    }

    public function imageExists(?string $fileName): bool// Cek apakah file gambar ada di server
    {
        if (empty($fileName)) {
            return false;
        }

        return is_file($this->uploadDir . $fileName);
    }

    private function uploadImage(?array $file, string $oldFile = '', bool $required = true): string|false// Proses upload gambar, hapus gambar lama jika ada, dan kembalikan nama file baru atau false jika gagal
    {
        if (!$file || !isset($file['error'])) {
            return $required ? false : $oldFile;
        }

        if ($file['error'] === UPLOAD_ERR_NO_FILE) {
            return $required ? false : $oldFile;
        }

        if ($file['error'] !== UPLOAD_ERR_OK) {
            return false;
        }

        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($extension, $allowedExtensions, true)) {
            return false;
        }

        $newFileName = uniqid('menu_', true) . '.' . $extension;// Buat nama file baru yang unik untuk menghindari konflik nama file
        $destination = $this->uploadDir . $newFileName;

        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            return false;
        }

        if ($oldFile !== '') {// Hapus file gambar lama jika ada
            $oldPath = $this->uploadDir . $oldFile;

            if (is_file($oldPath)) {
                unlink($oldPath);
            }
        }

        return $newFileName;
    }
}
?>
