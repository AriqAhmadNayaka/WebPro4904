<?php
session_start();

if (!isset($_SESSION['login'])) {// Cek apakah pengguna sudah login
    header('Location: login.php');
    exit;
}

require 'database.php';// Nama file database.php
$db = new Database();

if (isset($_GET['id'])) {// Cek apakah parameter id ada di URL
    $id = (int) $_GET['id'];

    if ($db->deleteMenu($id)) {// Panggil method deleteMenu untuk menghapus data berdasarkan id
        echo "<script>
                alert('Data berhasil dihapus!');
                document.location.href = 'homepage.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menghapus data!');
                document.location.href = 'homepage.php';
              </script>";
    }
} else {
    header('Location: homepage.php');//
    exit;
}
?>
