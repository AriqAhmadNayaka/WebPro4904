<?php
error_reporting(E_ALL); 
ini_set('display_errors', 1);// Aktifkan pelaporan kesalahan untuk debugging

session_start();// Mulai sesi untuk login

if (!file_exists('database.php')) {// Cek apakah file database.php ada
    die('File database.php tidak ditemukan di folder ini!');// Hentikan eksekusi jika file tidak ditemukan
}

require 'database.php';//untuk akses ke kelas Database
$db = new Database();

if (isset($_POST['login_btn'])) {// Cek apakah tombol login ditekan
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $user = $db->login($username, $password);

    if ($user) {// Jika login berhasil, set session dan redirect ke homepage
        $_SESSION['login'] = true;
        $_SESSION['user'] = $user['username'];
        header('Location: homepage.php');
        exit;
    }

    $error = 'Username atau password salah!';// Set pesan error jika login gagal
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login EcoTaste</title>
    <style>
        body { background: #8BC34A; font-family: sans-serif; display: flex; justify-content: center; padding-top: 100px; }
        .card { background: white; padding: 20px; border-radius: 10px; width: 300px; box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        h2 { text-align: center; color: #4CAF50; }
        input { width: 100%; padding: 10px; margin: 10px 0; box-sizing: border-box; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 10px; background: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; }
        .err { color: red; text-align: center; font-size: 14px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>EcoTaste Login</h2>
        <?php if (isset($error)) : ?>
            <p class="err"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></p>
        <?php endif; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login_btn">LOGIN</button>
        </form>
    </div>
</body>
</html>
