<?php
session_start();

if (isset($_POST['submit_laporan'])) {
   
    $laporan_baru = [
        'id'        => time(), 
        'judul'     => $_POST['judul'],
        'isi'       => $_POST['isi'],
        'tanggal'   => $_POST['tanggal'],
        'lokasi'    => $_POST['lokasi'],
        'instansi'  => $_POST['instansi'],
        'kategori'  => $_POST['kategori'],
        'waktu_input' => date("Y-m-d H:i:s")
    ];

    if (!isset($_SESSION['data_laporan'])) {
        $_SESSION['data_laporan'] = [];
    }
    
    array_push($_SESSION['data_laporan'], $laporan_baru);

    $_SESSION['success_laporan'] = "Laporan berhasil dikirim!";
    header("Location: LaporanPage.php");
    exit;
}
?>