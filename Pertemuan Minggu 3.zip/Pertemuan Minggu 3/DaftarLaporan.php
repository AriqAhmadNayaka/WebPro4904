<?php 
session_start(); 

// 1. Tentukan jumlah laporan per halaman
$laporanPerHalaman = 5;

// 2. Ambil data dari session atau buat array kosong jika belum ada
$semuaLaporan = isset($_SESSION['data_laporan']) ? array_reverse($_SESSION['data_laporan']) : [];

// 3. Hitung total data dan total halaman
$totalData = count($semuaLaporan);
$totalHalaman = ceil($totalData / $laporanPerHalaman);

// 4. Tentukan halaman saat ini dari URL (misal: DaftarLaporan.php?halaman=2)
$halamanAktif = (isset($_GET['halaman'])) ? (int)$_GET['halaman'] : 1;
if ($halamanAktif < 1) $halamanAktif = 1;

// 5. Tentukan index awal data yang akan ditampilkan
$awalData = ($laporanPerHalaman * $halamanAktif) - $laporanPerHalaman;

// 6. Potong array sesuai halaman (Fungsi Read Tersegmentasi)
$laporanHalamanIni = array_slice($semuaLaporan, $awalData, $laporanPerHalaman);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Riwayat Laporan - CyberVault</title>
    <link rel="stylesheet" href="HomePage.css">
    <style>
        body { background: #0a0a0f; color: #e0e6ed; font-family: 'Poppins', sans-serif; padding: 100px 20px; }
        .container { max-width: 900px; margin: auto; }
        .card-laporan {
            background: rgba(15, 15, 35, 0.65);
            border: 1px solid rgba(0, 212, 255, 0.2);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 20px;
            transition: 0.3s;
        }
        .card-laporan:hover { border-color: #00d4ff; transform: translateY(-5px); }
        .badge { background: rgba(0, 212, 255, 0.1); color: #00d4ff; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; }
        
        /* Desain Navigasi Halaman */
        .pagination { display: flex; justify-content: center; gap: 10px; margin-top: 30px; }
        .page-link {
            padding: 8px 16px;
            border: 1px solid rgba(0, 212, 255, 0.3);
            border-radius: 8px;
            color: #00d4ff;
            text-decoration: none;
            transition: 0.3s;
        }
        .page-link:hover, .page-link.active {
            background: #00d4ff;
            color: #0a0a0f;
        }
        .page-link.disabled {
            color: #444;
            border-color: #222;
            cursor: not-allowed;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 style="text-align: center; margin-bottom: 10px;">Riwayat Laporan</h2>
    <p style="text-align: center; color: #8892b0; margin-bottom: 30px;">Menampilkan total <?= $totalData ?> laporan</p>
    
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <a href="LaporanPage.php" style="color: #00d4ff; text-decoration: none; font-weight: 600;">+ Buat Laporan</a>
        <a href="HomePage.html" style="color: #8892b0; text-decoration: none; font-size: 0.85rem;">Kembali ke Home</a>
    </div>
    
    <hr style="border: 0.5px solid rgba(255,255,255,0.1); margin: 20px 0;">

    <?php if (!empty($laporanHalamanIni)): ?>
        <?php foreach ($laporanHalamanIni as $data): ?>
            <div class="card-laporan">
                <span class="badge"><?= htmlspecialchars($data['kategori']); ?></span>
                <h3 style="color: #00d4ff; margin: 10px 0;"><?= htmlspecialchars($data['judul']); ?></h3>
                <p style="color: #b0b8d1; font-size: 0.95rem;"><?= nl2br(htmlspecialchars($data['isi'])); ?></p>
                <div style="font-size: 0.75rem; color: #555; margin-top: 15px;">
                    📅 <?= $data['tanggal']; ?> | 🏛️ <?= $data['instansi']; ?> | ID: #<?= $data['id']; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="pagination">
            <?php if ($halamanAktif > 1): ?>
                <a href="?halaman=<?= $halamanAktif - 1 ?>" class="page-link">← Prev</a>
            <?php else: ?>
                <span class="page-link disabled">← Prev</span>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $totalHalaman; $i++): ?>
                <a href="?halaman=<?= $i ?>" class="page-link <?= ($i == $halamanAktif) ? 'active' : '' ?>">
                    <?= $i ?>
                </a>
            <?php endfor; ?>

            <?php if ($halamanAktif < $totalHalaman): ?>
                <a href="?halaman=<?= $halamanAktif + 1 ?>" class="page-link">Next →</a>
            <?php else: ?>
                <span class="page-link disabled">Next →</span>
            <?php endif; ?>
        </div>

    <?php else: ?>
        <p style="text-align: center; color: #8892b0; margin-top: 50px;">Belum ada laporan di halaman ini.</p>
    <?php endif; ?>
</div>

</body>
</html>