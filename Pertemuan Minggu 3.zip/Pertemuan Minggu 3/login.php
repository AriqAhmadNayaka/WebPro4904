<?php 
session_start();
$error = "";
if(isset($_SESSION['error'])){
    $error = $_SESSION['error'];
    unset($_SESSION['error']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk - CyberVault</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #00d4ff;
            --primary-dark: #0099cc;
            --bg: #0a0a0f;
            --card: rgba(15, 15, 35, 0.65);
            --text: #e0e6ed;
            --text-muted: #8892b0;
            --shadow: 0 15px 35px rgba(0, 0, 0, 0.6);
            --glow: 0 0 20px rgba(0, 212, 255, 0.4);
            --radius: 20px;
        }

        *{margin:0;padding:0;box-sizing:border-box;}

        body{
            min-height:100vh;
            font-family:'Poppins',sans-serif;
            background:linear-gradient(135deg,#0a0a0a 0%,#1a1a2e 50%,#16213e 100%);
            color:var(--text);
            padding-top:100px; /* Jarak agar tidak tertutup header fixed */
            display: flex;
            flex-direction: column;
        }

        .main-header{
            position:fixed;
            top:0; left:0; right:0;
            background:rgba(0,0,0,0.9);
            backdrop-filter:blur(15px);
            border-bottom:1px solid rgba(0,212,255,0.3);
            padding:0.8rem 0;
            z-index: 1000;
        }

        .nav-bar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            max-width:1300px;
            margin:auto;
            padding:0 2rem;
        }

        .logo{
            font-size:1.9rem;
            font-weight:800;
            color:var(--primary);
            text-decoration:none;
        }

        .nav-links{
            display:flex; gap:2rem; list-style:none;
        }

        .nav-links a{
            color:var(--text); text-decoration:none; transition: 0.3s;
        }

        .nav-links a:hover{ color: var(--primary); }

        /* Wrapper Form */
        .login-wrapper{
            width:100%;
            max-width:1100px;
            margin:40px auto;
            display:flex;
            gap:40px;
            align-items: stretch;
            flex: 1; /* Membuat konten utama mengisi ruang yang ada */
            padding: 0 20px;
        }

        .image-box{
            flex:1;
            border-radius:20px;
            overflow:hidden;
            box-shadow:var(--shadow);
            border: 1px solid rgba(255,255,255,0.1);
        }

        .image-box img{
            width:100%; height:100%; object-fit:cover;
        }

        .form-box{
            flex:0 0 440px;
            background:var(--card);
            backdrop-filter:blur(20px);
            border-radius:20px;
            padding:40px;
            box-shadow:var(--shadow);
            border: 1px solid rgba(255,255,255,0.1);
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .top{ text-align:center; margin-bottom:25px; }
        .top img{ width:80px; margin-bottom:10px; border-radius: 50%; }

        form{ display:flex; flex-direction:column; gap:18px; }

        .input{
            width:100%;
            padding:16px;
            border-radius:50px;
            border:1px solid rgba(0,212,255,0.3);
            background:rgba(255,255,255,0.05);
            color:white;
            outline: none;
            transition: 0.3s;
        }

        .input:focus { border-color: var(--primary); box-shadow: var(--glow); }

        .btn-login{
            padding:16px;
            border:none;
            border-radius:50px;
            background:linear-gradient(45deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:700;
            cursor:pointer;
            transition: 0.3s;
        }

        .btn-login:hover { transform: translateY(-3px); box-shadow: var(--glow); }

        /* Alerts */
        .error{ background:rgba(255, 60, 60, 0.2); color: #ff9999; padding:12px; border-radius:12px; margin-bottom:15px; text-align:center; border: 1px solid #ff3c3c; }
        .success{ background:rgba(0, 212, 255, 0.15); color: #00d4ff; padding:12px; border-radius:12px; margin-bottom:15px; text-align:center; border: 1px solid var(--primary); }

        /* Footer */
        .cyber-footer {
            background: rgba(5, 5, 15, 0.95);
            border-top: 1px solid rgba(0, 212, 255, 0.2);
            padding: 50px 0 20px;
            margin-top: 60px;
            color: var(--text-muted);
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 2fr 1fr 1fr;
            gap: 40px;
            padding: 0 20px;
        }

        .footer-section h3.footer-logo {
            color: var(--primary);
            font-size: 1.5rem;
            margin-bottom: 15px;
            font-weight: 800;
        }

        .footer-section h4 { color: white; margin-bottom: 20px; }
        .footer-section ul { list-style: none; }
        .footer-section ul li { margin-bottom: 10px; display: flex; align-items: center; gap: 10px; }
        .social-links { display: flex; flex-direction: column; gap: 10px; }
        .social-item { color: var(--text-muted); text-decoration: none; transition: 0.3s; }
        .social-item:hover { color: var(--primary); padding-left: 5px; }
        .footer-bottom { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); font-size: 0.8rem; }

        @media (max-width: 992px) {
            .login-wrapper { flex-direction: column; align-items: center; }
            .image-box { display: none; }
            .form-box { flex: 1; width: 100%; max-width: 500px; }
        }

        @media (max-width: 768px) {
            .footer-container { grid-template-columns: 1fr; text-align: center; }
            .footer-section ul li { justify-content: center; }
        }
    </style>
</head>
<body>

<header class="main-header">
    <nav class="nav-bar">
        <a href="HomePage.html" class="logo">CyberVault</a>
        <ul class="nav-links">
            <li><a href="HomePage.html">Home</a></li>
            <li><a href="About.html">About</a></li>
        </ul>
    </nav>
</header>

<div class="login-wrapper">
    <div class="image-box">
        <img src="cybersecurity_NicoElNino-AlamyStockPhoto.jpg" alt="Login Background">
    </div>

    <div class="form-box">
        <div class="top">
            <img src="0x0-1024x576 (1).webp" alt="Logo CyberVault">
            <h2>CyberVault</h2>
            <p>Masuk ke akun Anda</p>
        </div>

        <?php if(isset($_SESSION['success'])){ ?>
            <div class="success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php } ?>

        <?php if($error!=""){ ?>
            <div class="error"><?= $error ?></div>
        <?php } ?>

        <form method="POST" action="proseslogin.php">
            <div style="display: flex; gap: 20px; justify-content: center; margin-bottom: 5px; background: rgba(255,255,255,0.05); padding: 10px; border-radius: 50px; border: 1px solid rgba(0,212,255,0.2);">
                <label style="cursor:pointer;"><input type="radio" name="role" value="user" checked> User</label>
                <label style="cursor:pointer;"><input type="radio" name="role" value="admin"> Admin</label>
            </div>
            
            <input type="email" name="email" class="input" placeholder="Email" required>
            <input type="password" name="password" class="input" placeholder="Password" required>
            
            <button type="submit" name="submit" class="btn-login">Masuk Sekarang</button>
        </form>

        <p style="margin-top:20px; text-align:center; font-size: 0.9rem;">
            Belum punya akun? <a href="Registrasi.php" style="color:var(--primary); text-decoration:none; font-weight:600;">Daftar disini</a>
        </p>
    </div>
</div>

<footer class="cyber-footer">
    <div class="footer-container">
        <div class="footer-section">
            <h3 class="footer-logo">CyberVault</h3>
            <p>Platform edukasi keamanan siber terpercaya untuk melindungi data dan privasi Anda di era digital.</p>
        </div>
        <div class="footer-section">
            <h4>Contact Us</h4>
            <ul>
                <li>📍 Bandung, Indonesia</li>
                <li>📧 support@cybervault.id</li>
            </ul>
        </div>
        <div class="footer-section">
            <h4>Follow Us</h4>
            <div class="social-links">
                <a href="#" class="social-item">Instagram</a>
                <a href="#" class="social-item">GitHub</a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2026 CyberVault Project - Kelompok 10 SIKC. All Rights Reserved.</p>
    </div>
</footer>

</body>
</html>