<?php
session_start();

if (isset($_POST['submit'])) {
    $email    = $_POST['email'];
    $password = $_POST['password'];
    $role     = $_POST['role'];

    
    $user_email = "user@gmail.com";
    $user_pass  = "123456";
    $admin_email = "admin@gmail.com";
    $admin_pass  = "admin123";

    if($role == "user") {
        $is_reg_user = (isset($_SESSION['registered_user']) && 
                        $email == $_SESSION['registered_user']['email'] && 
                        $password == $_SESSION['registered_user']['password']);

        if(($email == $user_email && $password == $user_pass) || $is_reg_user) {
            $_SESSION['login'] = true;
            $_SESSION['role'] = "user";
            header("Location: HomePage.html");
            exit;
        } else {
            $_SESSION['error'] = "Email atau password user salah";
            header("Location: login.php");
            exit;
        }
    }

    if($role == "admin") {
        if($email == $admin_email && $password == $admin_pass) {
            $_SESSION['login'] = true;
            $_SESSION['role'] = "admin";
            header("Location: verifikasi2fa.html");
            exit;
        } else {
            $_SESSION['error'] = "Email atau password admin salah";
            header("Location: login.php");
            exit;
        }
    }
}
?>