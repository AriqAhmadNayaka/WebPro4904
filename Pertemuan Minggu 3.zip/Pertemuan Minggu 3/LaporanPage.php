<?php session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporkan Penipuan Online - CyberAlert ID</title>
    <link rel="stylesheet" href="HomePage.css">
    <style>
        .kirim-btn, .riwayat-btn {
            display: inline-block;
            padding: 0.6rem 1.4rem;
            border-radius: 30px;
            border: 1px solid rgba(0,212,255,0.35);
            background: rgba(0,212,255,0.08);
            color: #00d4ff;
            font-size: 0.85rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
            outline: none;
        }

        .kirim-btn:hover, .riwayat-btn:hover {
            background: rgba(0,212,255,0.18);
            box-shadow: 0 0 15px rgba(0,212,255,0.4);
            border-color: rgba(0,212,255,0.6);
            transform: translateY(-2px);
        }

        .button-group {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            margin-top: 1.5rem;
        }

        .alert {
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 15px;
            text-align: center;
        }
    </style>
</head>
<body>

<header class="main-header">
    <nav class="nav-bar">
        <div class="logo">CyberVault</div>
        <a href="HomePage.html" style="padding:0.7rem 1.6rem; border-radius:30px; text-decoration:none; font-weight:600; font-size:0.85rem; color:#00d4ff; border:1px solid rgba(0,212,255,0.35); background:rgba(0,212,255,0.08); transition:all 0.3s ease;">
            ← Kembali ke Home
        </a>
    </nav>
</header>

<section class="report-hero">
    <div class="report-form-container">
        <h2>Sampaikan Laporan Anda</h2>

        <?php if(isset($_SESSION['success_laporan'])): ?>
            <div class="alert" style="background:rgba(0, 212, 255, 0.15); color:#00d4ff; border:1px solid #00d4ff;">
                <?= $_SESSION['success_laporan']; unset($_SESSION['success_laporan']); ?>
            </div>
        <?php endif; ?>

        <form action="proseslaporan.php" method="POST">
            <div class="form-group">
                <label for="judul">Judul Laporan *</label>
                <input type="text" name="judul" id="judul" placeholder="Judul Laporan" required>
            </div>
            <div class="form-group">
                <label for="isi">Isi Laporan *</label>
                <textarea name="isi" id="isi" rows="5" placeholder="Jelaskan kronologi penipuan" required></textarea>
            </div>
            <div class="form-group">
                <label for="tanggal">Tanggal Kejadian *</label>
                <input type="date" name="tanggal" id="tanggal" required>
            </div>
            <div class="form-group">
                <label for="lokasi">Lokasi Kejadian *</label>
                <input type="text" name="lokasi" id="lokasi" placeholder="Lokasi Kejadian" required>
            </div>
            <div class="form-group">
                <label for="instansi">Instansi Tujuan *</label>
                <select name="instansi" id="instansi" required>
                    <option value="">Pilih Instansi Tujuan</option>
                    <option>Patroli Siber Polri</option>
                    <option>Otoritas Jasa Keuangan (OJK)</option>
                    <option>Kementerian Kominfo</option>
                </select>
            </div>
            <div class="form-group">
                <label for="kategori">Kategori Laporan</label>
                <select name="kategori" id="kategori">
                    <option>Penipuan Belanja Online</option>
                    <option>Phishing / Link Palsu</option>
                    <option>Investasi Bodong</option>
                </select>
            </div>

            <div class="button-group">
                <button type="submit" name="submit_laporan" class="kirim-btn">Kirim Laporan</button>
                <a href="DaftarLaporan.php" class="riwayat-btn">Lihat Riwayat Laporan</a>
            </div>
        </form>
    </div>
</section>
</body>
</html>