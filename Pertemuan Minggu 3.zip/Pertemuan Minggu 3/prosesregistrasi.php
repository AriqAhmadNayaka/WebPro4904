<?php
session_start();

if (isset($_POST['register'])) {
    $nama     = $_POST['nama'];
    $email    = $_POST['email'];
    $password = $_POST['password'];
    $confirm  = $_POST['confirm_password'];

    if($password !== $confirm) {
        $_SESSION['error'] = "Konfirmasi password tidak sesuai!";
        header("Location: Registrasi.php");
        exit;
    }

    if(empty($email) || empty($password) || empty($nama)) {
        $_SESSION['error'] = "Semua data wajib diisi!";
        header("Location: Registrasi.php");
        exit;
    }

    $_SESSION['registered_user'] = [
        'nama'     => $nama,
        'email'    => $email,
        'password' => $password
    ];

    $_SESSION['success'] = "Akun berhasil dibuat! Silakan masuk.";
    header("Location: login.php"); 
    exit;
}
?>