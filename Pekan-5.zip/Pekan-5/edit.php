<?php
session_start();
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }

$conn = mysqli_connect("localhost", "root", "", "cybervault");

if (!$conn) { die("Koneksi gagal: " . mysqli_connect_error()); }

if (!isset($_GET['id'])) { header("Location: datauser.php"); exit; }

$id = $_GET['id'];

// Ambil data user lama
$query = "SELECT * FROM datauser WHERE id = $id";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    echo "<script>alert('Data tidak ditemukan!'); window.location.href='datauser.php';</script>";
    exit;
}

if (isset($_POST['update'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    // Ambil info file foto baru
    $namaFile = $_FILES['foto']['name'];
    $tmpName  = $_FILES['foto']['tmp_name'];
    $errorFile = $_FILES['foto']['error'];

    // Cek apakah user mengupload foto baru?
    if ($errorFile === 4) {
        // Jika tidak upload baru, gunakan foto lama
        $fotoFinal = $data['foto'];
    } else {
        // Jika upload baru, proses filenya
        $ekstensiValid = ['jpg', 'jpeg', 'png'];
        $ekstensiFile = strtolower(pathinfo($namaFile, PATHINFO_EXTENSION));

        if (!in_array($ekstensiFile, $ekstensiValid)) {
            echo "<script>alert('Format file tidak didukung!');</script>";
            $fotoFinal = $data['foto'];
        } else {
            // Hapus foto lama dari folder img (kecuali jika itu default.png)
            if ($data['foto'] != 'default.png' && file_exists('img/' . $data['foto'])) {
                unlink('img/' . $data['foto']);
            }
            
            // Generate nama baru dan pindahkan
            $fotoFinal = uniqid() . '.' . $ekstensiFile;
            move_uploaded_file($tmpName, 'img/' . $fotoFinal);
        }
    }

    $updateQuery = "UPDATE datauser SET nama='$nama', email='$email', foto='$fotoFinal' WHERE id=$id";
    
    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('Data berhasil diperbarui!'); window.location.href='datauser.php';</script>";
    } else {
        echo "Gagal: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit User • CyberVault</title>
    <style>
        body { font-family: 'Poppins', sans-serif; background: #0a0a0f; color: #fff; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .edit-container { background: rgba(255, 255, 255, 0.05); padding: 30px; border-radius: 15px; border: 1px solid #00d4ff; width: 100%; max-width: 400px; }
        h2 { color: #00d4ff; text-align: center; }
        label { display: block; margin-top: 15px; font-size: 14px; color: #8892b0; }
        input { width: 100%; padding: 12px; margin-top: 5px; background: #1a1a2e; border: 1px solid #333; border-radius: 8px; color: #fff; box-sizing: border-box; }
        .current-foto { text-align: center; margin-bottom: 20px; }
        .img-edit { width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 2px solid #00d4ff; }
        .btn-save { width: 100%; padding: 12px; background: #00d4ff; border: none; border-radius: 8px; color: #000; font-weight: bold; cursor: pointer; margin-top: 25px; }
        .btn-back { display: block; text-align: center; margin-top: 15px; color: #8892b0; text-decoration: none; font-size: 13px; }
    </style>
</head>
<body>

    <div class="edit-container">
        <h2>Edit Data User</h2>
        
        <div class="current-foto">
            <img src="img/<?= $data['foto']; ?>" class="img-edit">
            <p style="font-size: 12px; color: #8892b0;">Foto Saat Ini</p>
        </div>
    
        <form action="" method="POST" enctype="multipart/form-data">
            <label>Nama Lengkap</label>
            <input type="text" name="nama" value="<?= htmlspecialchars($data['nama']); ?>" required>

            <label>Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($data['email']); ?>" required>

            <label>Ganti Foto (Kosongkan jika tidak ingin ganti)</label>
            <input type="file" name="foto">

            <button type="submit" name="update" class="btn-save">Simpan Perubahan</button>
            <a href="datauser.php" class="btn-back">Batal dan Kembali</a>
        </form>
    </div>

</body>
</html>