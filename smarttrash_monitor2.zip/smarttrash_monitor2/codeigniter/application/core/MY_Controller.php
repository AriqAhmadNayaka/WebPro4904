<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'third_party/MX/Controller.php';

class MY_Controller extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->bootstrap_database();
    }

    protected function bootstrap_database()
    {
        $host = '127.0.0.1';
        $user = 'root';
        $pass = '';
        $port = 3306;
        $database = 'smarttrash_monitor2';

        mysqli_report(MYSQLI_REPORT_OFF);

        try {
            $mysqli = new mysqli($host, $user, $pass, '', $port);
        } catch (Exception $e) {
            return;
        }

        if ($mysqli->connect_error) {
            return;
        }

        $mysqli->query("CREATE DATABASE IF NOT EXISTS `{$database}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
        $mysqli->close();

        if (!isset($this->db) || !$this->db->conn_id) {
            $this->load->database();
        }

        $this->db->query("
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
                photo VARCHAR(255) DEFAULT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
        ");

        $this->db->query("
            CREATE TABLE IF NOT EXISTS trash_bins (
                id INT AUTO_INCREMENT PRIMARY KEY,
                bin_code VARCHAR(30) NOT NULL UNIQUE,
                location_name VARCHAR(120) NOT NULL,
                waste_level TINYINT UNSIGNED NOT NULL DEFAULT 0,
                status ENUM('AMAN', 'WASPADA', 'PENUH', 'DIANGKUT') NOT NULL DEFAULT 'AMAN',
                last_collection DATETIME DEFAULT NULL,
                notes TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
        ");

        $this->db->query("
            CREATE TABLE IF NOT EXISTS waste_categories (
                id INT AUTO_INCREMENT PRIMARY KEY,
                category_name VARCHAR(100) NOT NULL UNIQUE,
                category_slug VARCHAR(120) NOT NULL UNIQUE,
                description TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
        ");

        $this->db->query("
            CREATE TABLE IF NOT EXISTS catalog_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                category_id INT NOT NULL,
                item_name VARCHAR(120) NOT NULL,
                item_type VARCHAR(80) NOT NULL,
                item_condition ENUM('Layak Daur Ulang', 'Perlu Dibersihkan', 'Residu') NOT NULL DEFAULT 'Layak Daur Ulang',
                example_photo VARCHAR(255) DEFAULT NULL,
                notes TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                CONSTRAINT fk_catalog_category
                    FOREIGN KEY (category_id) REFERENCES waste_categories(id)
                    ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
        ");

        $admin_name = $this->db->escape('Administrator Utama');
        $admin_email = $this->db->escape('admin@cybervault.com');
        $admin_password = $this->db->escape(password_hash('admin123', PASSWORD_DEFAULT));

        $this->db->query("
            INSERT INTO users (name, email, password, role, photo)
            VALUES ({$admin_name}, {$admin_email}, {$admin_password}, 'admin', NULL)
            ON DUPLICATE KEY UPDATE
                role = VALUES(role),
                name = name
        ");

        $default_bins = array(
            array('BIN-001', 'Lobby Kampus', 35, 'AMAN', NULL, 'Kondisi normal.'),
            array('BIN-002', 'Area Parkir Timur', 78, 'WASPADA', NULL, 'Perlu dicek sore ini.'),
            array('BIN-003', 'Kantin Utama', 95, 'PENUH', NULL, 'Prioritas pengangkutan.')
        );

        foreach ($default_bins as $bin) {
            $bin_code = $this->db->escape($bin[0]);
            $location_name = $this->db->escape($bin[1]);
            $waste_level = (int) $bin[2];
            $status = $this->db->escape($bin[3]);
            $last_collection = $bin[4] === NULL ? 'NULL' : $this->db->escape($bin[4]);
            $notes = $bin[5] === NULL ? 'NULL' : $this->db->escape($bin[5]);

            $this->db->query("
                INSERT INTO trash_bins (bin_code, location_name, waste_level, status, last_collection, notes)
                VALUES ({$bin_code}, {$location_name}, {$waste_level}, {$status}, {$last_collection}, {$notes})
                ON DUPLICATE KEY UPDATE
                    location_name = VALUES(location_name),
                    waste_level = VALUES(waste_level),
                    status = VALUES(status),
                    notes = VALUES(notes)
            ");
        }

        $default_categories = array(
            array('Organik', 'Sampah yang mudah terurai seperti sisa makanan, daun, dan kulit buah.'),
            array('Non Organik', 'Sampah anorganik seperti botol plastik, kaleng, dan kemasan.'),
            array('B3', 'Sampah bahan berbahaya dan beracun seperti baterai dan lampu bekas.')
        );

        foreach ($default_categories as $category) {
            $name = trim($category[0]);
            $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $name));
            $description = $category[1];

            $this->db->query("
                INSERT INTO waste_categories (category_name, category_slug, description)
                VALUES (" . $this->db->escape($name) . ", " . $this->db->escape($slug) . ", " . $this->db->escape($description) . ")
                ON DUPLICATE KEY UPDATE
                    description = VALUES(description),
                    category_name = VALUES(category_name)
            ");
        }

        $default_items = array(
            array('Organik', 'Sisa Nasi', 'Sisa Makanan', 'Layak Daur Ulang', 'Bisa masuk komposter.'),
            array('Non Organik', 'Botol Plastik', 'Plastik PET', 'Perlu Dibersihkan', 'Bilas sebelum didaur ulang.'),
            array('B3', 'Baterai Bekas', 'Limbah Elektronik', 'Residu', 'Simpan di wadah khusus B3.')
        );

        foreach ($default_items as $item) {
            $category = $this->db->get_where('waste_categories', array('category_name' => $item[0]))->row_array();
            if (!$category) {
                continue;
            }

            $exists = $this->db
                ->get_where('catalog_items', array(
                    'category_id' => $category['id'],
                    'item_name' => $item[1]
                ))
                ->row_array();

            if ($exists) {
                continue;
            }

            $this->db->insert('catalog_items', array(
                'category_id' => $category['id'],
                'item_name' => $item[1],
                'item_type' => $item[2],
                'item_condition' => $item[3],
                'notes' => $item[4]
            ));
        }

        $upload_path = FCPATH . 'uploads';
        if (!is_dir($upload_path)) {
            @mkdir($upload_path, 0755, TRUE);
        }

        $profile_path = FCPATH . 'uploads/profiles';
        if (!is_dir($profile_path)) {
            @mkdir($profile_path, 0755, TRUE);
        }

        $posts_path = FCPATH . 'uploads/posts';
        if (!is_dir($posts_path)) {
            @mkdir($posts_path, 0755, TRUE);
        }

        $items_path = FCPATH . 'uploads/items';
        if (!is_dir($items_path)) {
            @mkdir($items_path, 0755, TRUE);
        }
    }

    protected function json_response($payload, $status_code = 200)
    {
        return $this->output
            ->set_status_header($status_code)
            ->set_content_type('application/json', 'utf-8')
            ->set_output(json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    protected function request_data()
    {
        $content_type = $this->input->server('CONTENT_TYPE');
        $raw = trim($this->input->raw_input_stream);
        $server_method = strtoupper((string) $this->input->server('REQUEST_METHOD', TRUE));

        if ($raw !== '' && stripos((string) $content_type, 'application/json') !== FALSE) {
            $decoded = json_decode($raw, TRUE);
            return is_array($decoded) ? $decoded : array();
        }

        if ($server_method === 'POST') {
            $post_data = $this->input->post(NULL, TRUE);
            if (!empty($post_data)) {
                return $post_data;
            }
        }

        if ($this->request_method() === 'GET') {
            return $this->input->get(NULL, TRUE) ?: array();
        }

        if ($this->request_method() === 'POST') {
            return $this->input->post(NULL, TRUE) ?: array();
        }

        if ($raw !== '') {
            $parsed = array();
            parse_str($raw, $parsed);
            return $parsed;
        }

        return array();
    }

    protected function request_method()
    {
        $method = $this->input->server('HTTP_X_HTTP_METHOD_OVERRIDE', TRUE);

        if (!$method) {
            $method = $this->input->post('_method', TRUE);
        }

        if (!$method) {
            $method = $this->input->server('REQUEST_METHOD', TRUE);
        }

        if (!$method) {
            $method = 'GET';
        }

        return strtoupper($method);
    }

    protected function is_logged_in()
    {
        return (bool) $this->session->userdata('logged_in');
    }

    protected function current_user()
    {
        return array(
            'id' => $this->session->userdata('user_id'),
            'name' => $this->session->userdata('name'),
            'email' => $this->session->userdata('email'),
            'role' => $this->session->userdata('role')
        );
    }

    protected function require_login()
    {
        if (!$this->is_logged_in()) {
            redirect('auth');
        }
    }

    protected function require_admin()
    {
        $this->require_login();

        if ($this->session->userdata('role') !== 'admin') {
            redirect('dashboard');
        }
    }
}
