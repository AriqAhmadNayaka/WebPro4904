-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2026 at 07:33 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smarttrash_monitor2`
--

-- --------------------------------------------------------

--
-- Table structure for table `catalog_items`
--

CREATE TABLE `catalog_items` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `item_name` varchar(120) NOT NULL,
  `item_type` varchar(80) NOT NULL,
  `item_condition` enum('Layak Daur Ulang','Perlu Dibersihkan','Residu') NOT NULL DEFAULT 'Layak Daur Ulang',
  `example_photo` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `catalog_items`
--

INSERT INTO `catalog_items` (`id`, `category_id`, `item_name`, `item_type`, `item_condition`, `example_photo`, `notes`, `created_at`, `updated_at`) VALUES
(7, 316, 'Baterai Bekas', 'Limbah Elektronik', 'Residu', NULL, 'Simpan di wadah khusus B3.', '2026-06-04 04:47:27', '2026-06-04 04:47:27'),
(15, 377, 'Sisa Nasi', 'Sisa Makanan', 'Layak Daur Ulang', NULL, 'Bisa masuk komposter.', '2026-06-04 04:52:21', '2026-06-04 04:52:21'),
(18, 2, 'Stasiun Buaran', '30', 'Layak Daur Ulang', 'cd1faf2646af907164ebb1e1d912315d.png', 'Laporan terkini, di stasiun buaran terpantgau udara baik', '2026-06-04 04:58:56', '2026-06-04 05:07:56'),
(20, 591, 'Botol Plastik', 'Plastik PET', 'Perlu Dibersihkan', NULL, 'Bilas sebelum didaur ulang.', '2026-06-04 05:27:12', '2026-06-04 05:27:12'),
(21, 592, 'Baterai Bekas', 'Limbah Elektronik', 'Residu', NULL, 'Simpan di wadah khusus B3.', '2026-06-04 05:27:12', '2026-06-04 05:27:12'),
(22, 592, 'Manggarai', '50', 'Layak Daur Ulang', '6077b8aefb9cb2f7dea2134aaf0e8480.png', 'banyak kendaraan', '2026-06-04 05:31:05', '2026-06-04 05:31:05');

-- --------------------------------------------------------

--
-- Table structure for table `trash_bins`
--

CREATE TABLE `trash_bins` (
  `id` int(11) NOT NULL,
  `bin_code` varchar(30) NOT NULL,
  `location_name` varchar(120) NOT NULL,
  `waste_level` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `status` enum('AMAN','WASPADA','PENUH','DIANGKUT') NOT NULL DEFAULT 'AMAN',
  `last_collection` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trash_bins`
--

INSERT INTO `trash_bins` (`id`, `bin_code`, `location_name`, `waste_level`, `status`, `last_collection`, `notes`, `created_at`, `updated_at`) VALUES
(1, 'BIN-001', 'Lobby Kampus', 35, 'AMAN', NULL, 'Kondisi normal.', '2026-06-04 02:34:39', '2026-06-04 02:34:39'),
(2, 'BIN-002', 'Area Parkir Timur', 78, 'WASPADA', NULL, 'Perlu dicek sore ini.', '2026-06-04 02:34:39', '2026-06-04 02:34:39'),
(3, 'BIN-003', 'Kantin Utama', 95, 'PENUH', NULL, 'Prioritas pengangkutan.', '2026-06-04 02:34:39', '2026-06-04 02:34:39');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `photo`) VALUES
(1, 'Administrator Utama', 'admin@cybervault.com', '$2y$10$q3K5AhOmxOGK9H/HAn3mzOBMz41bI5kaNg7KJcmvLol18TlnBNUMO', 'admin', NULL),
(7, 'wisnu shantika', 'wisnushantika@gmail.com', '$2y$10$NaCwXrL069s1lP89Of.AmekZfP1yxAU5VowURbOnerrgDgf00vHfq', 'user', NULL),
(27, 'Pablo', 'pablomorino32@gmail.com', '$2y$10$ivnbu2fKLSq9AOXZ7vEWyOmexZrXgrt.i/RukJFQyVzjOmzRY5zxq', 'user', NULL),
(218, 'Asep', 'Asep@gmail.com', '$2y$10$aDJn3tnStswdpgEq62/LgOoCEeZmUXN1wSFN30TECdX3zW0FXVwR.', 'user', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `waste_categories`
--

CREATE TABLE `waste_categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_slug` varchar(120) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `waste_categories`
--

INSERT INTO `waste_categories` (`id`, `category_name`, `category_slug`, `description`, `created_at`, `updated_at`) VALUES
(2, 'Buaran', 'buaran', 'Banyak pabrik', '2026-06-04 03:31:34', '2026-06-04 04:49:14'),
(316, 'Jatinegara', 'jatinegara', 'Lalu lintas padat, ada pembakaran sampah', '2026-06-04 04:47:27', '2026-06-04 04:48:39'),
(377, 'Organik', 'organik', 'Sampah yang mudah terurai seperti sisa makanan, daun, dan kulit buah.', '2026-06-04 04:52:21', '2026-06-04 04:52:21'),
(591, 'Non Organik', 'non-organik', 'Sampah anorganik seperti botol plastik, kaleng, dan kemasan.', '2026-06-04 05:27:12', '2026-06-04 05:27:12'),
(592, 'B3', 'b3', 'Sampah bahan berbahaya dan beracun seperti baterai dan lampu bekas.', '2026-06-04 05:27:12', '2026-06-04 05:27:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `catalog_items`
--
ALTER TABLE `catalog_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_catalog_category` (`category_id`);

--
-- Indexes for table `trash_bins`
--
ALTER TABLE `trash_bins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bin_code` (`bin_code`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `waste_categories`
--
ALTER TABLE `waste_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_name` (`category_name`),
  ADD UNIQUE KEY `category_slug` (`category_slug`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `catalog_items`
--
ALTER TABLE `catalog_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `trash_bins`
--
ALTER TABLE `trash_bins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=667;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;

--
-- AUTO_INCREMENT for table `waste_categories`
--
ALTER TABLE `waste_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=632;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `catalog_items`
--
ALTER TABLE `catalog_items`
  ADD CONSTRAINT `fk_catalog_category` FOREIGN KEY (`category_id`) REFERENCES `waste_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
