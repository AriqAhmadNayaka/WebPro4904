

CREATE DATABASE IF NOT EXISTS `lifetrack_ci3` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `lifetrack_ci3`;

-- --------------------------------------------------------
-- --------------------------------------------------------
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'pasien',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`nama`, `email`, `password`, `role`) VALUES
('Admin', 'admin@lifetrack.id', '$2y$10$E9M2XQv1X3hZqKzN.8h5UO7V2bN1jW9qYxZsRtQ8YxXzKfLmNpOrC', 'tenaga_medis');

-- --------------------------------------------------------
-- --------------------------------------------------------
CREATE TABLE `data_pasien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(150) NOT NULL,
  `usia` int(11) NOT NULL,
  `keluhan` text DEFAULT NULL,
  `dokumen` varchar(255) DEFAULT NULL,
  `tanggal` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
