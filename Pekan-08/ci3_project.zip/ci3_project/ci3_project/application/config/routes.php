<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Auth';

// rute auth
$route['login']        = 'Auth/login';
$route['proses_login'] = 'Auth/proses_login';
$route['registrasi']   = 'Auth/registrasi';
$route['proses_daftar']= 'Auth/proses_daftar';
$route['logout']       = 'Auth/logout';

$route['beranda']              = 'Pasien/index';
$route['pasien/tambah']        = 'Pasien/tambah';
$route['pasien/edit/(:num)']   = 'Pasien/edit/$1';
$route['pasien/hapus/(:num)']  = 'Pasien/hapus/$1';
$route['pasien/simpan']        = 'Pasien/simpan';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
