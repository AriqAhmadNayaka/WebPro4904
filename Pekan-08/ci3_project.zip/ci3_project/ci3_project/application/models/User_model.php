<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    private $tabel = 'users';

    // cari user berdasarkan email (buat login)
    public function cari_by_email($email)
    {
        return $this->db->get_where($this->tabel, ['email' => $email])->row();
    }

    // daftar akun baru
    public function daftar($data)
    {
        return $this->db->insert($this->tabel, $data);
    }
}
