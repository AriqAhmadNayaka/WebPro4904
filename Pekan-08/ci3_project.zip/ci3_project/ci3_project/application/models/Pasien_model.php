<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien_model extends CI_Model {

    private $tabel = 'data_pasien';

    // ambil semua data pasien, urut dari yang terbaru
    public function semua()
    {
        $this->db->order_by('id', 'DESC');
        return $this->db->get($this->tabel)->result();
    }

    // cari satu data berdasarkan id
    public function cari($id)
    {
        return $this->db->get_where($this->tabel, ['id' => $id])->row();
    }

    // tambah data baru
    public function tambah($data)
    {
        return $this->db->insert($this->tabel, $data);
    }

    // update data
    public function ubah($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update($this->tabel, $data);
    }

    // hapus data
    public function hapus($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete($this->tabel);
    }
}
