<?php $this->load->view('templates/header', ['title' => 'LifeTrack - Registrasi']); ?>

<div class="auth-wrapper">
    <div class="auth-card">
        <h2>Buat Akun</h2>
        <p>Daftar untuk mulai menggunakan LifeTrack</p>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert-error"><?php echo $this->session->flashdata('error'); ?></div>
        <?php endif; ?>

        <?php echo form_open('proses_daftar'); ?>
            <div class="form-group">
                <label>Daftar sebagai</label>
                <select name="role" required>
                    <option value="">-- Pilih Peran --</option>
                    <option value="pasien">Pasien</option>
                    <option value="tenaga_medis">Tenaga Medis</option>
                </select>
            </div>
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" name="nama" placeholder="Masukkan nama lengkap" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="Masukkan email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Minimal 6 karakter" minlength="6" required>
            </div>
            <button type="submit" class="btn">Buat Akun</button>
        <?php echo form_close(); ?>

        <div class="auth-link">
            Sudah punya akun? <a href="<?php echo site_url('login'); ?>">Login</a>
        </div>
    </div>
</div>

<?php $this->load->view('templates/footer'); ?>
