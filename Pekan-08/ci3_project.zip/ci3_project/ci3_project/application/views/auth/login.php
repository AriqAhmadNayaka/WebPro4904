<?php $this->load->view('templates/header', ['title' => 'LifeTrack - Login']); ?>

<div class="auth-wrapper">
    <div class="auth-card">
        <h2>Selamat Datang</h2>
        <p>Masuk untuk melanjutkan ke LifeTrack</p>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert-success"><?php echo $this->session->flashdata('success'); ?></div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert-error"><?php echo $this->session->flashdata('error'); ?></div>
        <?php endif; ?>

        <?php echo form_open('proses_login'); ?>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="Masukkan email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Masukkan password" required>
            </div>
            <button type="submit" class="btn">Login</button>
        <?php echo form_close(); ?>

        <div class="auth-link">
            Belum punya akun? <a href="<?php echo site_url('registrasi'); ?>">Buat Akun</a>
        </div>
    </div>
</div>

<?php $this->load->view('templates/footer'); ?>
