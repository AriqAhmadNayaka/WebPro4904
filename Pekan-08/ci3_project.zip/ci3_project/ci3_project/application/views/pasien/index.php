<?php $this->load->view('templates/header', ['title' => 'LifeTrack - Beranda']); ?>

<nav class="navbar">
    <div class="logo">
        <span class="bulb"></span>
        LifeTrack
    </div>
    <div class="nav-right">
        <span><?php echo htmlspecialchars($user_nama); ?></span>
        <a href="<?php echo site_url('logout'); ?>">Logout</a>
    </div>
</nav>

<div class="konten">

    <h1>Halo, <?php echo htmlspecialchars($user_nama); ?></h1>
    <p class="sub">Selamat datang kembali di LifeTrack</p>

    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert-success" style="max-width:700px;"><?php echo $this->session->flashdata('success'); ?></div>
    <?php endif; ?>
    <?php if ($this->session->flashdata('error')): ?>
        <div class="alert-error" style="max-width:700px;"><?php echo $this->session->flashdata('error'); ?></div>
    <?php endif; ?>

    <div class="boxes">
        <div class="box">
            <h3>Input Data Pasien</h3>
            <p>Masukkan data pasien baru</p>
            <a href="#form-input">Input Data</a>
        </div>
        <div class="box">
            <h3>Daftar Pasien</h3>
            <p><?php echo count($data_pasien); ?> data pasien</p>
            <a href="#tabel-pasien">Lihat Daftar</a>
        </div>
        <div class="box">
            <h3>Jadwal</h3>
            <p><?php echo date('d F Y'); ?></p>
            <a href="#">Lihat Detail</a>
        </div>
        <div class="box">
            <h3>Nutrisi dan Gizi</h3>
            <p>Panduan nutrisi pasien</p>
            <a href="#">Lihat Detail</a>
        </div>
    </div>

    <!-- form CRUD + upload -->
    <div class="form-box" id="form-input">
        <h3><?php echo $edit ? 'Edit Data Pasien' : 'Input Data Pasien'; ?></h3>

        <?php echo form_open_multipart('pasien/simpan'); ?>
            <?php if ($edit): ?>
                <input type="hidden" name="id" value="<?php echo $edit->id; ?>">
            <?php endif; ?>

            <div class="form-group">
                <label>Nama Pasien</label>
                <input type="text" name="nama" placeholder="Masukkan nama pasien"
                       value="<?php echo $edit ? htmlspecialchars($edit->nama) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Usia</label>
                <input type="number" name="usia" placeholder="Masukkan usia"
                       value="<?php echo $edit ? $edit->usia : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Keluhan</label>
                <textarea name="keluhan" placeholder="Tuliskan keluhan pasien..." required><?php echo $edit ? htmlspecialchars($edit->keluhan) : ''; ?></textarea>
            </div>
            <div class="form-group">
                <label>Upload Dokumen (JPG, PNG, PDF - Max 5MB)</label>
                <input type="file" name="dokumen" accept="image/*,.pdf">
                <?php if ($edit && $edit->dokumen): ?>
                    <small>File saat ini:
                        <a href="<?php echo base_url('uploads/pasien/' . $edit->dokumen); ?>" target="_blank">
                            <?php echo htmlspecialchars($edit->dokumen); ?>
                        </a> (kosongkan jika tidak ganti)
                    </small>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn-submit">Simpan Data</button>
            <?php if ($edit): ?>
                <a href="<?php echo site_url('beranda'); ?>" class="btn-submit"
                   style="background:#888;text-decoration:none;display:inline-block;text-align:center;margin-left:8px;">Batal</a>
            <?php endif; ?>
        <?php echo form_close(); ?>
    </div>

    <!-- tabel daftar pasien -->
    <div class="tabel-box" id="tabel-pasien" style="max-width:100%;">
        <h3>Daftar Pasien (<?php echo count($data_pasien); ?> data)</h3>

        <?php if (count($data_pasien) == 0): ?>
            <p class="kosong">Belum ada data pasien.</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Usia</th>
                    <th>Keluhan</th>
                    <th>Tanggal</th>
                    <th>Dokumen</th>
                    <th>Aksi</th>
                </tr>
                <?php foreach ($data_pasien as $i => $p): ?>
                    <tr>
                        <td><?php echo $i + 1; ?></td>
                        <td><?php echo htmlspecialchars($p->nama); ?></td>
                        <td><?php echo $p->usia; ?> thn</td>
                        <td><?php echo htmlspecialchars($p->keluhan); ?></td>
                        <td><?php echo date('d-m-Y', strtotime($p->tanggal)); ?></td>
                        <td>
                            <?php if ($p->dokumen && file_exists('./uploads/pasien/' . $p->dokumen)): ?>
                                <a href="<?php echo base_url('uploads/pasien/' . $p->dokumen); ?>" target="_blank">Lihat</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo site_url('pasien/edit/' . $p->id); ?>#form-input" class="btn-edit">Edit</a>
                            <a href="<?php echo site_url('pasien/hapus/' . $p->id); ?>"
                               class="btn-hapus"
                               onclick="return confirm('Hapus data ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>

</div>

<?php $this->load->view('templates/footer'); ?>
