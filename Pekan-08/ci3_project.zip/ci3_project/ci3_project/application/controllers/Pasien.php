<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Pasien_model');

        // cek login - kalau belum login tendang ke halaman login
        if ($this->session->userdata('login') !== TRUE) {
            redirect('login');
        }
    }

    // halaman beranda / dashboard - tampilin semua data
    public function index()
    {
        $data['user_nama']   = $this->session->userdata('user_nama');
        $data['data_pasien'] = $this->Pasien_model->semua();
        $data['edit']        = NULL;
        $this->load->view('pasien/index', $data);
    }

    // form edit - isi form dengan data lama
    public function edit($id)
    {
        $data['user_nama']   = $this->session->userdata('user_nama');
        $data['data_pasien'] = $this->Pasien_model->semua();
        $data['edit']        = $this->Pasien_model->cari($id);
        $this->load->view('pasien/index', $data);
    }

    // hapus data + file dokumennya
    public function hapus($id)
    {
        $pasien = $this->Pasien_model->cari($id);
        if ($pasien && $pasien->dokumen) {
            $file = './uploads/pasien/' . $pasien->dokumen;
            if (file_exists($file)) unlink($file);
        }
        $this->Pasien_model->hapus($id);
        $this->session->set_flashdata('success', 'Data pasien berhasil dihapus');
        redirect('beranda');
    }

    // simpan - satu method untuk create & update + upload file
    public function simpan()
    {
        $this->form_validation->set_rules('nama', 'Nama', 'required|max_length[150]');
        $this->form_validation->set_rules('usia', 'Usia', 'required|numeric');
        $this->form_validation->set_rules('keluhan', 'Keluhan', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('beranda');
            return;
        }

        $id   = (int) $this->input->post('id');
        $data = [
            'nama'    => $this->input->post('nama', TRUE),
            'usia'    => (int) $this->input->post('usia'),
            'keluhan' => $this->input->post('keluhan', TRUE),
            'tanggal' => date('Y-m-d')
        ];

        // proses upload file kalau ada
        if (!empty($_FILES['dokumen']['name'])) {
            $upload = $this->_upload_dokumen();
            if ($upload['status']) {
                $data['dokumen'] = $upload['file_name'];

                // kalau edit, hapus file lama
                if ($id > 0) {
                    $lama = $this->Pasien_model->cari($id);
                    if ($lama && $lama->dokumen) {
                        $fileLama = './uploads/pasien/' . $lama->dokumen;
                        if (file_exists($fileLama)) unlink($fileLama);
                    }
                }
            } else {
                $this->session->set_flashdata('error', 'Upload gagal: ' . $upload['error']);
                redirect('beranda');
                return;
            }
        }

        // update atau insert
        if ($id > 0) {
            $this->Pasien_model->ubah($id, $data);
            $this->session->set_flashdata('success', 'Data pasien berhasil diupdate');
        } else {
            $this->Pasien_model->tambah($data);
            $this->session->set_flashdata('success', 'Data pasien berhasil disimpan');
        }

        redirect('beranda');
    }

    // private method - proses upload file
    private function _upload_dokumen()
    {
        $path = './uploads/pasien/';
        if (!is_dir($path)) mkdir($path, 0777, TRUE);

        $config['upload_path']   = $path;
        $config['allowed_types'] = 'jpg|jpeg|png|pdf';
        $config['max_size']      = 5120; // 5MB
        $config['file_name']     = 'doc_' . time() . '_' . uniqid();
        $config['overwrite']     = FALSE;

        $this->upload->initialize($config);

        if ($this->upload->do_upload('dokumen')) {
            $res = $this->upload->data();
            return ['status' => TRUE, 'file_name' => $res['file_name']];
        } else {
            return ['status' => FALSE, 'error' => $this->upload->display_errors('', '')];
        }
    }
}
