<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
    }

    // halaman default -> cek login
    public function index()
    {
        if ($this->session->userdata('login') === TRUE) {
            redirect('beranda');
        } else {
            redirect('login');
        }
    }

    // form login
    public function login()
    {
        if ($this->session->userdata('login') === TRUE) {
            redirect('beranda');
        }
        $this->load->view('auth/login');
    }

    // proses login  validasi + cek password
    public function proses_login()
    {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', 'Email dan password wajib diisi');
            redirect('login');
            return;
        }

        $email    = $this->input->post('email', TRUE);
        $password = $this->input->post('password', TRUE);

        $user = $this->User_model->cari_by_email($email);

        if ($user && password_verify($password, $user->password)) {
            // set session login
            $this->session->set_userdata([
                'login'     => TRUE,
                'user_id'   => $user->id,
                'user_nama' => $user->nama,
                'user_role' => $user->role
            ]);
            redirect('beranda');
        } else {
            $this->session->set_flashdata('error', 'Email atau password salah!');
            redirect('login');
        }
    }

    // form registrasi
    public function registrasi()
    {
        $this->load->view('auth/registrasi');
    }

    // proses daftar akun baru
    public function proses_daftar()
    {
        $this->form_validation->set_rules('nama', 'Nama', 'required|min_length[3]');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('role', 'Role', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('registrasi');
            return;
        }

        $data = [
            'nama'     => $this->input->post('nama', TRUE),
            'email'    => $this->input->post('email', TRUE),
            'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
            'role'     => $this->input->post('role', TRUE)
        ];

        if ($this->User_model->daftar($data)) {
            $this->session->set_flashdata('success', 'Akun berhasil dibuat! Silakan login.');
            redirect('login');
        } else {
            $this->session->set_flashdata('error', 'Gagal membuat akun');
            redirect('registrasi');
        }
    }

    // logout  hapus session
    public function logout()
    {
        $this->session->sess_destroy();
        redirect('login');
    }
}
